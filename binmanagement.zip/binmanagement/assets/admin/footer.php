<!-- START FOOTER -->
    <footer class="page-footer">
      <div class="container">
        <div class="row section">
          <div class="col l6 s12">
            <h5 class="white-text">World Market</h5>
            <p class="grey-text text-lighten-4">World map, world regions, countries and cities.</p>
            <div id="world-map-markers"></div>
          </div>
          <div class="col l4 offset-l2 s12">
            <h5 class="white-text">Sales by Country</h5>
            <p class="grey-text text-lighten-4">A sample polar chart to show sales by country.</p>
            <div id="polar-chart-holder">
              <canvas id="polar-chart-country" width="200"></canvas>
            </div>
          </div>
        </div>
      </div>
      <footer class="page-footer">
        <div class="footer-copyright">
          <div class="container">
            <span>Copyright ©
              <script type="text/javascript">
                document.write(new Date().getFullYear());
              </script> <a class="grey-text text-lighten-4" href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">PIXINVENT</a> All rights reserved.</span>
            <span class="right hide-on-small-only"> Design and Developed by <a class="grey-text text-lighten-4" href="https://pixinvent.com/">PIXINVENT</a></span>
          </div>
        </div>
      </footer>
    </footer>
    <!-- END FOOTER -->
    <!-- ================================================
    Scripts
    ================================================ -->
    <!-- jQuery Library -->
    <script type="text/javascript" src="vendors/jquery-3.2.1.min.js"></script>
    <!--materialize js-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- chartjs -->
    <script type="text/javascript" src="vendors/chartjs/chart.min.js"></script>
    <!-- sparkline -->
    <script type="text/javascript" src="vendors/sparkline/jquery.sparkline.min.js"></script>
    <!-- google map api -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>
    <!--jvectormap-->
    <script type="text/javascript" src="vendors/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script type="text/javascript" src="vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script type="text/javascript" src="vendors/jvectormap/vectormap-script.js"></script>
    <!--google map-->
    <script type="text/javascript" src="js/scripts/google-map-script.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="js/plugins.js"></script>
    <!--card-advanced.js - Page specific JS-->
    <script type="text/javascript" src="js/scripts/dashboard-analytics.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="js/custom-script.js"></script>
  </body>

<!-- Mirrored from pixinvent.com/materialize-material-design-admin-template/html/horizontal-menu/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 16 Oct 2017 09:32:18 GMT -->
</html>