<?php
class Service_amenity_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
   function getitemstitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_items')->result();
	   
	}
	 function getamenitytitle()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_s_amenity')->result();
	   
	}
	 function getamenity()
   {
	   
	   $this->db->where('org_id',$this->session->userdata('org_id'));
	   $this->db->select('*');
	  return $res= $this->db->get('tbl_service_amenity')->result();
	   
	}	
	
	public function insert() // addproduct
	{
		 $this->db->where('org_id',$this->session->userdata('org_id'));
		 $this->db->delete('tbl_service_amenity');
		 $this->db->where('org_id',$this->session->userdata('org_id'));
		 $this->db->delete('tbl_s_amenity');
		 $this->db->where('org_id',$this->session->userdata('org_id'));
		 $this->db->delete('tbl_s_items');
			
				$max=maxplus('tbl_service_amenity','amenity_id');
				$today= date("y-m-d");
				$org=$this->session->userdata('org_id');
				$general=$this->input->post('txtgeneral');
				$item=$this->input->post('txtitem');
				$g_title=$this->input->post('general_title');
				$c=count($g_title);
				$i_title=$this->input->post('Item_title');
				$c1=count($i_title);
				
				$data3= array('amenity_id'=>$max,'org_id'=>$org,'amenity_title'=>$general,
				'Item_title'=>$item,'create_date'=>$today,'modify_date'=>$today);
				
			$this->db->insert('tbl_service_amenity',$data3);
				
				
				///////////////////////////////////////////tbl_s_amenity
				for($i=0;$i<$c;$i++){
				$data= array('am_id'=>$max,'org_id'=>$org,
				'titles'=>$g_title[$i],'create_date'=>$today,'modify_date'=>$today
				);
				
			$this->db->insert('tbl_s_amenity',$data);
		
				}
			/////////////////////////////////	
				for($j=0;$j<$c1;$j++){
				$data2= array('it_id'=>$max,'org_id'=>$org,
				'titles'=>$i_title[$j],'create_date'=>$today,'modify_date'=>$today
				);
				
			$this->db->insert('tbl_s_items',$data2);
		
				}
				
				
				
				
}

}