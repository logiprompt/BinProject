<?php
class Absents_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getabsents()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_attendance')->result();
		}
		
		
		public function getmainmarketing()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('en_id');
		return $rows=$this->db->get('tbl_enquiry')->result();
		}
		
		public function addabsents()
		{
		  	$max=maxplus('tbl_attendance','attend_id');	
		    $today=date('Y-m-d');
			$data= array(
			   'org_id'=>$this->session->userdata('org_id'),
			   'attend_id'=>$max,
 			   'emp_id'=>$this->input->post('empId'),
			   'abs_date'=>$today,
			   'reason'=>$this->input->post('selReason'),
			   'emp_name'=>$this->input->post('empName'),
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   'status'=>0,
			);
			$this->db->insert('tbl_attendance',$data);	
		}
		public function deleteAbsents(){
		   $aid=$this->input->post('id');
		   $mid=decode($aid);
		   $data=array('status'=>1);
		   $array= array('attend_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_attendance',$data);	
			
		}
		public function editDetails($aid){ 
		    $id=$aid;
			$array=array('status'=>0,'attend_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_attendance');
       		return $rows=$result->row();
		}
		public function updateabsents(){
		    $id=$this->input->post('hdnId');
		    $today=date('Y-m-d');
			$data= array(
			   'org_id'=>$this->session->userdata('org_id'),
			   'attend_id' =>$id,
 			   'emp_id'=>$this->input->post('empId'),
			   'abs_date'=>$this->input->post('atdate'),
			   'reason'=>$this->input->post('selReason'),
			   'emp_name'=>$this->input->post('empName'),
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   'status'=>0
			);
			$array=array('org_id'=>$this->session->userdata('org_id'),'attend_id'=>$id);
			$this->db->where($array);
		    $this->db->update('tbl_attendance',$data);
		
		}
		public function insertnew(){
			$max=maxplus('tbl_enquiry_status','enquiry_status_id');	
		    $today=date('Y-m-d');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			   'enquiry_status_id' =>$max,
		       'status_name'=>$this->input->post('sname'),
			    'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   );
			   	$this->db->insert('tbl_enquiry_status',$data);
			}
			
			public function getnewstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select  id="status" name="status" style="display:block;" ><option value="0" >Select Status</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->enquiry_status_id.' ">'.$val->status_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
				public function getstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				return $res= $rows->result();
		}
		
		public function changevwstatus()
		{
			
		
		$enqid=decode($this->input->post('vid'));
		
		$array=array('status'=>0,'en_id'=>$enqid);
		$data=array('view_status'=>1);
		$this->db->where($array);
		
		$this->db->update('tbl_enquiry',$data);
		}
}