<?php
class Mysales_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	/*public function addsalesreport(){
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('salesmanid')->result();

		
		}*/
	public function getsales(){
		
	 $from=$this->input->post('mysales');
	 $to=$this->input->post('mydate');
     
	 $orgid=$this->session->userdata('org_id');
	  $empid=$this->session->userdata('emp_id');
	 
	 			$array=array('tbl_sales.status'=>0,'tbl_sales.org_id'=>$orgid,'tbl_sales.created_date >='=>$from,'tbl_sales.created_date <='=>$to,'tbl_sales.employee_id'=>$empid);
	 			$this->db->where($array);
				$this->db->select(  'tbl_sales.total_amount,tbl_sales.created_date,tbl_merchant.merchantname,tbl_sales.order_id');
				$this->db->from('tbl_sales');
				$this->db->join('tbl_merchant','tbl_sales.merchant_id=tbl_merchant.merchant_id');
				
	   $r=$this->db->get();	
	   $result=$r->result();
	   $totamt=0;
	   $html='';
				if($r->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($result as $key)
					{	
						$totamt=$totamt+$key->total_amount;
					
						
						$html.='<tr><td>'.$i.'</td>';
							$html.='<td>'.$key->order_id.'</td>';
						$html.='<td>'.$key->merchantname.'</td>';
						
						$html.='<td>'.$key->total_amount.'</td>';
						$html.='<td>'.$key->created_date.'</td></tr>';
					
						$i=$i+1;
					}
					
					    $html.='<td></td>';
						$html.='<td></td>';
						$html.='<td>Total Amount</td>';
						$html.='<td>'.$totamt.'</td>';
					
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
	   
	   
	      
	}

}