<?php
class Cashcollect_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	  public function getmerchant(){
		 $merid=$this->input->post('merid');
		 $array=array('tbl_merchant.status'=>0,'tbl_merchant.merchantid_num'=>$merid);
		$this->db->where($array);
		$this->db->select('*');
		//$this->db->from('tbl_merchant');
		 $query = $this->db->get('tbl_merchant'); 
		$result=$query->result();
		if($query->num_rows() >0){
			$this->output->set_output(json_encode($result));	
		}
		else{
			$this->output->set_output(json_encode(2));
				}
		}  
		
		 public function getareabyid(){
		 $array=array('tbl_merchant.status'=>0,'tbl_merchant.merchant_id'=>$this->input->post('id'));
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
	   public function addcashcollection(){
		$type=$this->input->post('type');
		//$exist=fieldexist('tbl_merchant','merchantname',$this->input->post('txtmerchantname'));
	if($type==1){
		
	$today= $this->input->post('currentdate');
	$time = strtotime($today);
$newformat = date('H:i:s',$time);
		$max=maxplus('tbl_cashcollect','cashcollect_id');
		$today= date("y-m-d");
		$salesmanid=$this->input->post('salesmanid');
		$merchant=$this->input->post('merchant');
		$location=$this->input->post('location');
		$amount=$this->input->post('amount');
		$type=$this->input->post('type');
		$chequeno=$this->input->post('chequeno');
		$date=$this->input->post('date');
		$termradio=$this->input->post('termradio');
		$bank=$this->input->post('bank');
		$branch=$this->input->post('branch');
		$data= array(
		       'cashcollect_id'=>$max,
			    'salesman_id'=>$salesmanid,
			   'merchant_id'=>$merchant,
			   'area_id'=>$location,
			    'amount'=>$amount,
			   'type'=>$type,
			   'checkno'=>$chequeno,
			    'date'=>$date,
			   'bank'=>$bank,
			   'branch'=>$branch,
			    'terminal'=>$termradio,
				'create_time'=>$newformat,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_cashcollect',$data);
		
		$merchant=$this->input->post('merchant');
		$opnbal=$this->input->post('openingbalance')-$this->input->post('amount');
		 $data=array('tbl_opening_balance.openingbalance'=>$opnbal);
		   $array= array('tbl_opening_balance.merchant'=>$merchant,'tbl_opening_balance.status'=>0);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);
		   
		}
			//$this->output->set_output(json_encode($result));	
			else{
				$today= $this->input->post('currentdate');
	$time = strtotime($today);
$newformat = date('H:i:s',$time);
				$max=maxplus('tbl_cashcollect','cashcollect_id');
		$today= date("y-m-d");
		$merchant=$this->input->post('merchant');
		$salesmanid=$this->input->post('salesmanid');
		$location=$this->input->post('location');
		$amount=$this->input->post('amount');
		$type=$this->input->post('type');
		$termradio=$this->input->post('termradio');
		$data= array(
		        'cashcollect_id'=>$max,
				'salesman_id'=>$salesmanid,
			   'merchant_id'=>$merchant,
			   'area_id'=>$location,
			    'amount'=>$amount,
			   'type'=>$type,
			   'checkno'=>'',
			   'bank'=>'',
			   'branch'=>'',
			    'date'=>'',
				 'terminal'=>$termradio,
				 'create_time'=>$newformat,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_cashcollect',$data);
				
		$merchant=$this->input->post('merchant');
		$opnbal=$this->input->post('openingbalance')-$this->input->post('amount');
		 $data=array('tbl_opening_balance.openingbalance'=>$opnbal);
		   $array= array('tbl_opening_balance.merchant'=>$merchant,'tbl_opening_balance.status'=>0);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);		
				}
		}  
	  
	   public function getopeningbalbyid(){
	//	echo  $this->input->post('id');
		
		 $array=array('tbl_opening_balance.status'=>0,'tbl_opening_balance.merchant'=>$this->input->post('id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_opening_balance');
		 $result = $this->db->get()->result(); 
		
		
			$this->output->set_output(json_encode($result));	
		}  
	  
	  public function getlocationbyid(){
	//	echo  $this->input->post('id');
		
		$array=array('tbl_merchant.status'=>0,'tbl_merchant.merchant_id'=>$this->input->post('id'));
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
		
		 public function getterminalsbyid(){
	//	echo  $this->input->post('id');
		
		$array=array('tbl_terminal.status'=>0,'tbl_terminal.merchantid_num'=>$this->input->post('id'));
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_terminal.*,tbl_merchant.merchantid_num');
		$this->db->from('tbl_terminal');

		$this->db->join ( 'tbl_merchant as tbl_merchant', 'tbl_merchant.merchantid_num = tbl_terminal.merchantid_num' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
	  
	  
	  
	  
	  
	    
}