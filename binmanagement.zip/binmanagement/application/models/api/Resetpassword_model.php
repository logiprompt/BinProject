<?php
class Resetpassword_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function checkoldpwd(){
		 
		 $array=array('tbl_salesmanreg.status'=>0,'tbl_salesmanreg.salesmanid'=>$this->input->post('salesmanid'),'tbl_salesmanreg.password'=>$this->input->post('oldpwd'));
		$this->db->where($array);
		$this->db->select('*');
	//	$this->db->from('tbl_salesmanreg');
		 $result = $this->db->get('tbl_salesmanreg');
		 $row=$result->result();
		if($result->num_rows()>0){
			//echo 1;
			$this->output->set_output(json_encode(1));
			//$this->output->set_output(json_encode($result));
			}
		else{//echo 2;
			$this->output->set_output(json_encode(2));
		//$this->output->set_output(json_encode($result));}
			//$this->output->set_output(json_encode($result));	
		}  
}
		 public function getarea(){
		 $array=array('tbl_area.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_area');
		 $result = $this->db->get()->result(); 
		
		
			$this->output->set_output(json_encode($result));	
		}  
	  public function resetpwd()
		{
			//$id=$this->input->post('id');
			$array=array('tbl_salesmanreg.status'=>0,'tbl_salesmanreg.salesmanid'=>$this->input->post('salesmanid'),'tbl_salesmanreg.password'=>$this->input->post('oldpwd'));
		$this->db->where($array);
		$this->db->select('*');
	//	$this->db->from('tbl_salesmanreg');
		 $result = $this->db->get('tbl_salesmanreg');
		 $row=$result->result();
		if($result->num_rows()>0){
			
			
				$newpwd=$this->input->post('newpassword');
				$data= array(
				'password' =>$newpwd,
				);	
		
				$array= array('tbl_salesmanreg.status'=>0,'salesmanid'=>$this->input->post('salesmanid'),);
		 		 $this->db->where($array);
		   $this->db->update('tbl_salesmanreg',$data);
				$this->output->set_output(json_encode(1));
				}
				else{
					$this->output->set_output(json_encode(2));
					}
				
			
			
		}
	  /* public function addcashcollection(){
		$type=$this->input->post('type');
		//$exist=fieldexist('tbl_merchant','merchantname',$this->input->post('txtmerchantname'));
	if($type==1){
		
	
		$max=maxplus('tbl_cashcollect','cashcollect_id');
		$today= date("y-m-d");
		$salesmanid=$this->input->post('salesmanid');
		$merchant=$this->input->post('merchant');
		$location=$this->input->post('location');
		$amount=$this->input->post('amount');
		$type=$this->input->post('type');
		$chequeno=$this->input->post('chequeno');
		$date=$this->input->post('date');
		$bank=$this->input->post('bank');
		$branch=$this->input->post('branch');
		$data= array(
		       'cashcollect_id'=>$max,
			    'salesman_id'=>$salesmanid,
			   'merchant_id'=>$merchant,
			   'area_id'=>$location,
			    'amount'=>$amount,
			   'type'=>$type,
			   'checkno'=>$chequeno,
			    'date'=>$date,
			   'bank'=>$bank,
			   'branch'=>$branch,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_cashcollect',$data);
		
		$merchant=$this->input->post('merchant');
		$opnbal=$this->input->post('openingbalance')-$this->input->post('amount');
		 $data=array('tbl_opening_balance.openingbalance'=>$opnbal);
		   $array= array('tbl_opening_balance.merchant'=>$merchant,'tbl_opening_balance.status'=>0);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);
		   
		}
			//$this->output->set_output(json_encode($result));	
			else{
				$max=maxplus('tbl_cashcollect','cashcollect_id');
		$today= date("y-m-d");
		$merchant=$this->input->post('merchant');
		$salesmanid=$this->input->post('salesmanid');
		$location=$this->input->post('location');
		$amount=$this->input->post('amount');
		$type=$this->input->post('type');
		$data= array(
		        'cashcollect_id'=>$max,
				'salesman_id'=>$salesmanid,
			   'merchant_id'=>$merchant,
			   'area_id'=>$location,
			    'amount'=>$amount,
			   'type'=>$type,
			   'checkno'=>'',
			   'bank'=>'',
			   'branch'=>'',
			    'date'=>'',
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_cashcollect',$data);
				
		$merchant=$this->input->post('merchant');
		$opnbal=$this->input->post('openingbalance')-$this->input->post('amount');
		 $data=array('tbl_opening_balance.openingbalance'=>$opnbal);
		   $array= array('tbl_opening_balance.merchant'=>$merchant,'tbl_opening_balance.status'=>0);
		   $this->db->where($array);
		   $this->db->update('tbl_opening_balance',$data);		
				}
		}  
	  
	   public function getopeningbalbyid(){
	//	echo  $this->input->post('id');
		
		 $array=array('tbl_opening_balance.status'=>0,'tbl_opening_balance.merchant'=>$this->input->post('id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_opening_balance');
		 $result = $this->db->get()->result(); 
		
		
			$this->output->set_output(json_encode($result));	
		}  
	  
	  public function getlocationbyid(){
	//	echo  $this->input->post('id');
		
		$array=array('tbl_merchant.status'=>0,'tbl_merchant.merchant_id'=>$this->input->post('id'));
		$this->db->where($array);
	//$this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');

		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		 $result = $this->db->get()->result(); 
			
			$this->output->set_output(json_encode($result));	
		}  
	  
	  */
	  
	  
	  
	  
	    
}