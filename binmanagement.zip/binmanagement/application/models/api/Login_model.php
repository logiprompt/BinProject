<?php
class Login_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      
	 public function login(){
			
		$user    = $this->input->post('username');
         $password  =  $this->input->post('password');
		 //$pass=do_hash($password,'md5');
		 $array=array('username'=>$user,'password'=>$password,'status'=>0);
                $this->db->where($array);
				$query = $this->db->get('tbl_login');
				$result=$query->row();
				$today=date('Y-m-d');
				$ex=0;
				if($query->num_rows() >0){
						$ugroup=$result->usergroup;
					$appstatus=$result->app_status;
						if($appstatus==1){
							$trialdays=$result->trial_days;
								
							$d='+'.$trialdays.' days';
							$from=$result->created_date;
						//	$nfrm=date('Y-m-d',$from)	;
							$fr = new DateTime($from);
							$frm = $fr->format('Y-m-d');
							
							$to = date('Y-m-d',strtotime($d,strtotime($from)));
							
								if($today>=$frm && $today<=$to)
								{
									$ex=0;
								}
								else{
									$ex=1;
								}
							}
								else if($ugroup!='org' && $ugroup!='0' ){
								
								$oid=$result->org_id;
								
									$arr=array('emp_id'=>$oid,'status'=>0);
									$this->db->where($arr);
									$this->db->select('*');
									$qu = $this->db->get('tbl_login');
									$res=$qu->row();
									
										if($qu->num_rows()>0){
										
												$ugroup=$res->usergroup;
												$appstatus=$res->app_status;
										
											if($appstatus==1 ){	
											$trialdays=$res->trial_days;
										
											$d='+'.$trialdays.' days';
											$from=$res->created_date;
										//	$nfrm=date('Y-m-d',$from)	;
											$fr = new DateTime($from);
											$frm = $fr->format('Y-m-d');
											
											$to = date('Y-m-d',strtotime($d,strtotime($from)));
												
												if($today>=$frm && $today<=$to)
												{
													$ex=0;
												
												}
												else{
													$ex=1;
												}
													
										}
										}
								
								}
								if($ex==0){
					$emp_id=$result->emp_id;
						$org_id=$result->org_id;
						$usergroup=$result->usergroup;
						
						$this->session->set_userdata(array(
										'loggedIn'=> true,
										'username' =>$user,
										'emp_id' =>$emp_id,
										'org_id' =>$org_id,
										'usergroup'=>$usergroup
								));	
						
					$this->output->set_output(json_encode($result));
			}
			else{		
						echo 3;	
					}
			
				}else{
			$this->output->set_output(json_encode(2));
				//echo 2;
				}
				
		}  
	  
	   public function checkattendance()
	{
			$uname    = $this->input->post('uname');
		date_default_timezone_set("Asia/Calcutta");
		$today=date('Y-m-d H:i:s');
		$date = new DateTime("now");
		$curr_date = $date->format('Y-m-d');
		$this->db->where('DATE(date)',$curr_date);
		$this->db->where('emp_id',$uname);
		$this->db->select('tbl_attendance.*');
		$this->db->from('tbl_attendance');
		$atn=$this->db->get()->result();
		if(empty($atn))
		{
			echo 0;
			
			}
			else{
				
				echo 1;
				}
		
	}
	  
	  
 public function checkphoto()
	{
		
		$empid    = $this->input->post('empid');
		 $array=array('salesmanid'=>$empid,'status'=>0);
                $this->db->where($array);
				 $this->db->select('attendance_tracker');
				$query = $this->db->get('tbl_salesmanreg');
				$result=$query->row();
				
				if($query->num_rows() >0){
					echo $result->attendance_tracker;
					
					}
	
	}	  
	  
	  public function addattendance()
	{
		$empid=$this->input->post('empid');
		$orgid=$this->input->post('orgid');
		$lat=$this->input->post('lat');
		$long=$this->input->post('long');
		
		date_default_timezone_set("Asia/Calcutta");
		$today=date('Y-m-d H:i:s');
		$date = new DateTime("now");
		$curr_date = $date->format('Y-m-d ');
		$this->db->where('DATE(date)',$curr_date);
		$this->db->where('emp_id',$empid);
		$this->db->select('tbl_attendance.*');
		$this->db->from('tbl_attendance');
		$atn=$this->db->get()->result();
		if(empty($atn))
		{
		$max=maxplus('tbl_attendance','attend_id');
		//echo $path;
		$data= array(
				'org_id'=>$orgid,
			   'attend_id' =>$max,
		       'emp_id'=>$empid,
			   'date'=>$today,
			   'latitude'=>$lat,
			   'longitude'=>$long,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_attendance',$data);
		
		echo 1;
		}
		
		
		
		
	} 
	  public function addattendancephoto()
	{
		$empid=$this->input->post('empid');
		$orgid=$this->input->post('orgid');
		$lat=$this->input->post('lat');
		$long=$this->input->post('long');
		$photos=$this->input->post('photo');
		
		date_default_timezone_set("Asia/Calcutta");
		$today=date('Y-m-d H:i:s');
		$date = new DateTime("now");
		$curr_date = $date->format('Y-m-d ');
		$this->db->where('DATE(date)',$curr_date);
		$this->db->where('emp_id',$empid);
		$this->db->select('tbl_attendance.*');
		$this->db->from('tbl_attendance');
		$atn=$this->db->get()->result();
		if(empty($atn))
		{
		$max=maxplus('tbl_attendance','attend_id');
		//echo $path;
		$data= array(
				'org_id'=>$orgid,
			   'attend_id' =>$max,
		       'emp_id'=>$empid,
			   'date'=>$today,
			   'photo'=>$photos,
			   'latitude'=>$lat,
			   'longitude'=>$long,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_attendance',$data);
		
		echo 1;
		}
		
		
		
		
	}     
}