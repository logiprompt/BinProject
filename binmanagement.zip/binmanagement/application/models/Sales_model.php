<?php
class Sales_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	public function checkprostock()
	{
		$proq=$this->input->post('proq');
		$proo=$this->input->post('proo');
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'product_id'=>$proo);
		$this->db->where($array);
		$this->db->select('negative_stock,qtyonhand');
		 $rows=$this->db->get('tbl_product');
		 $res=$rows->row();
		 if( $rows->num_rows()>0){
			if($res->negative_stock==2 && $res->qtyonhand <= 0){
				echo 1;
			}
			else if($res->negative_stock==2 && $res->qtyonhand <$proq ){
				echo 2;
			}
			
		 }
	}
	public function getmerchant()
		{
			//tbl_merchantproduct.merchant_id,tbl_merchantproduct.merchant_product,tbl_merchantproduct.merchant_product_id,tbl_product.product_id,tbl_product.product_name'
			$array=array('tbl_merchant.status'=>0,'tbl_merchant.org_id'=>$this->session->userdata('org_id'));
		 $this->db->where($array);
	    $this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');
			//$this->db->join('tbl_merchantproduct as tbl_merchantproduct', 'tbl_merchant.merchant_id=tbl_merchantproduct.merchant_id');
		//$this->db->join('tbl_product as tbl_product', 'tbl_merchantproduct.merchant_product=tbl_product.product_id');
		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		return $result = $this->db->get()->result(); 
			
		}
	public function getproducts(){
	$sid=	$this->session->userdata('org_id');
	
	$rows=	$this->db->query("SELECT * FROM  tbl_product WHERE (status =0 AND  org_id = '".$sid."' AND qtyonhand >0 AND  negative_stock =2)OR (negative_stock =1 AND  status =0 AND  org_id ='".$sid."') ");

		/*$array1=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'qtyonhand >'=>0,'negative_stock'=>2);
		$this->db->where($array1);
		$array2=array('negative_stock'=>1);
			$this->db->or_where($array2);
			$array3=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array3);
		$this->db->select('*');
		
		return $rows=$this->db->get('tbl_productc')->result();*/
return $rows->result();
		
		}
	public function getcategory()
	{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_category')->result();

	}
	public function merchantsearch()
	{
		$num=$this->input->post('mer_num');
		
		$array=array('status'=>0,'merchantid_num'=>$num);
		$this->db->where($array);
		$this->db->select('merchant_id,merchantname,address,phoneno,tax_type,gst_reg,bank_name,account_name,account_no,ifsc_code');
		
		$rows1=$this->db->get('tbl_merchant');
		$result1=$rows1->row();
		
		if($rows1->num_rows()>0){
			
		$id=$result1->merchant_id;
		$this->session->set_userdata('mer_id',$id);
		
		
		$array=array('status'=>0,'merchant'=>$id);
		$this->db->where($array);
		$this->db->select('*');
		$rows2=$this->db->get('tbl_opening_balance')->row();
	
		$mname=$result1->merchantname;
		$maddress=$result1->address;
		$mphone=$result1->phoneno;
		
		$tax_type=$result1->tax_type;
		$gst_reg=$result1->gst_reg;
		$bank_name=$result1->bank_name;
		$account_name=$result1->account_name;
		$account_no=$result1->account_no;
		$ifsc_code=$result1->ifsc_code;
		
		
		$opbal=0;
	
		$html='';	
		$html='<div class="card-panel">
                      <h4 class="header2"></h4>
                      <div class="row">
                      <div class="row">
                            <div class="input-field col s6">
                              <input   type="text" value="'.$mname.'" readonly >
                              <label for="first_name" class="active"> Merchant Name</label>
                            </div>
                          
                            <div class="input-field col s6">
                              <input  type="text" value="'.$maddress.'" readonly >
                              <label for="first_name" class="active"> Merchant Address</label>
                            </div>
                          </div>
                           <div class="row">
                            
                              <input  name="taxtype" id="taxtype"  type="hidden" value="'.$tax_type.'">
                             
                            
                          
                            <div class="input-field col s6">
                              <input   type="text" value="'.$gst_reg.'" readonly >
                              <label for="first_name" class="active">Gst No</label>
                            </div>
                         
                            <div class="input-field col s6">
                              <input   type="text" value="'.$bank_name.'" readonly >
                              <label for="first_name" class="active">Bank Name</label>
                            </div>
                           </div>
						  <div class="row">
                           
                          
                            <div class="input-field col s6">
                              <input   type="text" value="'.$account_name.'" readonly >
                              <label for="first_name" class="active">Account Name</label>
                            </div>
                         
                            <div class="input-field col s6">
                              <input  type="text" value="'.$account_no.'" readonly >
                              <label for="first_name" class="active"> Account No</label>
                            </div>
                          </div>
						  <div class="row">
                            <div class="input-field col s6">
                              <input    type="text" value="'.$ifsc_code.'" readonly >
                              <label for="first_name" class="active">IFSC code</label>
                            </div>
                          </div>
                     
                          </div>
						 
                      </div>
                    </div>
					';
			echo $html;		
		}
		else{
			echo 1;
			 /*$html='<div class="card-panel">
                      <div class="row"><h4 class="header2" style="text-align: center;">No result Found</h4><div></div>';
			 	*/
			}
			
		
		
		
	}
	
	public function selproamount()
	{
		
		$id=$this->input->post('id');
		
		$array=array('tbl_product.status'=>0,'tbl_product.product_id'=>$id);
		$this->db->where($array);
		$this->db->select('tbl_product.product_name,tbl_product.mrp,tbl_product.p_measurement,tbl_product.amount,tbl_measurement.measurement_name,tbl_product_type.pro_type_name,tbl_product_type.pro_type_percentage');
		$this->db->from('tbl_product');
		$this->db->join('tbl_measurement','tbl_measurement.measurement_id=tbl_product.p_measurement');
		$this->db->join('tbl_product_type','tbl_product_type.pro_type_id=tbl_product.p_type');
		$rows2=$this->db->get()->row();
		$arr=array('p_name'=>$rows2->product_name,'mrp'=>$rows2->mrp,'s_amt'=>$rows2->amount,'measure_name'=>$rows2->measurement_name,'p_type'=>$rows2->pro_type_name,'p_type_per'=>$rows2->pro_type_percentage);
		//echo $rows2->p_netamount;
	echo json_encode($arr);
		}	
		
	public function addorder()
	{

		$selcat=$this->input->post('selcat');
		$txtmrp=$this->input->post('txtmrp');
		$txtunit=$this->input->post('txtunit');
		$qty=$this->input->post('qty');
		$txtrate=$this->input->post('txtrate');
		$txtrateinctax=$this->input->post('txtrateinctax');
		$txttotal=$this->input->post('txttotal');
		$txtdiscountp=$this->input->post('txtdiscountp');
		$txtdiscounta=$this->input->post('txtdiscounta');
		$txttaxpay=$this->input->post('txttaxpay');
		$txtcgstrate=$this->input->post('txtcgstrate');
		$txtcgstamt=$this->input->post('txtcgstamt');
		$txtsgstrate=$this->input->post('txtsgstrate');
		$txtsgstamt=$this->input->post('txtsgstamt');
		$txtnetamt=$this->input->post('txtnetamt');
		$txtigstrate=$this->input->post('txtigstrate');
		$txtigstamt=$this->input->post('txtigstamt');
		
		$txtigstamt=$this->input->post('txtigstamt');
		$txtigstamt=$this->input->post('txtigstamt');
		
		$taxtype=$this->input->post('taxtype');
		$salestype=$this->input->post('salestype');
		
		$c1=count($this->input->post('selcat'));
		 $emptyarr=array();
		 $err=0;
		 $oerr=0;
		for($i1=0;$i1<$c1;$i1++){
						
							if($selcat[$i1]!=0){
								
								$proqty=$qty[$i1];
								$prooid=$selcat[$i1];
								
								$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'product_id'=>$prooid);
								$this->db->where($array);
								$this->db->select('negative_stock,qtyonhand,product_name');
								 $rows=$this->db->get('tbl_product');
								 $res=$rows->row();
								
								 if( $rows->num_rows()>0){
									if(($res->negative_stock==2 && $res->qtyonhand <= 0 ) || ($res->negative_stock==2 && $res->qtyonhand <$proqty )){
										//echo 1;
										 //$emptyarr=
										array_push($emptyarr,$res->product_name);
										
										echo json_encode($emptyarr);
										$err=1;
									}
								 }
								}
							}
							
							
		
	
		if($err==0){	
		$selpmode=$this->input->post('selmode');
		$selptype='';
		if($selpmode!=3){
		$selptype=$this->input->post('selmodetype');
		}
		$chqnum='';
		$bank='';
		$chqdate='';
		$partialamt='';
		$creditamt='';
		if(($selpmode==1 && $selptype==2) ||($selpmode==2 && $selptype==2) ){
		$chqnum=$this->input->post('chqnum');
		$bank=$this->input->post('bank');
		$chqdate=$this->input->post('chqdate');
		}
		if($selpmode==2){
		$partialamt=$this->input->post('partialamt');
		$creditamt=$this->input->post('creditamt');	
		}
		
		$date=date('Y-m-d');
		
		$txttotbillamt=$this->input->post('txttotbillamt');
		$orderid=$this->input->post('txtorderid');
			 	if($salestype==2){
							$ostatus=1;	
								}
								else{
									$ostatus=0;	
									
									}	
									
		if($selpmode==2 || $selpmode==3){
			
			if($selpmode==2 ){
				$oamt=$partialamt;
				
				}
				else{
					$oamt=$txttotbillamt;
					
					}
					
					$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant_id'=>$this->session->userdata('mer_id'));
			$this->db->where($array);
			$this->db->select('creditlimit');
			 $rowslimit=$this->db->get('tbl_merchant');
				$reslimit=$rowslimit->row();
			
				if($rowslimit->num_rows()>0){
			$mercreditlimit=$reslimit->creditlimit;
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant'=>$this->session->userdata('mer_id'));
			$this->db->where($array);
			$this->db->select('openingbalance');
			 $rows=$this->db->get('tbl_opening_balance');
				$res=$rows->row();
			
				if($rows->num_rows()>0){
					
					$oldopnbal1=$res->openingbalance;
					$newcreditamt=$oldopnbal1+$oamt;
					
					if($newcreditamt>$mercreditlimit){
						
						$oerr=1;
						echo 2;
						}
				
				
				}
				else{
					if($oamt>$mercreditlimit){
						
						$oerr=1;
						echo 2;
						}
					
					}
		
			}
		}				
		if($oerr==0){		
		
				$array=array(
				'org_id'=>$this->session->userdata('org_id'),
				'order_id'=>$orderid,
				'merchant_id'=>$this->session->userdata('mer_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'tax_type'=>$taxtype,
				'total_amount'=>$txttotbillamt,
				'created_date'=>$date,
				'modified_date'=>$date,
				'status'=>$ostatus
				);
				$this->db->insert('tbl_order',$array);
				
				if($salestype==2){
					$array=array(
				'org_id'=>$this->session->userdata('org_id'),
				'order_id'=>$orderid,
				'merchant_id'=>$this->session->userdata('mer_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'tax_type'=>$taxtype,
				'total_amount'=>$txttotbillamt,
				'created_date'=>$date,
				'modified_date'=>$date,
				'status'=>0
				);
				$this->db->insert('tbl_sales',$array);
					
					}
				$c=count($this->input->post('selcat'));
			//	echo $selcat[0];
					for($i=0;$i<$c;$i++){
						
							if($selcat[$i]!=0){
								
								
							    $proqty1=$qty[$i];
								$prooid1=$selcat[$i];
								
								$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'product_id'=>$prooid1);
								$this->db->where($array);
								$this->db->select('qtyonhand');
								 $rows=$this->db->get('tbl_product');
								 $res=$rows->row();
								if($rows->num_rows()>0){
									
								$nwqty=	$res->qtyonhand-$qty[$i];
								$arrqty=array('qtyonhand'=>$nwqty);
								$arrqtyc=array('product_id'=>$prooid1);
								$this->db->where($arrqtyc);
									$this->db->update('tbl_product',$arrqty);
									}
								
								
								
								
								
							if($salestype==2){
							$orderstatus=1;	
								}
								else{
									$orderstatus=0;	
									
									}
								$max=maxplus('tbl_order_details','order_details_id');	
								if($taxtype==1){
								$array=array(
									'org_id'=>$this->session->userdata('org_id'),
									'order_details_id'=>$max,
									'order_id'=>$orderid,
									'item_id'=>$selcat[$i],
								//	'unit'=>$txtunit[$i],
									'qty'=>$qty[$i],
									'rate'=>$txtrate[$i],
									'rateinctax'=>$txtrateinctax[$i],
									'total'=>$txttotal[$i],
									'discount_per'=>$txtdiscountp[$i],
									'discount_amt'=>$txtdiscounta[$i],
									'taxpay'=>$txttaxpay[$i],
									'cgst_rate'=>$txtcgstrate[$i],
									'cgst_amt'=>$txtcgstamt[$i],
									'sgst_rate'=>$txtsgstrate[$i],
									'sgst_amt'=>$txtsgstamt[$i],
									//'igst_rate'=>$txtigstrate[$i],
									//'igst_amt'=>$txtigstamt[$i],
									'net_amt'=>$txtnetamt[$i],
									'created_date'=>$date,
									'modified_date'=>$date,
									'status'=>$orderstatus
								);
								}
								 if($taxtype==2){
								$array=array(
									'org_id'=>$this->session->userdata('org_id'),
									'order_details_id'=>$max,
									'order_id'=>$orderid,
									'item_id'=>$selcat[$i],
								//	'unit'=>$txtunit[$i],
									'qty'=>$qty[$i],
									'rate'=>$txtrate[$i],
									'rateinctax'=>$txtrateinctax[$i],
									'total'=>$txttotal[$i],
									'discount_per'=>$txtdiscountp[$i],
									'discount_amt'=>$txtdiscounta[$i],
									'taxpay'=>$txttaxpay[$i],
									'igst_rate'=>$txtigstrate[$i],
									'igst_amt'=>$txtigstamt[$i],
									'net_amt'=>$txtnetamt[$i],
									'created_date'=>$date,
									'modified_date'=>$date,
									'status'=>$orderstatus
								);
								}
								$this->db->insert('tbl_order_details',$array);
								
							
							if($salestype==2)
							{
								
							
								$max=maxplus('tbl_sales_details','salesdetails_id');	
								if($taxtype==1){
								$array1=array(
									'org_id'=>$this->session->userdata('org_id'),
									'salesdetails_id'=>$max,
									'order_id'=>$orderid,
									'item_id'=>$selcat[$i],
								//	'unit'=>$txtunit[$i],
									'qty'=>$qty[$i],
									'rate'=>$txtrate[$i],
									'rateinctax'=>$txtrateinctax[$i],
									'total'=>$txttotal[$i],
									'discount_per'=>$txtdiscountp[$i],
									'discount_amt'=>$txtdiscounta[$i],
									'taxpay'=>$txttaxpay[$i],
									'cgst_rate'=>$txtcgstrate[$i],
									'cgst_amt'=>$txtcgstamt[$i],
									'sgst_rate'=>$txtsgstrate[$i],
									'sgst_amt'=>$txtsgstamt[$i],
									//'igst_rate'=>$txtigstrate[$i],
									//'igst_amt'=>$txtigstamt[$i],
									'net_amt'=>$txtnetamt[$i],
									'created_date'=>$date,
									'modified_date'=>$date,
									'status'=>0
								);
								}
								else if($taxtype==2){
								$array1=array(
									'org_id'=>$this->session->userdata('org_id'),
									'salesdetails_id'=>$max,
									'order_id'=>$orderid,
									'item_id'=>$selcat[$i],
								//	'unit'=>$txtunit[$i],
									'qty'=>$qty[$i],
									'rate'=>$txtrate[$i],
									'rateinctax'=>$txtrateinctax[$i],
									'total'=>$txttotal[$i],
									'discount_per'=>$txtdiscountp[$i],
									'discount_amt'=>$txtdiscounta[$i],
									'taxpay'=>$txttaxpay[$i],
									'igst_rate'=>$txtigstrate[$i],
									'igst_amt'=>$txtigstamt[$i],
									'net_amt'=>$txtnetamt[$i],
									'created_date'=>$date,
									'modified_date'=>$date,
									'status'=>0
								);
								}
								$this->db->insert('tbl_sales_details',$array1);
								
							
								}
								}
						
						}
					
					
					if($selpmode==1){
						$max=maxplus('tbl_payment_details','payment_id');			
				$array2=array(
				
				'payment_id'=>$max,
				'org_id'=>$this->session->userdata('org_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$this->session->userdata('mer_id'),
				'invoice_id'=>$orderid,
				'payment_mode'=>$selpmode,
				'payment_type'=>$selptype,
				'cheque_num'=>$chqnum,
				'cheque_bank'=>$bank,
				'cheque_date'=>$chqdate,
				'p_amount'=>$txttotbillamt,
				'created_date'=>$date,
				'modified_date'=>$date
				);
						
					$this->db->insert('tbl_payment_details',$array2);		
						
						}
					if($selpmode==2)
							{	
				$max=maxplus('tbl_payment_details','payment_id');			
				$array2=array(
				
				'payment_id'=>$max,
				'org_id'=>$this->session->userdata('org_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$this->session->userdata('mer_id'),
				'invoice_id'=>$orderid,
				'payment_mode'=>$selpmode,
				'payment_type'=>$selptype,
				'cheque_num'=>$chqnum,
				'cheque_bank'=>$bank,
				'cheque_date'=>$chqdate,
				'p_amount'=>$partialamt,
				'created_date'=>$date,
				'modified_date'=>$date
				);
						
					$this->db->insert('tbl_payment_details',$array2);	
				}
					if($selpmode==2){
				
						
				$max=maxplus('tbl_credit_details','credit_details_id');			
				$array4=array(
				
				'credit_details_id'=>$max,
				'org_id'=>$this->session->userdata('org_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$this->session->userdata('mer_id'),
				'invoice_id'=>$orderid,
				'payment_mode'=>$selpmode,
				'payment_type'=>$selptype,
				'credit_amt'=>$creditamt,
				'created_date'=>$date,
				'modified_date'=>$date
				);
				$this->db->insert('tbl_credit_details',$array4);
				
				
				
				
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant'=>$this->session->userdata('mer_id'));
			$this->db->where($array);
			$this->db->select('*');
			 $rows=$this->db->get('tbl_opening_balance');
				$res=$rows->row();
				$tdate=date('Y-m-d');
				if($rows->num_rows()>0){
					
					$oldopnbal=$res->openingbalance;
					$newopnbal=$oldopnbal+$creditamt;				
						
						$arrayc=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant'=>$this->session->userdata('mer_id'));
			$this->db->where($arrayc);
						$obalarray=array(
						'openingbalance'=>$newopnbal,
						);
						$this->db->update('tbl_opening_balance',$obalarray);			
					
					}
					else{
					$omax=maxplus('tbl_opening_balance','openbalance_id');		
					$oarr=array(
										'openbalance_id'=>$omax,
										'org_id'	=>$this->session->userdata('org_id'),	
										'merchant'	=>$this->session->userdata('mer_id'),
										'date'	=>$tdate,
										'openingbalance'=>$creditamt,
										'status'=>0,
										'create_date'=>$tdate,
										'modify_date'=>$tdate
									);
						
							
						$this->db->insert('tbl_opening_balance',$oarr);		
						
						}
				
	}
				
				
				if($selpmode==3)
							{	
				$max=maxplus('tbl_credit_details','credit_details_id');			
				$array4=array(
				
				'credit_details_id'=>$max,
				'org_id'=>$this->session->userdata('org_id'),
				'employee_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$this->session->userdata('mer_id'),
				'invoice_id'=>$orderid,
				'payment_mode'=>$selpmode,
				'payment_type'=>$selptype,
				'credit_amt'=>$txttotbillamt,
				'created_date'=>$date,
				'modified_date'=>$date
				);
						
				$this->db->insert('tbl_credit_details',$array4);		
					
					
					
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant'=>$this->session->userdata('mer_id'));
			$this->db->where($array);
			$this->db->select('*');
			 $rows=$this->db->get('tbl_opening_balance');
				$res=$rows->row();
				$tdate=date('Y-m-d');
				if($rows->num_rows()>0){
					
					$oldopnbal=$res->openingbalance;
					$newopnbal=$oldopnbal+$txttotbillamt;				
						
						$arrayc=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),'merchant'=>$this->session->userdata('mer_id'));
			$this->db->where($arrayc);
						$obalarray=array(
						'openingbalance'=>$newopnbal,
						);
						$this->db->update('tbl_opening_balance',$obalarray);			
					
					}
					else{
					$omax=maxplus('tbl_opening_balance','openbalance_id');		
					$oarr=array(
										'openbalance_id'=>$omax,
										'org_id'	=>$this->session->userdata('org_id'),	
										'merchant'	=>$this->session->userdata('mer_id'),
										'date'	=>$tdate,
										'openingbalance'=>$txttotbillamt,
										'status'=>0,
										'create_date'=>$tdate,
										'modify_date'=>$tdate
									);
						
							
						$this->db->insert('tbl_opening_balance',$oarr);		
						
						}
						
				}
				
			//$prodarr=array('qtyonhand'=>)	
		
		 
		 echo 1;
			}
		}
	}
		
	
		
}					
						
			/*	$in=0;
			$sch=$this->input->post('selcat');
			$cou=$this->input->post('cou');
			echo $cou[0];
		$sc=	count($sch);
		
		for(i=0;i<$sc,i++){
			$arr=array('scname'=>$sch[$i],'course'=>$cou[$i]);
			
			
			}
			foreach($this->input->post('selcat')	as $val){
				if($val){
					$max=maxplus('tbl_order_details','order_details_id');
						$array=array(
							'org_id'=>$this->session->userdata('org_id'),
						'order_details_id'=>$max,
						'order_id'=>$orderid,
						'item_id'=> $val,
						'qty'=>$qty[$in],
						'net_amount'=>$amt[$in],
						'gross_amount'=>$gamt[$in],
						'item_discount'=>$dis[$in],
						'created_date'=>$date,
						'modified_date'=>$date
						);
						$this->db->insert('tbl_order_details',$array);
					}
				$in++;
				}
				
				foreach($this->input->post('selcat')	as $val){
				if($val){
					
						$array=array('tbl_product_tax.status'=>0,'tbl_product_tax.txp_p_id'=>$val);
						$this->db->where($array);
						$this->db->select('tbl_product_tax.txp_tax_type,tbl_product_tax.txp_property,tbl_product_tax.txp_percentage,tbl_product.p_discount');
						$this->db->from('tbl_product_tax');
						$this->db->join('tbl_product','tbl_product.product_id=tbl_product_tax.txp_p_id');
						$taxdetails=$this->db->get()->result();
						
								foreach($taxdetails as $taxval){
									
									$tid=$taxval->txp_tax_type;
									$tpid=$taxval->txp_property;
									$tper=$taxval->txp_percentage;
									$tdis=$taxval->p_discount;
								
									$max1=maxplus('tbl_order_tax_details','order_tax_details_id');
								$array=array(
									'org_id'=>$this->session->userdata('org_id'),
								'order_tax_details_id'=>$max1,
								'order_id'=>$orderid,
								'item_id'=> $val,
								'tax_id'=>$tid,
								'tax_property_id'=>$tpid,
								'tax_percentage'=>$tper,
								//'item_discount'=>$tdis,
								'created_date'=>$date,
								'modified_date'=>$date
								);
								$this->db->insert('tbl_order_tax_details',$array);
								
									}
							
					}
			//	$in++;
				}
		
		
		
		
		$array=array('tbl_order_tax_details.status'=>0,'tbl_order_tax_details.order_id'=>$orderid);
		$this->db->where($array);
		$this->db->select('tbl_order_tax_details.*,tbl_taxpropery.ptax_propery');
		$this->db->from('tbl_order_tax_details');
		$this->db->join('tbl_taxpropery','tbl_taxpropery.ptax_u_id=tbl_order_tax_details.tax_property_id');
		$orderdet=$this->db->get();
		$orderdetres=$orderdet->result();
		
		$array=array('tbl_order_details.status'=>0,'tbl_order_details.order_id'=>$orderid);
		$this->db->where($array);
		$this->db->select('tbl_order_details.*,tbl_product.product_name');
		$this->db->from('tbl_order_details');
		//$this->db->group_by('tbl_order_details.item_id');
		$this->db->join('tbl_product','tbl_product.product_id=tbl_order_details.item_id');
	//	$this->db->join('tbl_product_tax','tbl_product_tax.txp_p_id=tbl_order_details.item_id');
		$orderdt1=$this->db->get()->result();
		
		
		$html='';
		
		if($orderdet->num_rows()>0){
			
			$html.='<table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">

                      <thead><tr><th style="width:20px;text-align:center;">SN</th>
					  <th>Item</th>
                          <th>Qty</th>
                           <th>Gross amt</th>
                          <th>Tax</th>
                           <th>Discount</th>
                          <th>Net amt</th>
						  <th></th>
                          <th style="width:75px"></th>
                        </tr>
                      </thead>
                      <tbody>';
					  $totalamt=0;
					 // $tcount=1;
					 $tottxamt=0;
					  $txpropamt=array();
					  $itmc=count($orderdt1);
					  $totalgrossamt=0;
					$c=1;  foreach($orderdt1 as $vdet){
						
						
						
						
						
						$totalamt=$totalamt+$vdet->net_amount;
			$html.='<tr>
								<td style="width:20px;text-align:center;">'.$c.'</td>
								<td style="text-align:left;" >'.$vdet->product_name.' </td>
                                <td style="text-align:left;" >'.$vdet->qty.' </td>';
								$progrossamt=$vdet->gross_amount*$vdet->qty;
								$totalgrossamt=$totalgrossamt+$progrossamt;
                      $html.='<td style="text-align:left;" >'.$progrossamt .' </td><td style="text-align:left;width: 140px;" >';
								
							//$arrtaxwisetotal=array();	
							foreach($orderdetres as $vtxdet){
									$txamt1=0;
									
									
									//$txamt1=($vdet->gross_amount*$vdet->qty)*($vtxdet->tax_percentage/100);
									
									
									$txamt=0;
								if($vtxdet->order_id==$vdet->order_id && $vtxdet->item_id==$vdet->item_id)	{
									
									$txamt=($vdet->gross_amount*$vdet->qty)*($vtxdet->tax_percentage/100); 
									//$txpropamt.$tcount=$txamt;
									$txpropamt[$vtxdet->item_id][$vtxdet->tax_property_id]=$txamt;
								//	$txpropamt[$vtxdet->item_id]['property_id_'.$vtxdet->tax_property_id]=$vtxdet->tax_property_id;
									
										
									//$tcount++;
									$html.='<span style="font-size:10px;">'.$vtxdet->ptax_propery.'</span>
							      <span style="font-size:10px;">('.$vtxdet->tax_percentage.'%)</span>'.$txamt.'<span style="font-size:10px;"> Rs</span></br> ';	
								}
								
							}
							$discamt=0;
							$asum=0;
							
							
							foreach($txpropamt as $k=>$v){
								
								if($k==$vdet->item_id){
								$asum=	array_sum($txpropamt[$k]);
							
								$discamt=abs((($vdet->gross_amount*$vdet->qty)+$asum)-$vdet->net_amount);
								}
							}
						//	var_dump($asum);
					
							
                 			$html.='</td><td style="text-align:left;" ><span style="font-size:10px;">('.$vdet->item_discount.'% )</span>'.$discamt.'</td><td style="text-align:left;" >'.$vdet->net_amount.' </td></tr>';
					$c++;
				}		
				
				
			$html.='<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td style="width:20px;text-align:center;">'.$totalamt.'</td>';
			
			$html.='<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>Gross Amt</td><td style="width:20px;text-align:center;">'.$totalgrossamt.'</td>';
			
		
					
				//	$html.='<td>&nbsp;</td><td style="width:20px;text-align:center;">'.$txpropval.'</td>';
			foreach($txpropamt as  $k0=>$v0){
				 echo json_encode(array_column($txpropamt,$k0));
				
			//$html.='<td>&nbsp;</td><td style="width:20px;text-align:center;">'.$k0.'</td>';
			}
			
			
			var_dump($txpropamt);
			$html.='</tr>';	
             $html.=  '</tbody>
                    </table>';	
				
			
			
			}
		
		
		echo $html;	*/
