<?php
class Employeecollection_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function getemployee(){
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_salesmanreg')->result();

		
		}
	public function getcategory()
	{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		    $this->db->where($array);
		    $this->db->select('*');
		    return $rows=$this->db->get('tbl_category')->result();

	}
	
	
	public function empvicecollection()
	{
		         $from=$this->input->post('txtfrm');
	             $to=$this->input->post('txtto');
				 $emp=$this->input->post('selsalesman');
	 
	 			 $array=array('tbl_payment_details.status'=>0,'tbl_payment_details.org_id'=>$this->session->userdata('org_id'),'tbl_payment_details.created_date >='=>$from,'tbl_payment_details.employee_id'=>$emp,'tbl_payment_details.created_date <='=>$to);
	 			 $this->db->where($array);
			
				 $this->db->select('tbl_payment_details.payment_mode,tbl_payment_details.payment_type,tbl_payment_details.p_amount,tbl_salesmanreg.name,tbl_payment_details.invoice_id,tbl_payment_details.created_date,tbl_merchant.merchantname,');
			     $this->db->from('tbl_payment_details');
				 $this->db->join('tbl_salesmanreg','tbl_payment_details.employee_id=tbl_salesmanreg.salesmanid');
				 $this->db->join('tbl_merchant','tbl_payment_details.merchant_id=tbl_merchant.merchant_id');
				
					$result=$this->db->get();
       				$rows=$result->result();
			
			
				$html='';
				$total=0;
				$i=1;
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						
					foreach($rows as $val =>$key)
					{ 
					    $total=$total+$key->p_amount;
						$type="";
						if($key->payment_type==1)
						{
							$type="Cash";
						}
						else{
							$type="Cheque";
						}
							$payment_mode="";
							
							if($key->payment_mode==1)
						{
							$payment_mode="one Time Settlment";
						}
						else if($key->payment_mode==2){
							$payment_mode="Part Time Settlment";
							}
							else{ 	$payment_mode="Part Time Settlment";
								}
						
						$html.='<tr><td>'.$i.'</td>';
						/*$html.='<td>'.$key->invoice_id.'</td>';*/
						$html.='<td>'.$key->merchantname.'</td>';
						$html.='<td> Sales </td>';
						$html.='<td>'.$type.'</td>';
						
						$html.='<td>'.$key->created_date.'</td>';
						$html.='<td>'.$key->p_amount.'</td></tr>';
						$i=$i+1;
					}
			
					  /*  $html.='<td></td>';
						$html.='<td></td>';
					    $html.='<td></td>';
						$html.='<td>Total Amount</td>';
						$html.='<td>'.$total.'</td>';*/
						
				}/*else{
					$html.='<td>-- No result  --</td>';
						}*/
						
						
					$html1='';	
						
					 $array1=array('tbl_cashcollect.status'=>0,'tbl_cashcollect.org_id'=>$this->session->userdata('org_id'),'tbl_cashcollect.create_date >='=>$from,'tbl_cashcollect.salesman_id'=>$emp,'tbl_cashcollect.create_date <='=>$to);
	 			 $this->db->where($array1);
			
				 $this->db->select('tbl_cashcollect.type,tbl_cashcollect.amount,tbl_salesmanreg.name,tbl_cashcollect.create_date,tbl_merchant.merchantname');
			     $this->db->from('tbl_cashcollect');
				 $this->db->join('tbl_salesmanreg','tbl_cashcollect.salesman_id=tbl_salesmanreg.salesmanid');
				 $this->db->join('tbl_merchant','tbl_cashcollect.merchant_id=tbl_merchant.merchantid_num');
				
					$result1=$this->db->get();
       				$rows1=$result1->result();		
						$total1=$total;
					
						if($result1->num_rows()>0){
							
					
					foreach($rows1 as $val1=>$key1)
					{ 
					    $total1=$total1+$key1->amount;
						$type="";
						if($key1->type==1)
						{
							$type="Cash";
						}
						else{
							$type="Cheque";
						}
					
						
						$html1.='<tr><td>'.$i.'</td>';
						/*$html.='<td>'.$key->invoice_id.'</td>';*/
						$html1.='<td>'.$key1->merchantname.'</td>';
						$html1.='<td> Credit </td>';
						$html1.='<td>'.$type.'</td>';
						
						$html1.='<td>'.$key1->create_date.'</td>';
						$html1.='<td>'.$key1->amount.'</td></tr>';
						$i=$i+1;
					}
				
						
							
							}
						
						
						if($html.$html1==''){
							$html.='<td> No result  </td>';
							echo $html;
							}
							else{
						 $html1.='<tr><td></td>';
						$html1.='<td></td>';
					    $html1.='<td></td>';
						 $html1.='<td></td>';
						$html1.='<td>Total Amount</td>';
						$html1.='<td>'.$total1.'</td></tr>';	
							echo $html.$html1;
							}
		
		
		}
	

		

		
}