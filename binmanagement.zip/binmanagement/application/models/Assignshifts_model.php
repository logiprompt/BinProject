<?php
class Assignshifts_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getshifts()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_shifts')->result();
		}
		public function getemployee(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_authreg.name,tbl_authreg.empid');
			return $rows=$this->db->get('tbl_authreg')->result();
			}
		public function getmainmarketing()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('en_id');
		return $rows=$this->db->get('tbl_enquiry')->result();
		}
		
		public function shiftreg()
		{
		  	$max=maxplus('tbl_shifts','shift_id');	
		    $today=date('Y-m-d');
			$data= array(
			   'org_id'=>$this->session->userdata('org_id'),
			   'shift_id' =>$max,
 			   'emp_name'=>$this->input->post('selEmpname'),
			   'emp_id'=>$this->input->post('selEmpId'),
			   'date_from'=>$this->input->post('datefrm'),
			   'date_to'=>$this->input->post('dateto'),
			   'time_from'=>$this->input->post('selTfrm'),
			   'time_to'=>$this->input->post('selTto'),
			   'crea_date'=>$today,
			   'mod_date'=>$today
			);
			$this->db->insert('tbl_shifts',$data);	
		}
		public function deleteShift(){
		   $aid=$this->input->post('id');
		   $mid=decode($aid);
		   $data=array('status'=>1);
		   $array= array('shift_id'=>$mid);
		   $this->db->where($array);
		   $this->db->update('tbl_shifts',$data);	
			
		}
		public function editDetails($aid){ 
		    $id=$aid;
			$array=array('status'=>0,'shift_id'=>$id);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_shifts');
       		return $rows=$result->row();
		}
		public function updateshift(){
		    $id=$this->input->post('hdnId');
		    $today=date('Y-m-d');
			$data= array(
   			   'emp_name'=>$this->input->post('selEmpname'),
			   'emp_id'=>$this->input->post('selEmpId'),
			   'date_from'=>$this->input->post('datefrm'),
			   'date_to'=>$this->input->post('dateto'),
			   'time_from'=>$this->input->post('selTfrm'),
			   'time_to'=>$this->input->post('selTto'),
			   'crea_date'=>$today,
			   'mod_date'=>$today
			);
			$array=array('org_id'=>$this->session->userdata('org_id'),'shift_id'=>$id);
			$this->db->where($array);
		    $this->db->update('tbl_shifts',$data);
		
		}
		public function insertnew(){
			$max=maxplus('tbl_enquiry_status','enquiry_status_id');	
		    $today=date('Y-m-d');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			   'enquiry_status_id' =>$max,
		       'status_name'=>$this->input->post('sname'),
			    'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			   );
			   	$this->db->insert('tbl_enquiry_status',$data);
			}
			
			public function getnewstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select  id="status" name="status" style="display:block;" ><option value="0" >Select Status</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->enquiry_status_id.' ">'.$val->status_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
				public function getstatus()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_enquiry_status');
				return $res= $rows->result();
		}
		
		public function changevwstatus()
		{
			
		
		$enqid=decode($this->input->post('vid'));
		
		$array=array('status'=>0,'en_id'=>$enqid);
		$data=array('view_status'=>1);
		$this->db->where($array);
		
		$this->db->update('tbl_enquiry',$data);
		}
}