<?php
class Bank_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
		public function getbankname(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $result=$this->db->get('tbl_bank')->result();
		}
	//Adding New Bank name
	public function addbank(){
		$exist=fieldexist('tbl_bank','b_bname',$this->input->post('txtbankname'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
		echo 1;
		}
		else{
			$max=maxplus('tbl_bank','b_uid');
			$today= date("y-m-d");
			$bank=$this->input->post('txtbankname');
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
				   'b_uid'=>$max,
				   'b_bname'=>$bank,
				   'b_created_date'=>$today,
				   'b_modify_date'=>$today
			);
			$this->db->insert('tbl_bank',$data);
			}
			//echo 2;
	}
	//GET Bank Details for edit
	public function getbdetails(){
		$eid=decode($this->input->post('eid'));
		$array=array('b_uid'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->select('b_bname');
		$rows=$this->db->get('tbl_bank')->row();
		 echo $rows->b_bname;
	}
	//UPDATE BANK Name
	public function updatebank(){
		$eid=decode($this->input->post('eid'));
		$bankname=$this->input->post('bankname');
		$data=array('b_bname'=>$bankname);
		$array=array('b_uid'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_bank',$data);
		 echo 1;
	}
	public function deletebank(){
		 $delid=decode($this->input->post('id'));
		 $data=array('status'=>1);
		 $array= array('b_uid'=>$delid);
		 $this->db->where($array);
		 $this->db->update('tbl_bank',$data);
	}
	//selecting all bank names - ajax
		public function getbank(){
			$array=array('status'=>0);
			$this->db->where($array);
			$this->db->select('*');
			$result=$this->db->get('tbl_bank');
			$res=$result->result();
				if($result->num_rows()>0)
				{
					$html='';
					$i=1;
					foreach($res as $val =>$key){
						$html.='<tr><td style="width:20px;text-align:center;">'.$i.'</td>';
						$html.='<td>'.$key->b_bname.'</td>';
						$html.='<td style="width:75px"><a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan btnedit"  data-id="'.encode($key->b_uid).'"><i class="material-icons">mode_edit</i></a>';
						$html.='<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="'.encode($key->b_uid).'" href="#"><i class="material-icons">delete</i></a></td>';
						$html.=' </tr>';	
						$i=$i+1;
					}
					echo $html;
				}
				
		}

		
		
		
		
		
/*____________________________________________________________________________________________________________*/		
		
	//fetch &  update bank Name	
/*	public function editbank($id){
		$tid=$id;
		$array=array('bank_id'=>$tid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_bank')->row();
	}		
	public function deletebank(){
		 $did=$this->input->post('id');
		 $data=array('status'=>1);
		 $array= array('bank_product_id'=>$did);
		 $this->db->where($array);
		 $this->db->update('tbl_bank',$data);
	}
		
	public function getdetails()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('bank_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->select('bank_name');
		$rows=$this->db->get('tbl_bank')->row();
		 echo $rows->bank_name;
	}	
*/
}