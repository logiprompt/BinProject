<?php
class Tax_propertymodel extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	//selecting all tax names
		public function gettax(){
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_tax')->result();
		}
	//Adding Sub Tax Name
	public function addsubtax()
	{
	/*$exist=fieldexist('tbl_taxpropery','ptax_taxid',$this->input->post('ptax_taxid'));
		if($exist==1){
		echo 1;
		}
		else{*/
			$taxid=decode($this->input->post('selcat'));
			$today= date("y-m-d");
			//  $html=array();
			$delid=array('ptax_taxid'=>$taxid);
			$this->db->where($delid);
			$this->db->delete('tbl_taxpropery');
			foreach($this->input->post('txtproperty') as $datavalue){	
			$max=maxplus('tbl_taxpropery','ptax_id');
				$data= array(
				'org_id'=>$this->session->userdata('org_id'),
				   'ptax_u_id'=>$max,
				   'ptax_taxid'=>$taxid,
				   'ptax_propery'=>$datavalue,
				    'status'=>0,
				   'created_date'=>$today,
				   'modify_date'=>$today
			   );
			 //  echo json_encode($data);
			$this->db->insert('tbl_taxpropery',$data);
			 // array_push($html,$datavalue);
			
			}

			//}	
}
	public function seltaxproperty()
	{
			$id=decode($this->input->post('catid'));
			$array=array('ptax_taxid'=>$id,'status'=>0);
			$this->db->where($array);
			$this->db->select('*');
       		$result=$this->db->get('tbl_taxpropery');
       		$rows=$result->result();
			$html='';
				if($result->num_rows() > 0)
				{
				foreach($rows as $val =>$key)
					{
				$html.='<div class="input-field col s10 dynamicaddfield" aria-controls="">';
				$html.='<input  class="form-control txtproperty" placeholder="Enter Property name" value="'.($key->ptax_propery).'" id="txtproperty" name="txtproperty[]" type="text" >';
            	$html.='<a class="removeDynamicfield"><i class="material-icons">close</i></a>';
           		$html.=' </div><div class="clearfix"></div>';
					}
				}else{
					//$html.='no value'; 
						}
			echo $html;	
		}


		
		
		
		
		
/*____________________________________________________________________________________________________________*/		
}