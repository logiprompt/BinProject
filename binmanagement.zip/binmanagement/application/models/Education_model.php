<?php
class Education_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function geteducation()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_education')->result();
		}
		
		public function addeducation(){
		$exist=fieldexist('tbl_education','educationname',$this->input->post('ename'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
			echo 1;
		}else{
			$max=maxplus('tbl_education','education_id');
		 	$today= date("y-m-d");
			$eduname=$this->input->post('ename');
			
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'education_id' =>$max,
		    'educationname'=>$eduname,
			'create_date'=>$today,
			'modify_date'=>$today
		);
		
		$this->db->insert('tbl_education',$data);
		}	
		}
public function getdetails()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('education_id'=>$eid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('educationname');
		$rows=$this->db->get('tbl_education')->row();
		$a=array('name'=>$rows->educationname);
		 echo json_encode($a);
	}	
	
	public function updateedu()
	{
		$eid=decode($this->input->post('eid'));
		$txtpname=$this->input->post('txtpname');
		$data=array('educationname'=>$txtpname);
		$array=array('education_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_education',$data);
		// echo 1;
	}		

		public function deleteedu(){ 
		 	$cid=$this->input->post('id');
		   $data=array('status'=>1);
		   $array= array('education_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_education',$data);
		}
}