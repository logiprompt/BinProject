<?php
class Brand_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getbrand()
		{
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('man_id');
		return $rows=$this->db->get('tbl_brand')->result();
		}
		
		public function addbrand()
		{
			
			$exist=fieldexist('tbl_brand','man_title',$this->input->post('txtbrand'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 1;
	}else{
			$max=maxplus('tbl_brand','man_id');
				$orgid=$this->session->userdata('org_id');
		$today= date("y-m-d");
		$brand=$this->input->post('txtbrand');
		$data= array(
			'man_id' =>$max,
			'org_id'=>$orgid,
		       'man_title'=>$brand,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		$this->db->insert('tbl_brand',$data);
		}
		}	
		public function editbrand($id){
			$cid=decode($id);
				$array=array('man_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->row();
			}
			
			public function updatebrand()
			{
				$cid=decode($this->input->post('txthiden'));
				$today= date("y-m-d");
		$category=$this->input->post('txtbrand');
				   $data=array(
				    'man_title'=>$category,
			   'created_date'=>$today,
			   'modified_date'=>$today
				   
				   
				   );
		   $array= array('man_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_brand',$data);
		   echo $cid;
			}
			
			  public function deletebrand()
			  {
		 	$cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('man_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_brand',$data);
		   }
	
}