<?php
class Merchant_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	public function getmerchant()
		{
			//tbl_merchantproduct.merchant_id,tbl_merchantproduct.merchant_product,tbl_merchantproduct.merchant_product_id,tbl_product.product_id,tbl_product.product_name'
			$array=array('tbl_merchant.status'=>0,'tbl_merchant.org_id'=>$this->session->userdata('org_id'));
		 $this->db->where($array);
	    $this->db->group_by('tbl_merchant.merchant_id');
		$this->db->select('tbl_merchant.*,tbl_area.area_id,tbl_area.area_name');
		$this->db->from('tbl_merchant');
			//$this->db->join('tbl_merchantproduct as tbl_merchantproduct', 'tbl_merchant.merchant_id=tbl_merchantproduct.merchant_id');
		//$this->db->join('tbl_product as tbl_product', 'tbl_merchantproduct.merchant_product=tbl_product.product_id');
		$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_merchant.location' );
		return $result = $this->db->get()->result(); 
			
			}
			public function getproduct()
			{
			$array=array('tbl_product.status'=>0,'tbl_product.org_id'=>$this->session->userdata('org_id'));
		     $this->db->where($array);
		     $this->db->select('tbl_product.*,tbl_merchantproduct.merchant_product');
		     $this->db->from('tbl_product');
			$this->db->join('tbl_merchantproduct as tbl_merchantproduct', 'tbl_merchantproduct.merchant_product=tbl_product.product_id');
		    return $rows=$this->db->get()->result();
			}
	public function getmerchantid()
		{
			$array=array('status'=>0);
		    $this->db->where($array);
		     $this->db->select_max('merchant_id');
		      return $result = $this->db->get('tbl_merchant')->row(); 
			}
		public function getsubcategory()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		    $this->db->where($array);
		    $this->db->select('*');
		    return $rows=$this->db->get('tbl_subcategory')->result();
		}
		public function getproducts($id)
		{
			$array=array('status'=>0,'subcat_id'=>$id);
		    $this->db->where($array);
		    $this->db->select('*');
		     return $rows=$this->db->get('tbl_product')->result();
		}
		public function getterminal($mid)
			{
			$array=array('tbl_terminal.status'=>0,'tbl_terminal.merchantid_num'=>$mid);
		    $this->db->where($array);
		    $this->db->select('tbl_terminal.*');
		//$this->db->from('tbl_product');
		//	$this->db->join('tbl_merchantproduct as tbl_merchantproduct', 'tbl_merchantproduct.merchant_product=tbl_product.product_id');
		    return $rows=$this->db->get('tbl_terminal')->result();
			}
		/*public function getproducts()
		{
			$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_product')->result();
		}*/
		public function getarea()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_area')->result();
		}
	public function getcategory()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_category')->result();
			}
			
        public function  merchantadd()
		{
			$exist=fieldexist('tbl_merchant','phoneno',$this->input->post('txtphone'),'org_id',$this->session->userdata('org_id'));
	        if($exist==1){
		     echo 1;
	     }
	       else
	     {
		$max=maxplus('tbl_merchant','merchant_id');
		$today= date("y-m-d");
		$auth=$this->input->post('selAuth');
		$person=$this->input->post('txtauthor');
		$authorised_person=$auth.$person;
		$merchantname=$this->input->post('txtmerchantname');
		$txtmerchantid=$this->input->post('txtmerchantid');
		$address=$this->input->post('address');
		$phoneno=$this->input->post('txtphone');
		$designation=$this->input->post('txtdesg');
		$location=$this->input->post('area');
		$lat=$this->input->post('latitude');
		$long=$this->input->post('longitude');
		$credit=$this->input->post('credit');
		$date=$this->input->post('date');
		$gst=$this->input->post('txtgst');
		$mobile=$this->input->post('txtlandphone');
		$txttaxtype=$this->input->post('txttaxtype');
		$txtbankname=$this->input->post('txtbankname');
		$txtaccountname=$this->input->post('txtaccountname');
		$txtaccountno=$this->input->post('txtaccountno');
		$txtifsccode=$this->input->post('txtifsccode');
		//$logo=$this->input->post('logofile');
		//$image=$this->input->post('imgfile'); 
		
		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('logofile')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$dataimg['upload_data']['file_name'];
			
			$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path2='./uploads/'.$dataimg['upload_data']['file_name'];
		
		//$numofterminals=$this->input->post('numofterminals');
		//$terminalid=$this->input->post('terminalid');
		//foreach($this->input->post('terminalid') as $tid)
		$data= array(
		'org_id'=>$this->session->userdata('org_id'),
		       'merchant_id'=>$max,
			   'merchantname'=>$merchantname,
			    'merchantid_num'=>$txtmerchantid,
				'numofterminals'=>'',
			    'address'=>$address,
			   'phoneno'=>$phoneno,
			   'authorised_person'=>$authorised_person,
			   'designation'=>$designation,
			    'latitude'=>$lat,
				 'longitude'=>$long,
				 'creditlimit'=>$credit,
				 'dates'=>$date,
				 'mer_land_phone'=>$mobile,
				 'logo'=>$path,
				 'image'=>$path2,
				 'gst_reg'=>$gst,
			   'location'=>$location,
			   'tax_type'=>$txttaxtype,
			   
			    'bank_name'=>$txtbankname,
				'account_name'=>$txtaccountname,
				'account_no'=>$txtaccountno,
				'ifsc_code'=>$txtifsccode,
				   
			   'create_date'=>$today,
			   'modify_date'=>$today,
			   'status'=>0
		);
		
		$this->db->insert('tbl_merchant',$data);
	/*	$today= date("y-m-d");
		$txtmerchantid=$this->input->post('txtmerchantid');
		//$terminalid=$this->input->post('terminalid');
		
		foreach($this->input->post('terminalid') as $tid){
			$max=maxplus('tbl_terminal','terminalid');
		$data= array(
		
		       'terminalid'=>$max,
			    'merchantid_num'=>$txtmerchantid,
				'terminalid_num'=>$tid,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_terminal',$data);
		}*/
		}
	}
	public function editmerchant($id)
		{
			$id=decode($id);
			$array=array('merchant_id'=>$id,'status'=>0);
		     $this->db->where($array);
		     $this->db->select('*');
		    return $rows=$this->db->get('tbl_merchant')->row();
			}	
				
			public function updatemerchant()
				{
			  if($this->input->post('phone')!=$this->input->post('txtphone')){
			
		 		$exist=fieldexist('tbl_merchant','phoneno',$this->input->post('txtphone'),'org_id',$this->session->userdata('org_id'));
			}
			else{
				$exist=0;
				}
	         if($exist==1){
		      echo 1;
	         }
		
	else{
			
		$id=decode($this->input->post('txthiden'));
		$today= date("y-m-d");
		$txtmerchantid=$this->input->post('txtmerchantid');
		$merchantname=$this->input->post('txtmerchantname');
		$address=$this->input->post('address');
		$phoneno=$this->input->post('txtphone');
		$gst=$this->input->post('txtgst');
		$mobile=$this->input->post('txtlandphone');
		$authorised_person=$this->input->post('txtauthor');
		$designation=$this->input->post('txtdesg');
		$location=$this->input->post('area');
		$lat=$this->input->post('latitude');
		$long=$this->input->post('longitude');
		$credit=$this->input->post('credit');
		$date=$this->input->post('date');
		
		if($_FILES['imgfile']['name']!=''&&$_FILES['logofile']['name']!=''){
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('logofile')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$dataimg['upload_data']['file_name'];
			
			$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path2='./uploads/'.$dataimg['upload_data']['file_name'];
		
		
		$data= array(
			
			   'merchantname'=>$merchantname,
			    'merchantid_num'=>$txtmerchantid,
			    'address'=>$address,
			   'phoneno'=>$phoneno,
			   'authorised_person'=>$authorised_person,
			   'designation'=>$designation,
			   'location'=>$location,
			    'latitude'=>$lat,
				 'longitude'=>$long,
				 'creditlimit'=>$credit,
				 'dates'=>$date,
				 'gst_reg'=>$gst,
				 'mer_land_phone'=>$mobile,
				 'logo'=>$path,
				 'image'=>$path2,
			   'create_date'=>$today,
			   'modify_date'=>$today,
			   'status'=>0
			   		);   
		}
		else
		{
				$data= array(
			   'merchantname'=>$merchantname,
			    'merchantid_num'=>$txtmerchantid,
			    'address'=>$address,
			   'phoneno'=>$phoneno,
			   'authorised_person'=>$authorised_person,
			   'designation'=>$designation,
			   'location'=>$location,
			    'gst_reg'=>$gst,
				'mer_land_phone'=>$mobile,
			    'latitude'=>$lat,
				 'longitude'=>$long,
				 'creditlimit'=>$credit,
				 'dates'=>$date,
			   'create_date'=>$today,
			   'modify_date'=>$today,
			   'status'=>0
			   		);   
			
		}
		   $array= array('merchant_id'=>$id);
		   $this->db->where($array);
		   $this->db->update('tbl_merchant',$data);
					
	}
				}
		public function deletemerchant()
		{
				 	$cid=decode($this->input->post('id'));
						//$mid=$this->input->post('mid');
		   $data=array('status'=>1);
		   $array= array('merchant_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_merchant',$data);
		   
		}
		
		
		
}