<?php
class Employeesale_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	public function getemployees(){
	$array=array('tbl_salesmanreg.status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_salesmanreg.*');
		    $this->db->from ( 'tbl_salesmanreg' );
			
			
			return $query = $this->db->get()->result();
		}
	
	
	
	
	
	
	public function datevicecollection(){
			$from=$this->input->post('date');
	 $to=$this->input->post('txt');
	  $emp=$this->input->post('selsalesman');
	 
	  $array=array('tbl_sales.status'=>0,'tbl_sales.org_id'=>$this->session->userdata('org_id'),'tbl_sales.created_date >='=>$from,'tbl_sales.created_date <='=>$to,'tbl_sales.employee_id'=>$emp);
	 		$this->db->where($array);
			
				$this->db->select(  'tbl_sales.total_amount,tbl_sales.created_date,tbl_merchant.merchantname,tbl_sales.order_id');
			$this->db->from('tbl_sales');
			
				$this->db->join('tbl_merchant','tbl_sales.merchant_id=tbl_merchant.merchant_id');
				
					$result=$this->db->get();
       		$rows=$result->result();
			
			$sum=0;
				$html='';
				if($result->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($rows as $val =>$keys)
					{
						$sum=$sum+$keys->total_amount;
					
						$html.='<tr><td>'.$i.'</td>';
						
						$html.='<td>'.$keys->order_id.'</td>';
						$html.='<td>'.$keys->merchantname.'</td>';
				$html.='<td>'.$keys->total_amount.'</td>';
						$html.='<td>'.$keys->created_date.'</td></tr>';
						
						$i=$i+1;
					}
					
						$html.='<td></td>';
						$html.='<td></td>';
						$html.='<td>Total Amount</td>';
						$html.='<td>'.$sum.'</td>';
						$html.='<td></td>';
					
				}else{
					$html.='<td>-- No result  --</td>';
						}
			echo $html;
		
			
			
			
		}
		
		
		}
	