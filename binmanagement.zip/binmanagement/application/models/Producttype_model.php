<?php
class Producttype_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function getproducttype()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_product_type')->result();
		}
		
		public function addproducttype(){
			$max=maxplus('tbl_product_type','pro_type_id');
		$today= date("y-m-d");
		$pro_type_name=$this->input->post('pro_type_name');
		$pro_type_per=$this->input->post('pro_type_per');
		$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'pro_type_id' =>$max,
		    'pro_type_name'=>$pro_type_name,
			'pro_type_percentage'=>$pro_type_per,
			'created_date'=>$today,
			'modified_date'=>$today
		);
		$this->db->insert('tbl_product_type',$data);
			
		}
public function getdetails()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('pro_type_id'=>$eid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('pro_type_name,pro_type_percentage');
		$rows=$this->db->get('tbl_product_type')->row();
		$a=array('name'=>$rows->pro_type_name,'per'=>$rows->pro_type_percentage);
		 echo json_encode($a);
	}	
	
	public function updateproducttype()
	{
		$eid=decode($this->input->post('eid'));
		$txtpname=$this->input->post('txtpname');
		$txtpper=$this->input->post('txtpper');
		$data=array('pro_type_name'=>$txtpname,'pro_type_percentage'=>$txtpper);
		$array=array('pro_type_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_product_type',$data);
		 echo 1;
	}		
	//Delete Product incom	
		public function deleteproducttype(){
		 	$cid=$this->input->post('id');
		   $data=array('status'=>1);
		   $array= array('pro_type_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_product_type',$data);
		}
}