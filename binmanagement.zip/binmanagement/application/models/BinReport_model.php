<?php
class BinReport_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	/*public function addsalesreport(){
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('salesmanid')->result();

		
		}*/
	public function getReport(){
		
	 $from=$this->input->post('txtfromdate');
	 $to=$this->input->post('txttodate');
	/* $from="2021-04-21";
	 $to="2021-04-30";*/
     $newfDate = date("y-m-d", strtotime($from)); 
	 $newtDate = date("y-m-d", strtotime($to)); 
     //echo "New date format is: ".$newDate. " (MM-DD-YYYY)";  
	 //echo $newDate;
     
	 $orgid=$this->session->userdata('org_id');
	 
	 $array=array('tbl_bin.status'=>0,'tbl_bin.org_id'=>$orgid,'tbl_bin.bin_date >='=>$newfDate,'tbl_bin.bin_date <='=>$newtDate);
		$this->db->where($array);
		//$this->db->select('*');
	   //$rows=$this->db->get('tbl_sales_details')->result();
	   // $this->db->select('*');
	   
	   
	   $this->db->select('tbl_bin.pro_id,tbl_bin.bin_date,tbl_bin.sub_id,tbl_bin.cat_id,tbl_category.cat_name,tbl_subcategory.subcat_name,tbl_product.product_name,tbl_product.mrp');
	   $this->db->from('tbl_bin');
	   $this->db->join('tbl_category','tbl_category.category_id=tbl_bin.cat_id');
	   $this->db->join('tbl_subcategory','tbl_subcategory.subcategory_id=tbl_bin.sub_id');
	   $this->db->join('tbl_product','tbl_product.product_id=tbl_bin.pro_id');
	   $r=$this->db->get();	
	   $result=$r->result();
	   $totamt=0;
	   $html='';
				if($r->num_rows() > 0)
				{
						//$html.='<td></td>';
						$i=1;
					foreach($result as $key)
					{
						$bindate= date("d-m-y", strtotime($key->bin_date));	
						$totamt=$totamt+$key->mrp;
						$html.='<tr><td>'.$i.'</td>';
						$html.='<td>'.$bindate.'</td>';
						$html.='<td>'.$key->product_name.'</td>';
						
						$html.='<td>'.$key->cat_name.'</td>';
						$html.='<td>'.$key->subcat_name.'</td>';
						$html.='<td>'.$key->mrp.'</td></tr>';
						
						$i=$i+1;
					}
					
					    $html.='<td></td>';
						$html.='<td></td>';
						$html.='<td></td>';
						$html.='<td></td>';
						$html.='<td style="font-weight:bold;color:red;">Total loss amount</td>';
						$html.='<td style="font-weight:bold;color:red;">'.$totamt.'</td>';
					
				}else{
					$html.='<td>-- No result  --</td>';
						}
					$html.="<script> $('#datatable').dataTable( { pageLength: 10,
        dom: 'Bfrtip',
        buttons: ['csv', 'excel', 'pdf', 'print'],
        responsive: true} );</script>";	
						
			echo $html;
	   
	   
	      
	}

}