<?php
class Category_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getcategory()
		{
		
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->group_by('category_id');
		return $rows=$this->db->get('tbl_category')->result();
		}
		
		public function addcategory()
		{
			
						$exist=fieldexist('tbl_category','cat_name',$this->input->post('txtcategory'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 1;
	}else{
			$max=maxplus('tbl_category','category_id');
				$orgid=$this->session->userdata('org_id');
		$today= date("y-m-d");
		$category=$this->input->post('txtcategory');
		$data= array(
			'category_id' =>$max,
			'org_id'=>$orgid,
		       'cat_name'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
		$this->db->insert('tbl_category',$data);
		}
		}	
		public function editcategory($id){
			$cid=decode($id);
				$array=array('category_id'=>$cid,'status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_category')->row();
			}
			
			public function updatecategory()
			{
				$cid=decode($this->input->post('txthiden'));
				$today= date("y-m-d");
		$category=$this->input->post('txtcategory');
				   $data=array(
				    'cat_name'=>$category,
			   'create_date'=>$today,
			   'modify_date'=>$today
				   
				   
				   );
		   $array= array('category_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_category',$data);
		   echo $cid;
			}
			
			  public function deleteCategories()
			  {
		 	$cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('category_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_category',$data);
		   }
	
}