<?php
class Usergroup_model  extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function getgroup()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_usergroup');
		return $result=$this->db->get()->result();	
		}
		
		public function getgroupdetails($id)
		{
			$sid=decode($id);
		$array=array('status'=>0,'usergroup_id'=>$sid);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_usergroup');
		return $result=$this->db->get()->row();	
		}
		
		
		public function addgroup()
		{
			$exist=fieldexist('tbl_usergroup','usergroup_name',$this->input->post('group'),'org_id',$this->session->userdata('org_id'));
	if($exist==1){
		echo 'ex';
	}else{
			$max=maxplus('tbl_usergroup','usergroup_id');
			$today= date("y-m-d");
			$user=$this->input->post('group');	
			$array=array(
			'org_id'=>$this->session->userdata('org_id'),
			'usergroup_id'=>$max,
			'usergroup_name'=>$user,
			'created_date'=>$today,
			'modified_date'=>$today
			);
			$this->db->insert('tbl_usergroup',$array);
			//echo $this->db->insert_usergroup_id();
			}
		}
		public function editgroup($id)
		{
		       $groupid=decode($id);
		        $array=array('usergroup_id'=>$groupid,'status'=>0);
				$this->db->where($array);
				$this->db->select('*');
				return $rows=$this->db->get('tbl_usergroup')->row();
			}
			
			public function updategroup()
			{
					$grpid=decode($this->input->post('txthiden'));
					$user=$this->input->post('group');	
					$today= date("y-m-d");
				   	$data=array(
				   		 		'usergroup_name'=>$user,
			   					'created_date'=>$today,
			  					 'modified_date'=>$today
				  			 	);
		   			$array= array('usergroup_id'=>$grpid);
		  			 $this->db->where($array);
		   			$this->db->update('tbl_usergroup',$data);
			}
			
			  public function deletegroup()
			  {
		 	$grpid=decode($this->input->post('id'));
		       $data=array('status'=>1);
		      $array= array('usergroup_id'=>$grpid);
		      $this->db->where($array);
		      $this->db->update('tbl_usergroup',$data);
			  echo $grpid;
		   }
		   
			 public function updatepermission()
			  {
			 $id=max1('tbl_usergroup','usergroup_id',$this->session->userdata('org_id'));
		//	$id=$this->input->post('txtid');	
				  $permission=$this->input->post('txthper');	
				  
				  $today= date("y-m-d");
				   	$data=array(
				   		 		'permission'=>$permission,
			  					 'modified_date'=>$today
				  			 	);
		   			$array= array('usergroup_id'=>$id);
		  			 $this->db->where($array);
		   			$this->db->update('tbl_usergroup',$data);
				  
			  }
			   public function updatepermission2()
			  {
			
					$id=decode($this->input->post('txtid'));	
				  $permission=$this->input->post('txthper');	
				  
				  $today= date("y-m-d");
				   	$data=array(
				   		 		'permission'=>$permission,
			  					 'modified_date'=>$today
				  			 	);
		   			$array= array('usergroup_id'=>$id);
		  			 $this->db->where($array);
		   			$this->db->update('tbl_usergroup',$data);
				  
			  }
				  
}