<?php
class Smsorg_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function getallorg()
	{
	
			$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_organisation')->result();

	}
	
	public function insert()
	{
			
		$max=maxplus('tbl_sms_orgsettings','max_id');
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
		
		$category=decode($this->input->post('selcat'));
		$data= array(
			 'max_id'=>$max,
			 'org_id'=>$category,
		      'smscount'=>$subcategory,
			  'created_on'=>$today,
			   'modified_on'=>$today
		);
		$this->db->insert('tbl_sms_orgsettings',$data);
		
		
	}
       
	public function update()
			{
				$max=decode($this->input->post('hdid'));
		$today= date("y-m-d");
		$subcategory=$this->input->post('txtsubcategory');
		
		$category=decode($this->input->post('selcat'));
		$data= array(
			 'max_id'=>$max,
			 'org_id'=>$category,
		      'smscount'=>$subcategory,
			  'created_on'=>$today,
			   'modified_on'=>$today
		);
		$this->db->where('max_id',$max);
		$this->db->update('tbl_sms_orgsettings',$data);
				
				}
			
	
	
	
	
	
	
	public function getallsms()
	{
		
		$array=array('tbl_sms_orgsettings.status'=>0);
		$this->db->where($array);
		$this->db->select('tbl_sms_orgsettings.*,tbl_organisation.org_name');
		$this->db->from('tbl_sms_orgsettings');
		$this->db->join('tbl_organisation','tbl_sms_orgsettings.org_id=tbl_organisation.o_maxid');
		return $rows=$this->db->get()->result();
	}
	
	public function getdet($id)
	{
	$sid=decode($id);
			$array=array('status'=>0,'max_id'=>$sid);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_sms_orgsettings')->row();

	}
	public function delete()
	{
		$id=decode($this->input->post('id'));
		 $array= array('max_id'=>$id);
		   $this->db->where($array);
		   $this->db->delete('tbl_sms_orgsettings');
		}
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	/////////////////////////////////////////////////////////////////////////

		
		
}