<?php
class Manufacture_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        public function getmanufacture()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_manufacture')->result();
		}
		
		public function addmanufacture(){
			$max=maxplus('tbl_manufacture','manufacture_id');
		$today= date("y-m-d");
		$manu_name=$this->input->post('manu_name');
		$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'manufacture_id' =>$max,
		    'manufacture_name'=>$manu_name,
			'created_date'=>$today,
			'modified_date'=>$today
		);
		$this->db->insert('tbl_manufacture',$data);
			
		}
public function getdetails()
	{
		$eid=decode($this->input->post('eid'));
		$array=array('manufacture_id'=>$eid,'status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('manufacture_name');
		$rows=$this->db->get('tbl_manufacture')->row();
		 echo $rows->manufacture_name;
	}	
	
	public function updatemanufacture()
	{
		$eid=decode($this->input->post('eid'));
		$txtmname=$this->input->post('txtmname');
		$data=array('manufacture_name'=>$txtmname);
		$array=array('manufacture_id'=>$eid,'status'=>0);
		$this->db->where($array);
		$this->db->update('tbl_manufacture',$data);
		 echo 1;
	}		
	//Delete Product incom	
		public function deletemanufacture(){
		 	$cid=$this->input->post('id');
		   $data=array('status'=>1);
		   $array= array('manufacture_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_manufacture',$data);
		}
}