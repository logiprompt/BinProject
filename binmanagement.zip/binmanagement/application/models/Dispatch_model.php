<?php
class Dispatch_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function getcategory()
	{
			$array=array('status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_category')->result();

	}
	public function merchantsearch()
	{
		$num=$this->input->post('mer_num');
		$array=array('status'=>0,'merchantid_num'=>$num);
		$this->db->where($array);
		$this->db->select('merchant_id,merchantname,address,phoneno');
		$rows=$this->db->get('tbl_merchant')->row();

		$id=$rows->merchant_id;
		
		$array=array('status'=>0,'merchantid_num'=>$num);
		$this->db->where($array);
		$this->db->select('*');
		$rows=$this->db->get('tbl_merchant')->result();
		
		

	}
	
		
		
}