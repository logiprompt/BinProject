<?php
class Currentlocation_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
      public function getsalesman(){
		 $array=array('tbl_salesmanreg.status'=>0);
		$this->db->where($array);
		$this->db->select('*');
		$this->db->from('tbl_salesmanreg');
		return $result = $this->db->get()->result(); 
		
		}     
		public function location(){
		$sid=$this->input->post('sid');
		$array=array('tbl_currentlocation.emp_id'=>$sid);
		$this->db->where($array);
		$this->db->select('tbl_currentlocation.*');
		$this->db->from('tbl_currentlocation');
		$result=$this->db->get();
       	$rows=$result->result();
		
		$html='';
				  if(!empty($rows))
				  {		
					foreach($rows as $val =>$key)
					{
						
						$html.='<tr><td>'.$key->created_date.'</td>';
						$html.='<td>'.$key->latitude.'</td>';
						$html.='<td>'.$key->longitude.'</td>';
						$html.='<td> <a id="map" class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" lat="'.$key->latitude.'" long="'.$key->longitude.'" >
										<i class="material-icons">place</i>
									</a></td>';
					}
				}else{
					$html.='<td>- No result -</td>';
						}
						
				echo $html;		
						
		}  
		
		
}