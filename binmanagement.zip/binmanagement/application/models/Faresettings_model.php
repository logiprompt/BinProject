<?php
class Faresettings_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
        
		public function getallfare()
		{
		$array=array('tbl_fare_settings.status'=>0,'tbl_fare_settings.owner_id'=>$this->session->userdata('emp_id'));
		$this->db->where($array);
		$this->db->select('tbl_fare_settings.*,tbl_brand.*,tbl_model.*');
		$this->db->from('tbl_fare_settings');
		$this->db->join('tbl_brand','tbl_fare_settings.brand_id=tbl_brand.man_id');
		$this->db->join('tbl_model','tbl_fare_settings.model_id=tbl_model.model_id');
		return $rows=$this->db->get()->result();
		
		
		}
		
		
		public function getbrand()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_brand')->result();
		}
		public function getallmodel()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_model')->result();
		}
		
		public function getdetails($mid)
		{
			
			$array=array('tbl_fare_settings.fare_settings_id'=>$mid);
		$this->db->where($array);
		$this->db->select('tbl_fare_settings.*');
		$this->db->from('tbl_fare_settings');
		
		return $rows=$this->db->get()->row();
			
			
		}
		
		
		public function insert()
		{
		    $max=maxplus('tbl_fare_settings','fare_settings_id');	
		    $today=date('Y-m-d');
			$data= array(
			   'fare_settings_id' =>$max,
			  
			   'owner_id'=>$this->session->userdata('emp_id'),
			   'brand_id'=>decode($this->input->post('brand')),
			    'model_id'=>decode($this->input->post('model')),
			  
			  'min_charge'=>$this->input->post('mincharge'),
			   'min_charge_km'=>$this->input->post('minkm'),
			   'rate_per_km'=>$this->input->post('kmrate'),
			   'wait_time'=>$this->input->post('waittime'),
			   'after_wait_time'=>$this->input->post('afterwaittime'),
			   'after_wait_time_amt'=>$this->input->post('amount'),
			    'status'=>0,
			   'created_date'=>$today,
			   'modified_date'=>$today,
			);
			$this->db->insert('tbl_fare_settings',$data);	
			
		}
		
		
		
		
		 function get_model()
       {   
	
	$id=decode($this->input->post('brand'));
	 $arr=array('brand_id'=>$id);
	  $this->db->where($arr);
	 $res=$this->db->get("tbl_model");
	$result=$res->result();
	
		$html='';
	
	
		if($res->num_rows() > 0)
	{
		 
	$html.='<option value="0"> select model</option>';
	foreach($result as $val =>$key)
	{
	$html.='<option value="'.encode($key->model_id).'">'.$key->model_name.'</option>';
	}
	echo $html;
	}
	
	
	}
		
	public function update()
		{
		    $max=decode($this->input->post('hdid'));	
		    $today=date('Y-m-d');
			$data= array(
			
			   'brand_id'=>decode($this->input->post('brand')),
			    'model_id'=>decode($this->input->post('model')),
			  'min_charge'=>$this->input->post('mincharge'),
			   'min_charge_km'=>$this->input->post('minkm'),
			   'rate_per_km'=>$this->input->post('kmrate'),
			   'wait_time'=>$this->input->post('waittime'),
			   'after_wait_time'=>$this->input->post('afterwaittime'),
			   'after_wait_time_amt'=>$this->input->post('amount'),
			   
			   'modified_date'=>$today,
			);
			
			$this->db->where('fare_settings_id',$max);
			$this->db->update('tbl_fare_settings',$data);	
			
		}
		
		public function delete()
		  {
		   $cid=decode($this->input->post('id'));
		   $array= array('fare_settings_id'=>$cid);
		   $this->db->where($array);
		   $this->db->delete('tbl_fare_settings');	
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////
		
	



}