<?php
class Employee_model extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	
	public function addemployee()
		{
			//echo $this->input->post('eduid');
			
			
		$existphone=fieldexist('tbl_salesmanreg','phoneno',$this->input->post('phone'),'org_id',$this->session->userdata('org_id'));
		$existmail=fieldexist('tbl_salesmanreg','emp_email',$this->input->post('email'),'org_id',$this->session->userdata('org_id'));
	if($existphone==1){
		echo 1;
	}
	else if($existmail==1){
		echo 2;
		}
	else{
		
		
		$today= date("y-m-d");
		$name=$this->input->post('name');
		$address=$this->input->post('address');
		$designation=$this->input->post('designation');
		$head=$this->input->post('head');
		$blood=$this->input->post('blood');
		$fathername=$this->input->post('fname');
		$education =$this->input->post('edu');
		$qualification =$this->input->post('quali');
		$experience =$this->input->post('exp');
		$nationality=$this->input->post('ntn');
		$familytype=$this->input->post('fmlytype');
		$dateofbirth=$this->input->post('dob');
		$dateofjoin=$this->input->post('doj');
		$pfno=$this->input->post('pfuan');
		$esino=$this->input->post('esi');
		$attend=$this->input->post('atttrack');
		$starttime=$this->input->post('starttime');
		$endtime=$this->input->post('endtime');
		$phone=$this->input->post('phone');
		$gender=$this->input->post('gender');
		$area=$this->input->post('area');
		$pwd=$this->input->post('salespwd');
		$usergroup=$this->input->post('usergroup');
		$email=$this->input->post('email');
		$eduid=$this->input->post('eduid');
		$areaid=$this->input->post('areaid');
		$orgid=$this->session->userdata('org_id');
		$empuserlimit=$this->input->post('empuserlimit');
		$flag=0;	
		if($head==0){
		//totorglimit
		$arrol=array('o_maxid'=>$orgid,'status'=>0);
		$this->db->where($arrol);
		$this->db->select('user_limit');
		$this->db->from('tbl_organisation');
		$resol=$this->db->get();
		$resultol=$resol->row();
		if($resol->num_rows()>0){
			$orglimit=$resultol->user_limit;
			
			}
		//allocatedemplimit
		$arrl=array('org_id'=>$orgid,'status'=>0);
		$this->db->where($arrl);
		$this->db->select('emp_user_limit');
		$this->db->from('tbl_salesmanreg');
		$resl=$this->db->get();
		$resultl=$resl->result();
		$totl=0;
		if($resl->num_rows()>0){
			$totl=$resl->num_rows();
		foreach($resultl as $vall){
			
			$totl=$totl+$vall->emp_user_limit;
			}	
			
		}
		
		$orglimitbal=$orglimit-$totl;//org limit bal
		
		if($orglimitbal>0){
					
					if($orglimitbal<$empuserlimit  )
					{
						echo 3;
					$flag=1;	
						}
			}
			else{
				echo 4;
				$flag=1;	
				}
		}
		else{
			
			$empuserlimit=0;
				//Total employee  limit
				$arre=array('org_id'=>$orgid,'salesmanid'=>$head,'status'=>0);
				$this->db->where($arre);
				$this->db->select('emp_user_limit');
				$this->db->from('tbl_salesmanreg');
				$rese=$this->db->get();
				$resulte=$rese->row();
					if($rese->num_rows()>0){
						$totemplimit=$resulte->emp_user_limit;
					}
					
					//allocated emps
				$arrle=array('org_id'=>$orgid,'head'=>$head,'status'=>0);
				$this->db->where($arrle);
				$this->db->select('count(salesmanid) as num');
				$this->db->from('tbl_salesmanreg');
				$resle=$this->db->get();
				$resultle=$resle->row();
				$allocatedemp=$resultle->num;
				
				$empballimit=$totemplimit-$allocatedemp;//balance emp limit
					
					if($empballimit>0){
							/*if($empballimit<$empuserlimit )
							{
									echo 5;
									$flag=1;	
							}*/
						}
						else{
								    echo 6;
									$flag=1;
							}	
				}
			
		if($flag==0){
		$empcode='Emp_'.$phone;
			$max=maxplus('tbl_salesmanreg','salesmanid');
			
			
			///////////////////////////////////////Attachment////////////////////////////		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imgfile')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $dataimg = array('upload_data'=>$this->upload->data());
            }
            $path='./uploads/'.$dataimg['upload_data']['file_name'];
			
					///////////////////////////////////////Attachment////////////////////////////		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('biodata')) {
                $error = array('error'=>$this->upload->display_errors());
				//echo 201;
				//exit;
				//$this->load->view('upload_form', $error);
            } else {
            $databio = array('upload_data'=>$this->upload->data());
            }
            $pathbiodata='./uploads/'.$databio['upload_data']['file_name'];
		//echo $path;
/////////////////////////////////////////////////////////////////////////////////////////////////////
			
			
		$data= array(
				'org_id'=>$orgid,
		       'name'=>$name,
			   'emp_father_name'=>$fathername,
			   'emp_education'=>$education,
			   'emp_qualification'=>$qualification,
			   'emp_experience'=>$experience,
			   'nationality'=>$nationality,
			   'date_of_birth'=>$dateofbirth,
			   'date_of_joining'=>$dateofjoin,
			   'pf_uan_no'=>$pfno,
			   'family_type'=>$familytype,
			   'esi_no'=>$esino,
			   'attendance_tracker'=>$attend,
			   'salesmanid'=>$max,
			   'address'=>$address,
			   'designation'=>$designation,
			   'head'=>$head,
			   'bloodgroup'=>$blood,
			  'endtime'=>$endtime,
			  'starttime'=>$starttime,	
			   'phoneno'=>$phone,
			   'empcode'=>$empcode,
			   'gender'=>$gender,
			   'emp_email'=>$email,
			   'usergroup'=>$usergroup,
			    'password'=>$pwd,
				'image'=>$path,
				'biodata'=>$pathbiodata,
				'emp_user_limit'=>$empuserlimit,
			   'create_date'=>$today,
			   'modify_date'=>$today
		);
	
		$this->db->insert('tbl_salesmanreg',$data);
		
		$data= array(
			   'emp_id'=>$max,
			   'username'=>$phone,
			   'password'=>$pwd,
			   'org_id'=>$orgid,
			   'email'=>$email,
			   'usergroup'=>$usergroup,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		
	  $this->db->insert('tbl_login',$data);	
	  	$data1= explode(",",$areaid);
	 	foreach($data1	 as $v){
	 $data=array(
			   'emp_id'=>$max,
			   	'org_id'=>$orgid,
			   'area_id'=>$v,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
	   $this->db->insert('tbl_emparea',$data);
		}
	$dataedu= explode(",",$eduid);
	 	foreach($dataedu as $v){
	 $data=array(
			   'emp_id'=>$max,
			   	'org_id'=>$orgid,
			   'education_id'=>$v,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
	   $this->db->insert('tbl_emp_education',$data);
		}
		
		$maxver=maxplus('tbl_empverification','ver_id');
		
		
		$agencyname=$this->input->post('agencyname');
		$verifieddate=$this->input->post('verifieddate');
		$bckgrndveri=$this->input->post('bckgrndveri');
		
		
		
		$dataver= array(
			   'emp_id'=>$max,
			   'ver_id'=>$maxver,
			   'org_id'=>$orgid,
			   'verification'=>$bckgrndveri,
			   'agency_name'=>$agencyname,
			   'date'=>$verifieddate,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
		
		$this->db->insert('tbl_empverification',$dataver);
		
		
		}
		
	}
		}	
		
		public function getdesignation()
		{
			
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_designation');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select id="designation" name="designation" style="display:none;" ><option value="0" >Select Designation</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->desi_id.'">'.$val->desi_name.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		
		}
		public function getdesig()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_designation')->result();
		}
		
			public function geteducation1()
		{	
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'),);
				$this->db->where($array);
				$this->db->select('*');
				 $rows=$this->db->get('tbl_education');
				 $res= $rows->result();
				 $html='';
				 
				 if($rows->num_rows()>0){
					 
					 $html.='<select id="edu" name="edu" style="display:none;" ><option value="0" >Select eduaction</option>';
					foreach($res as $val){
					 $html.='<option value="'.$val->education_id.'">'.$val->educationname.'</option>	';
					}
					$html.='</select>';
					 //$html.='</select><a class="addDynamicfield btnaddunit"><i class="material-icons">add_circle</i></a>';
					 }
					
					
						 
				echo $html;
		}
		
		
		public function geteducation()
		{
			$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('*');
			return $rows=$this->db->get('tbl_education')->result();
		}
		
		
        public function getusergroup()
		{
		$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_usergroup')->result();
			
		}
	
		public function getarea()
		{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
		$this->db->where($array);
		$this->db->select('*');
		return $rows=$this->db->get('tbl_area')->result();
		}
		

		
		
		
	/*	public function getemployee()
		{
			$array=array('tbl_salesmanreg.status'=>0);
			$this->db->where($array);
			$this->db->select('tbl_salesmanreg.*,tbl_area.area_id,tbl_area.area_name,tbl_usergroup.usergroup_name');
		    $this->db->from ( 'tbl_salesmanreg' );
			$this->db->group_by('salesmanid');
			$this->db->join ( 'tbl_area as tbl_area', 'tbl_area.area_id = tbl_salesmanreg.area' );
			$this->db->join ( 'tbl_usergroup', 'tbl_usergroup.usergroup_id = tbl_salesmanreg.usergroup' );
			
			return $query = $this->db->get()->result();
    
	
		}*/
			public function getemployee()
		{
			$array=array('tbl_salesmanreg.status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_salesmanreg.*');
		    $this->db->from ( 'tbl_salesmanreg' );
			
			
			return $query = $this->db->get()->result();
    
	
		}
		public function getemployeelist()
		{
			$array=array('tbl_salesmanreg.status'=>0,'org_id'=>$this->session->userdata('org_id'));
			$this->db->where($array);
			$this->db->select('tbl_salesmanreg.*');
		    $this->db->from ( 'tbl_salesmanreg' );
			
			
			return $query = $this->db->get()->result();
    
	
		}
		
		
		   public function getemployeearea($id)
		   {
			   $id=decode($id);
			   
			  $array=array('status'=>0,'emp_id'=>$id);
			  $this->db->where($array);
			  $this->db->select('area_id');
			  $this->db->from('tbl_emparea');
			  
			   $query=$this->db->get()->result();
			  $arealist=array();
			  foreach($query as $val)
			  {
				  array_push($arealist,$val->area_id);
				  
				  }
			  return $arealist;
		
			   }
			   
			   
			   
			   public function getemployedu($id)
		   {
			   $id=decode($id);
			   
			  $array=array('status'=>0,'emp_id'=>$id);
			  $this->db->where($array);
			  $this->db->select('education_id');
			  $this->db->from('tbl_emp_education');
			  
			   $query=$this->db->get()->result();
			  $edulist=array();
			  foreach($query as $val)
			  {
				  array_push($edulist,$val->education_id);
				  
				  }
			  return $edulist;
		
		  }
		  
		  
			   
    public function getemployveri($id)
		   {
			   $id=decode($id);
			   
			  $array=array('status'=>0,'emp_id'=>$id);
			  $this->db->where($array);
			  $this->db->select('org_id,verification,agency_name,date');
			  $this->db->from('tbl_empverification');
			  
			   return $query=$this->db->get()->row();
			 
			    
		
			   }
		
		public function addeducation(){
		 
		$exist=fieldexist('tbl_education','educationname',$this->input->post('ename'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
			echo 1;
		}else{
			$max=maxplus('tbl_education','education_id');
		 	$today= date("y-m-d");
			$eduname=$this->input->post('ename');
			
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'education_id' =>$max,
		    'educationname'=>$eduname,
			'create_date'=>$today,
			'modify_date'=>$today
		);
		$this->db->insert('tbl_education',$data);
		}	
		}
		public function adddesi(){
			$exist=fieldexist('tbl_designation','desi_name',$this->input->post('dname'),'org_id',$this->session->userdata('org_id'));
		if($exist==1){
			echo 1;
		}else{
			$max=maxplus('tbl_designation','desi_id');
			$today= date("y-m-d");
			$desi_name=$this->input->post('dname');
			
			$data= array(
			'org_id'=>$this->session->userdata('org_id'),
			'desi_id' =>$max,
		    'desi_name'=>$desi_name,
			'created_date'=>$today,
			'modified_date'=>$today
		);
		$this->db->insert('tbl_designation',$data);
			
		}	   
		}	   
		
		
		  public function upemployeereg(){
			  $eid=decode($this->input->post('hidden'));
			  $existphone=0;
			  $existmail=0;
			//var_dump($id);
			$array=array('salesmanid'=>$eid,'status'=>0);
			$this->db->where($array);
			$this->db->select('phoneno,emp_email');
			
       		$res=$this->db->get('tbl_salesmanreg')->row();
			
			if($res->phoneno!=$this->input->post('phone')){
				// if($this->input->post('phone')!=$this->input->post('oldphone')){
		  
				$existphone=fieldexist('tbl_salesmanreg','phoneno',$this->input->post('phone'),'org_id',$this->session->userdata('org_id'));
			}
			if($res->emp_email!=$this->input->post('email')){
		  
				$existmail=fieldexist('tbl_salesmanreg','emp_email',$this->input->post('email'),'org_id',$this->session->userdata('org_id'));
			}
			
		if($existphone==1){
			echo 1;
			}
		else if($existmail==1){
			echo 2;
			}
					
				else{
		$orgid=$this->session->userdata('org_id');			
		$today= date("y-m-d");
		$name=$this->input->post('name');
		$address=$this->input->post('address');
		$bckverf=$this->input->post('bckgrndveri');
		$fathername=$this->input->post('fname');
		$education =$this->input->post('edu');
		$qualification =$this->input->post('quali');
		$experience =$this->input->post('exp');
		$nationality=$this->input->post('ntn');
	    $dateofbirth=$this->input->post('dob');
		$dateofjoin=$this->input->post('doj');
		$pfno=$this->input->post('pfuan');
		$agncynme=$this->input->post('agencyname');
		$veridate=$this->input->post('verifieddate');
		$esino=$this->input->post('esi');
		$attend=$this->input->post('atttrack');
		$familytype=$this->input->post('fmlytype');
		$phone=$this->input->post('phone');
		$designation=$this->input->post('designation');
        $head=$this->input->post('head');
		$blood=$this->input->post('blood');
		$starttime=$this->input->post('starttime');
		$endtime=$this->input->post('endtime');
		$gender=$this->input->post('gender');
		$area=$this->input->post('area');
		$pwd=$this->input->post('salespwd');
		$usergroup=$this->input->post('usergroup');
		$email=$this->input->post('email');
		$eduid=$this->input->post('eduid');
		$areaid=$this->input->post('areaid');
		$empuserlimit=$this->input->post('empuserlimit');
		$flag=0;	
		
		if($head==0){
		//totorglimit
		$arrol=array('o_maxid'=>$orgid,'status'=>0);
		$this->db->where($arrol);
		$this->db->select('user_limit');
		$this->db->from('tbl_organisation');
		$resol=$this->db->get();
		$resultol=$resol->row();
		if($resol->num_rows()>0){
			$orglimit=$resultol->user_limit;
			
			}
			//added emps
		$arradd=array('org_id'=>$orgid,'status'=>0);
		$this->db->where($arradd);
		$this->db->select('count(salesmanid) as addedemps');
		$this->db->from('tbl_salesmanreg');
		$resadd=$this->db->get();
		$resultadd=$resadd->row();
		
		$totl=$resultadd->addedemps;
	
		//allocatedemplimit
		$arrl=array('org_id'=>$orgid,'status'=>0,'salesmanid !='=>$eid);
		$this->db->where($arrl);
		$this->db->select('emp_user_limit');
		$this->db->from('tbl_salesmanreg');
		$resl=$this->db->get();
		$resultl=$resl->result();
		if($resl->num_rows()>0){
		foreach($resultl as $vall){
			
			$totl=$totl+$vall->emp_user_limit;
			}	
		}
			
		$orglimitbal=$orglimit-$totl;//org limit bal
	
		if($orglimitbal>0){
					
					if($orglimitbal<$empuserlimit  )
					{
						echo 3;
					$flag=1;	
						}
			}
			else{
				echo 4;
				$flag=1;	
				}
		}
		else{
			
			$empuserlimit=0;
				//Total employee  limit
				$arre=array('org_id'=>$orgid,'salesmanid'=>$head,'status'=>0);
				$this->db->where($arre);
				$this->db->select('emp_user_limit');
				$this->db->from('tbl_salesmanreg');
				$rese=$this->db->get();
				$resulte=$rese->row();
					if($rese->num_rows()>0){
						$totemplimit=$resulte->emp_user_limit;
					}
					
					//allocated emps
				$arrle=array('org_id'=>$orgid,'head'=>$head,'status'=>0,'salesmanid !='=>$eid);
				$this->db->where($arrle);
				$this->db->select('count(salesmanid) as num');
				$this->db->from('tbl_salesmanreg');
				$resle=$this->db->get();
				$resultle=$resle->row();
				$allocatedemp=$resultle->num;
				
				$empballimit=$totemplimit-$allocatedemp;//balance emp limit
					
					if($empballimit>0){
							/*if($empballimit<$empuserlimit )
							{
									echo 5;
									$flag=1;	
							}*/
						}
						else{
								    echo 6;
									$flag=1;
							}	
				}
			if($flag==0){
		$empcode='Emp_'.$phone;
							if($_FILES['imgfile']['name']!=''){
								
								///////////////////////////////////////Attachment////////////////////////////		
								$config['upload_path'] = './uploads/';
								$config['allowed_types'] = 'gif|jpg|png';
								$this->load->library('upload', $config);
								if ( ! $this->upload->do_upload('imgfile')) {
								$error = array('error'=>$this->upload->display_errors());
								//echo 201;
								//exit;
								//$this->load->view('upload_form', $error);
								} 
								else {
								$dataimg = array('upload_data'=>$this->upload->data());
								}
							$path='./uploads/'.$dataimg['upload_data']['file_name'];
							
							
								$data= array(
									   'name'=>$name,
									   'address'=>$address,
									   'phoneno'=>$phone,
									   'gender'=>$gender, 
									   'designation'=>$designation,
		  	 						   'head'=>$head,
									   'family_type'=>$familytype,
			  							'bloodgroup'=>$blood,
										 'empcode'=>$empcode,
			   							'endtime'=>$endtime,
										'starttime'=>$starttime,		
									   'emp_email'=>$email,
									   'emp_user_limit'=>$empuserlimit,
									   'usergroup'=>$usergroup,
										'image'=>$path,
									   'create_date'=>$today,
									   'modify_date'=>$today
								);
						}
						else{
								
								$data= array(
								       'name'=>$name,
									   'address'=>$address,
									   'phoneno'=>$phone,
									   'gender'=>$gender,
									    'emp_father_name'=>$fathername,
									   'emp_education'=>$education,
									   'emp_qualification'=>$qualification,
									   'emp_experience'=>$experience,
									   'nationality'=>$nationality,
									   'date_of_birth'=>$dateofbirth,
									   'date_of_joining'=>$dateofjoin,
									   'pf_uan_no'=>$pfno,
									   'esi_no'=>$esino,
									  'emp_user_limit'=>$empuserlimit,
									   'attendance_tracker'=>$attend,   
									    'designation'=>$designation,
										'family_type'=>$familytype,
			          				     'head'=>$head,
			   								'bloodgroup'=>$blood,
											 'empcode'=>$empcode,
			  							'endtime'=>$endtime,
										'starttime'=>$starttime,		
									   'emp_email'=>$email,
									   'usergroup'=>$usergroup,
									   'create_date'=>$today,
									   'modify_date'=>$today
							);
								
						}
				   $array= array('salesmanid'=>$eid);
				   $this->db->where($array);
				   $this->db->update('tbl_salesmanreg',$data);
				   
				   
				   	$data2= array(
								     //  'username'=>$phone,
									   'usergroup'=>$usergroup,
									    'email'=>$email,
									   'modified_date'=>$today
							);
							
				   $array2= array('emp_id'=>$eid);
				   $this->db->where($array2);
				   $this->db->update('tbl_login',$data2);
				   
				   $data3=array(
				   
				                
			               	    'verification'=>$bckverf,
			   					'agency_name'=>$agncynme,
			   					'date'=>$veridate,
			   					'created_date'=>$today,
			   				    'modified_date'=>$today    
	
				                );
								
				     $array2= array('emp_id'=>$eid);
				   $this->db->where($array2);
				   $this->db->update('tbl_empverification',$data3);				
				   
				 
                                $array2= array('emp_id'=>$eid);
				                 $this->db->where($array2);
				   
							    $this->db->delete('tbl_emparea');
				   
				             $this->db->where($array2);
						   
	                             	
                         	$dataedu= explode(",",$areaid);
	                        	foreach($dataedu as $v){
	                                    $data=array(
		                        	   'emp_id'=>$eid,
			                          	'org_id'=>$orgid,
			  						 'area_id'=>$v,
			   						'created_date'=>$today,
			  						 'modified_date'=>$today
										);
									 $this->db->insert('tbl_emparea',$data);
	                                     }	
										 
										 
						 $array2= array('emp_id'=>$eid);
				        $this->db->where($array2);
				   
						 $this->db->delete('tbl_emp_education');
						 
				$dataedu= explode(",",$eduid);
	 	foreach($dataedu as $v){
	 $data=array(
			   'emp_id'=>$eid,
			   	'org_id'=>$orgid,
			   'education_id'=>$v,
			   'created_date'=>$today,
			   'modified_date'=>$today
		);
	   $this->db->insert('tbl_emp_education',$data);
					}
										 
			}
		}				 
 
				 			
	  }
		  
		  public function getemployeebyid($id)
		{
			$id=decode($id);
			$array=array('tbl_salesmanreg.status'=>0,'tbl_salesmanreg.salesmanid'=>$id);
			$this->db->where($array);
			$this->db->select('tbl_salesmanreg.*');
		    $this->db->from ( 'tbl_salesmanreg' );
			return $query = $this->db->get()->row();
    
	
		}
		 public function deleteEmployee(){
		    $cid=decode($this->input->post('id'));
		   $data=array('status'=>1);
		   $array= array('salesmanid'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_salesmanreg',$data);
		   
		   $data=array('status'=>1);
		   $array= array('emp_id'=>$cid);
		   $this->db->where($array);
		   $this->db->update('tbl_login',$data);
		   
		  
		   }		
		   
		   
		
}