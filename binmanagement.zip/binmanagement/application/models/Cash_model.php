<?php
class Cash_model  extends CI_Model {
	
    public function __construct(){
        $this->load->database(); 
    }
	public function merchantsearch()
		{
			$merid=$this->input->post('mer_num');
			$data=array(
			'merchantid_num'=>$merid
			);
			 $this->db->where($data);
			 $this->db->select('*');
		   $this->db->from('tbl_merchant');
		   $res= $this->db->get();
		   $result = $res->row(); 
			
			$html='';
			if( $res->num_rows()>0){
				
					$id=$result->merchant_id;
				$array=array('status'=>0,'merchant'=>$id);
		$this->db->where($array);
		$this->db->select('*');
		$rows2=$this->db->get('tbl_opening_balance');
		$res2=$rows2->row();
			if($rows2->num_rows()>0){
			
			
			
				$mid=$result->merchantid_num;
				$this->session->set_userdata('mid',$mid);
				
			$mname=	 $result->merchantname;
			$madddress=$result->address;
			$mphone=$result->phoneno;
			$opbal=$res2->openingbalance;
			//$mid=encode($result->merchant_id);
			
			$html.='
                    <div class="card-panel">
                      <h4 class="header2">Merchant Details</h4>
                      <div class="row">
                      <div class="row">
                            <div class="input-field col s12">
                              <input placeholder=" Name" name="mer_num" id="mer_num"  type="text" value="'. $mname.'" readonly>
                              <label for="first_name" class="active"> Merchant Name</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder=" Merchant Address" name="mer_num" id="mer_num"  type="text"  value="'.$madddress.'" readonly>
                              <label for="first_name" class="active"> Merchant Address</label>
                            </div>
                          </div>
                           <div class="row">
                            <div class="input-field col s12">
                              <input placeholder=" Merchant Mobile" name="mer_num" id="mer_num"  type="text"    value="'.$mphone.'" readonly>
                              <label for="first_name" class="active"> Merchant Mobile</label>
                            </div>
                          </div>
                   
					<div class="row">
                            <input type="hidden" name="merchantid" id="merchantid" value="'.$opbal.'">
							                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action"  id="btnconfirm" style="margin-right:9px;" onclick="placeorder()">Confirm
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
						  </div>
                    </div> ';
					echo $html;
			}	
			else{
				echo 2;
				}
			}
			else{
				echo 1;
				//$html.='No Result found';
				}
			
			}
			public function getbank()
			{
				$array=array('status'=>0,'org_id'=>$this->session->userdata('org_id'));
				$this->db->where($array);
				$this->db->select('*');
				$this->db->from('tbl_bank');
				return $result=$this->db->get()->result();
			}
			public function insertcash()
			{
				
			 $max=maxplus('tbl_cashcollect','cashcollect_id'); 
			   

			 $creditbal=$this->input->post('balance');
				$amount=$this->input->post('amount');
				$username=$this->session->userdata('username');
				$mid=$this->session->userdata('mid');
				$type=$this->input->post('method');
				$cdate=$this->input->post('cdate');
				
				$this->db->where('merchantid_num',$mid);
				$this->db->select('*');
				$this->db->from('tbl_merchant');
				$result=$this->db->get()->row();
				$area=$result->location;
				$chequeno=$this->input->post('check');
				$bank=$this->input->post('bank');
				$date=$this->input->post('datepicker');
				$today=date("y-m-d");
				$time=date("H:i:s");
			
				if($type==1){
				$array=array(
				'org_id'=>$this->session->userdata('org_id'),
				'cashcollect_id'=>$max,
				'salesman_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$mid,
				'terminal'=>'',
				'area_id'=>$area,
				'amount'=>$amount,
				'type'=>$type,
				'status'=>0,
				'create_time'=>$time,
				'create_date'=>$today,
				'modify_date'=>$today
				);	
			$this->db->insert('tbl_cashcollect',$array);
				}
				else
				{
					$data=array(
					'org_id'=>$this->session->userdata('org_id'),
				'cashcollect_id'=>$max,
				'salesman_id'=>$this->session->userdata('emp_id'),
				'merchant_id'=>$mid,
				'terminal'=>'',
				'area_id'=>$area,
				'amount'=>$amount,
				'type'=>$type,
				'checkno'=>$chequeno,
				'bank'=>$bank,
				'branch'=>'',
				'status'=>0,
				'date'=>$cdate,
				'create_time'=>$time,
				'create_date'=>$today,
				'modify_date'=>$today
				);	
				$this->db->insert('tbl_cashcollect',$data);
				}
				
				$carr=array('merchant'=>$mid,'org_id'=>$this->session->userdata('org_id'));
				//$this->db->where('merchant',$mid);
				$array=array(
				'openingbalance'=>$creditbal,
				'create_date'=>$today,
				'modify_date'=>$today
				);
				$this->db->update('tbl_opening_balance',$array);
				
			
			$sarr=array('status'=>0,'merchantid_num'=>$mid);
			 $this->db->where($sarr);
			 $this->db->select('phoneno');
			 $sres=$this->db->get('tbl_merchant')->row();
			 $mmob=$sres->phoneno;
			
			 $msg=" Received Amount of Rs: ".$amount."  and Balance Amount is :  ".$creditbal;
			 
			sentsms($msg,$mmob);	
			//	echo $msg;
				
				
			}
			
}











