<style>
  .addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
				  a .remove{cursor:pointer !important;}a .addmore{cursor:pointer !important;}
				   a .remove1{cursor:pointer !important;}a .addmore1{cursor:pointer !important;}
				  </style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l12">
                <div class="card-panel">
				<h4 class="header2">Service Amenity </h4>
                  <div class="row">
                  <!--FORM PRODUCT ADD-->
                   <form role="form" action="" name="frmzehal" id="frmzehal">
                    <!--Product Type-->
                   
                 <div class="row"> 
                  <div class="input-field col s12 m6 l6">
                               <input  class="form-control confirm-chr" data-handel="allow-input-chr-field" title="input-field-role-for-product-name" value="<?php if(isset($am[0])){ echo $am[0]->amenity_title;}?>" spellcheck="false" id="txtgeneral" name="txtgeneral" type="text" >
                              <label for="email">General Title </label>
                       </div>
                        <div class="input-field col s12 m6 l6">
                               <input value="<?php if(isset($am[0])){echo $am[0]->Item_title;}?>" class="form-control confirm-chr" data-handel="allow-input-chr-field" title="input-field-role-for-product-name" spellcheck="false" id="txtitem" name="txtitem" type="text" >
                              <label for="batch">Item Title</label>
                       </div>
                       </div>
                          <div class="row">
                          
                           <div class="col s6 m6 l6 general">
                            <?php if($amenity){ $j=1; $c1=count($amenity); foreach($amenity as $val){ ?>
                           <div class="div1">
                          <div class="input-field col s11 m11 l11">
                           <input  class="form-control" value="<?php echo $val->titles?>" spellcheck="false" id="general_title" name="general_title[]" type="text" >				<label for="pcode">Title </label>
                             </div> 
                             <div  class="input-field col s1 m1 l1">
                       <?php if($j==$c1){ ?> <a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a><?php } else{ ?><a class="btnplus" style="right:12px"><i class="material-icons remove">cancel</i></a><?php } ?>
                        </div></div>
                        <?php $j++; }}else{ ?><div class="div1">
                          <div class="input-field col s11 m11 l11">
                           <input  class="form-control" value="" spellcheck="false" id="general_title" name="general_title[]" type="text" >				<label for="pcode">Title </label>
                             </div> 
                             <div  class="input-field col s1 m1 l1">
                       <a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a>                        </div></div><?php } ?>
                             </div> 
                             
                             
                             
                             <div class="col s6 m6 l6 item">
                             <?php if($item){ $i=1; $c=count($item); foreach($item as $val){ ?>
                           <div class="div2">
                          <div class="input-field col s11 m11 l11">
                           <input  class="form-control" value="<?php echo $val->titles?>" spellcheck="false" id="Item_title" name="Item_title[]" type="text" >				<label for="pcode">Title </label>
                             </div> 
                             <div  class="input-field col s1 m1 l1">
                       <?php if($i==$c){ ?> <a class="btnplus" style="right:12px"><i class="material-icons addmore1">add_circle</i></a><?php } else{ ?><a class="btnplus" style="right:12px"><i class="material-icons remove1">cancel</i></a><?php }?>
                        </div></div>
                        <?php $i++; }} else{ ?>
                        
                        <div class="div2">
                          <div class="input-field col s11 m11 l11">
                           <input  class="form-control" value="" spellcheck="false" id="Item_title" name="Item_title[]" type="text" >				<label for="pcode">Title </label>
                             </div> 
                             <div  class="input-field col s1 m1 l1">
                   <a class="btnplus" style="right:12px"><i class="material-icons addmore1">add_circle</i></a>  				              
                        </div></div>
                         <?php }?>
                        
                             </div>
                        	</div>
                            
					   <div class="row">
                          <div class="input-field col s12">
                            <button  class="btn cyan waves-effect waves-light right btnsubmit" type="button" id="btnsubmit" name="action">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
              
              
              
                </div>
                
                
                
                
                
                
                
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
<div class="overlay"><div class="loadingimg"></div></div>        
        <!-- END CONTENT -->
       
<script type="text/javascript">
 $(document).ready(function(){
	 
	//////////////////////////////////////////////////////////////////////////////////////////
	 $(document).on("click",".addmore",function() {
		
        var tparent = $(this).parent();
        var rem='<i class="material-icons remove">cancel</i>';
        tparent.html(rem);
        var htm='<div class="div1"><div class="input-field col s11 m11 l11"><input  class="form-control" value="" spellcheck="false" id="general_title" name="general_title[]" type="text" ><label for="pcode">Title </label></div> <div  class="input-field col s1 m1 l1"><a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a></div></div>';

        $('.general').append(htm);
    }) 
	 
	 
	  $(document).on("click",".remove",function() {
		 // alert('delet');
       $(this).parent().parent().parent().remove();
    });
	/////////////////////////////////////////////////////////////////////////////////
 $(document).on("click",".addmore1",function() {
		
        var tparent = $(this).parent();
        var rem='<i class="material-icons remove1">cancel</i>';
        tparent.html(rem);
        var htm='<div class="div2"><div class="input-field col s11 m11 l11"><input  class="form-control"spellcheck="false" id="Item_title" name="Item_title[]" type="text" ><label for="pcode">Title</label></div><div  class="input-field col s1 m1 l1"><a class="" style="right:12px"><i class="material-icons addmore1">add_circle</i></a></div></div>';

        $('.item').append(htm);
    }) 
	 
	 
	  $(document).on("click",".remove1",function() {
		 // alert('delet');
       $(this).parent().parent().parent().remove();
    });	
	
	
	 $(document).on("click","#btnsubmit",function() {
		// alert(5);
			var e=validation();
			//alert(e);
			if(e==0){
				$('.overlay').css({'display':'flex'});
			var url="<?php echo ADMIN_PATH?>service_amenity/insert";
  			var redirect ="<?php echo ADMIN_PATH?>service_amenity";
  			var form = document.forms.namedItem("frmzehal");                        
			var oData = new FormData(document.forms.namedItem("frmzehal"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) {
					
				
				if(oReq.responseText==1){
					$('.overlay').css({'display':'none'});
					alert(' already exists');
					}

				 else{
					 $('.overlay').css({'display':'none'});
					customSwalFunD("Updated!", " Successfully Updated")
					setTimeout(function(){document.location=redirect;},500);
					 }
 					
				 	}
                oReq.send(oData);
               // ev.preventDefault();   
      
						}
   			
		 });
	
	function validation(){
		 error=0;
$('input').removeClass('err');
$('input').removeClass('errorInput');
    var values = {
                 'txtgeneral':$('#txtgeneral').val(),
					'txtitem':$('#txtitem').val(),
							 }

   if(values.txtgeneral == ''){
            $('#txtgeneral').addClass('err');
            ///$('#txtgeneral').attr("placeholder", "Please enter General title")
			$('#txtgeneral').css({'border':'1px solid red'});
		    $('#txtgeneral').addClass('errorInput');
            error=1;
        } 
		 if(values.txtitem == ''){
            $('#txtitem').addClass('err');
           /// $('#txtitem').attr("placeholder", "Please enter Item title")
			$('#txtitem').css({'border':'1px solid red'});
		    $('#txtitem').addClass('errorInput');
            error=1;
        } 
		return error;

		}
	
	 });

						
	 				
	

</script>


    
    
    
    
    
    
    

