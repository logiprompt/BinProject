<!DOCTYPE html>
<html lang="en">
  <!--================================================================================
	Item Name: Materialize - Material Design Admin Template
	Version: 4.0
	Author: PIXINVENT
	Author URL: https://themeforest.net/user/pixinvent/portfolio
================================================================================ -->
  
<!-- Mirrored from pixinvent.com/materialize-material-design-admin-template/html/horizontal-menu/user-forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 16 Oct 2017 09:33:56 GMT -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content="Materialize is a Material Design Admin Template,It's modern, responsive and based on Material Design by Google. ">
    <meta name="keywords" content="materialize, admin template, dashboard template, flat admin template, responsive admin template,">
    <title>Forgot Password Page | Carbon Copy</title>
    <!-- Favicons-->
    <link rel="icon" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/favicon-32x32.png" sizes="32x32">
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/apple-touch-icon-152x152.png">
    <!-- For iPhone -->
    <meta name="msapplication-TileColor" content="#00bcd4">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.html">
    <!-- For Windows Phone -->
    <!-- CORE CSS-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/materialize.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/style.css" type="text/css" rel="stylesheet">
    <!-- CSS style Horizontal Nav-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/layouts/style-horizontal.css" type="text/css" rel="stylesheet">
    <!-- Custome CSS-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/custom/custom.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>css/layouts/page-center.css" type="text/css" rel="stylesheet">
    <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
    <link href="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet">
  </head>
  <body class="cyan">
    <!-- Start Page Loading -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Page Loading -->
    <div id="login-page" class="row">
      <div class="col s12 z-depth-4 card-panel">
        <form class="login-form">
          <div class="row">
            <div class="input-field col s12 center">
              <h4>Forgot Password</h4>
              <p class="center">You can reset your password</p>
            </div>
          </div>
          <div class="row margin">
            <div class="input-field col s12">
              <i class="material-icons prefix pt-5">person_outline</i>
              <input id="username" type="text">
              <label for="username" class="center-align">Username</label>
            </div>
          </div>
          <div class="row margin">
            <div class="input-field col s12">
              <i class="material-icons prefix pt-5">lock_outline</i>
              <input id="password" type="password">
              <label for="password">Password</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <a href="index.html" class="btn waves-effect waves-light col s12">Reset Password</a>
            </div>
            <div class="input-field col s12">
              <p class="margin sign-up"> <a href="<?php echo SITE_PATH ?>" class="right">Login</a></p>
            </div>
          </div>
        </form>
      </div>
    </div>
    <!-- ================================================
    Scripts
    ================================================ -->
    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jquery-3.2.1.min.js"></script>
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/materialize.min.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/custom-script.js"></script>
  </body>

<!-- Mirrored from pixinvent.com/materialize-material-design-admin-template/html/horizontal-menu/user-forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 16 Oct 2017 09:33:56 GMT -->
</html>