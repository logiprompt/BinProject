<!-- START FOOTER -->
    <footer class="page-footer">
      
      <footer class="page-footer">
        <div class="footer-copyright">
          <div class="container">
            <span>Copyright ©
              <script type="text/javascript">
                document.write(new Date().getFullYear());
              </script> <a class="grey-text text-lighten-4">Bin Management - A basic smart Digital Manager</a> All rights reserved.</span>
            <span class="right hide-on-small-only">Design and Developed by 
            <a class="grey-text text-lighten-4" href="#">Haran</a>
            </span>
          </div>
        </div>
      </footer>
    </footer>
    <!-- END FOOTER -->
    <!-- ================================================
    Scripts
    ================================================ -->
    <!-- jQuery Library -->
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/materialize.min.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- chartjs -->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/chartjs/chart.min.js"></script>
    <!-- sparkline -->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/sparkline/jquery.sparkline.min.js"></script>
    <!-- google map api -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>
    <!--jvectormap-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jvectormap/vectormap-script.js"></script>
    <!--google map-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/scripts/google-map-script.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/plugins.js"></script>
    <!--card-advanced.js - Page specific JS-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/scripts/dashboard-analytics.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/custom-script.js"></script>

  </body>

</html>