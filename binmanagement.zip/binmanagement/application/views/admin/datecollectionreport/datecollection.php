

          <!--breadcrumbs end-->
<style>
.picker__table th{
	color:#fff !important;
}
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l4">
                <div class="card-panel">
                <h4 class="header2">Add Data Vice Collection Report</h4>
                  <div class="row">
                  <!--FORM Report ADD-->
                   <form role="form" action="" name="frmdatecolle" id="frmdatecolle">
                    <!-- Sales man-->
                 <div class="row">
                            
                        </div>
                      <!--Sales date--> 
                    <div class="row">
                        <div class="input-field col s12">
                       			<input class="datepicker form-control " type="text" placeholder="Date" name="txtdate" id="txtdate" >
                                <label for="dob">From</label>
                        </div>
                      </div>
                      
                      <div class="row">
                        <div class="input-field col s12">
                       			<input class="datepicker form-control " type="text" placeholder="Date" name="textid" id="txtid" >
                                <label for="dob">To</label>
                        </div>
                      </div>

                      
                      <!--BUTTON SUBMIT-->
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn green accent-4 waves-effect waves-light right" type="button" id="getbtn" name="action">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
           <div class="col s12 m12 l8">
               <div class="card-panel">
                  <div class="row">
                     <table id="datatable" class="display" cellspacing="0" width="100%">
						 <thead>
						   <tr class="text-center">
								  <!--<th style="width:50px;">-->
                                    <th style="width:10%;">Sl No</th>
                                    
                                    <th>Employe Name</th>
                                    <th>Merchant Name</th>
                                    <th>Collection Type </th>
                                    <th>Payment Type</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                          </tr>   
						</thead>
                            <tbody id="dat">
                                              
                            </tbody>
                   </table>               		
                  </div>
             	</div>
          </div>
</div>     
        
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	
   	//------insert -------------//
       	 $("#getbtn").click(function(ev) {
			//alert(1);
			var e=validation();
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php  echo ADMIN_PATH?>DateCollectionReport/collection";
  			var redirect = "<?php echo ADMIN_PATH?>DateCollectionReport";
  			var form = document.forms.namedItem("frmdatecolle");                        
			var oData = new FormData(document.forms.namedItem("frmdatecolle"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
						$('.overlay').css({'display':'none'});
				 $('#dat').html(oReq.responseText);
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){
        error=0;
		$('label').removeClass('labelerror');
        $('input').removeClass('errors');
      //  $('input').removeClass('errorInput');
        $('select').removeClass('errors');
     //   $('select').removeClass('errorInput');
        var values = {'name':$('#txtdate').val(),'nam':$('#txtdate').val()
						
							}
        if(values.name == ''){
			$('#txtdate').parent().children('label').addClass('labelerror');
            $('#txtdate').addClass('errors');
            $('#txtdate').attr("placeholder", "Please Enter Valid Date")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
		 if(values.nam == ''){
			$('#txtid').parent().children('label').addClass('labelerror');
            $('#txtid').addClass('errors');
            $('#txtid').attr("placeholder", "Please Enter Valid Date")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
		
        return error;
	}
});
	

						</script>