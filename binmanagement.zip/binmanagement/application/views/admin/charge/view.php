

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l12 ">
                <div class="card-panel">
				<h4 class="header2">Trip Sheet Details</h4>
                  <div class="row">
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">   
                                    
                            <div class="input-field col s12 m6 s6" id="vname">
                       <input readonly="readonly"type="text" value="<?php echo $details->man_title; ?>" placeholder="Name" id="sname" name="sname">
                       <label for="first_name">Brand Name</label>
                        </div>   
                        
                         <div class="input-field col s12 m6 s6" id="vname">
                        <input readonly="readonly"type="text" value="<?php echo $details->model_name; ?>" placeholder="Name" id="sname" name="sname">
                        <label for="first_name">Model Name</label>
                        </div>                 
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          	<input readonly="readonly"type="text" value="<?php echo $details->c_name; ?>" placeholder="Name" id="sname" name="sname">
                            
                          <label for="first_name">Client Name</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          	<input readonly="readonly"type="text" value="<?php echo $details->c_id; ?>"  placeholder="Client Id" id="cid" name="cid">
                            
                          <label for="first_name">Client Id</label>
                        </div>
                                                                    
                        
                        <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly"type="number" value="<?php echo $details->s_km; ?>" placeholder="Starting km" id="s_km" name="s_km">
                          <label for="first_name">Starting km</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly"type="number" value="<?php echo $details->e_km; ?>" placeholder="Ending km" id="e_km" name="e_km">
                          <label for="first_name">Ending km</label>
                        </div>
                         <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly"type="text"  class="timepicker" value="<?php echo $details->w_time; ?>" placeholder="Waiting time" id="w_time" name="w_time">
                          <label for="first_name">Waiting time</label>
                        </div>
                         <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly"type="number" value="<?php echo $details->min_charge; ?>" placeholder="Minimum charge" id="m_charge" name="m_charge">
                          <label for="first_name">Minimum charge</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input readonly="readonly"type="number" value="<?php echo $details->totalfare; ?>" placeholder="Minimum charge" id="m_charge" name="m_charge">
                          <label for="first_name">Total Fare</label>
                        </div>
                       
                                  </div>
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Cancel
                             
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
			  
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >




	
	
	
	
$(document).ready(function(e) {
		 $("#btnsub").click(function(e) {
			 
			 var redirect = "<?php echo ADMIN_PATH?>charge";
			document.location=redirect;
		
   			});
	
});
	
		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

