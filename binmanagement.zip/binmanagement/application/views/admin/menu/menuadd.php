 <!--breadcrumbs start-->
 <style>
 .mmenu{
	display:none; 
	 }

 </style>
          <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
              <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
              <div class="row">
                <div class="col s10 m6 l6">
                  <h5 class="breadcrumbs-title">Menu</h5>
                  <ol class="breadcrumbs">
                    <li><a href="<?php echo ADMIN_PATH?>index/home">Dashboard</a>
                    </li>
                    <li><a href="#">Menu</a>
                    </li>
                  </ol>
                </div>
                
              </div>
            </div>
          </div>
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              
              <div id="basic-form" class="section">
                <div class="row">
                   <!-- Form with placeholder -->
                 <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">New Menu</h4>
                      <div class="row">
                       <form role="form" name="frmmenu" action="" method="post">
                       <div class="row">
                            <div class="input-field col s12">
                              <select class="form-control form-control1" name="selmenutype" id="selmenutype">
                                  
											    <option value="1" selected>Main Menu</option>
                                            	<option value="2">Sub Menu</option>
									</select>
                              <label for="first_name">Select Menu Type</label>
                            </div>
                          </div>
                          <div class="mmenu">
                           <div class="row">
                            <div class="input-field col s12">
                              <select class="form-control form-control1" name="selmenu" id="selmenu">
                                  
											    <option value="0" selected>Main Menu</option>
                                                <?php foreach($mainmenu as $val) {?>
                                            	<option value="<?php echo $val->menu_id; ?>"><?php echo $val->menu_name; ?></option>
                                                <?php } ?>
									</select>
                              <label for="first_name">Select Parent Menu</label>
                            </div>
                          </div>
                            </div>
                          <div class="row" >
                            <div class="input-field col s12">
                              <input placeholder="Enter Menu Name" name="menuname" id="menuname" type="text">
                              <label for="first_name"> Menu Name</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Menu Icon" name="menuicon" id="menuicon" type="text">
                              <label for="first_name">Menu Icon</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Menu Path" name="menupath" id="menupath" type="text">
                              <label for="first_name">Menu Path</label>
                            </div>
                          </div>
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  
                  <!--Basic Form-->
                  
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Menu</h4>
                      <div class="row">
                        <table id="datatable" class="display" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th>Menu</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($menu) { $i=1; foreach($menu as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td ><?php echo $val->menu_name?> </td>
								<td style="width:75px"> 
                                <!--<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>menu/editMenu/<?php echo encode($val->menu_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>-->
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->menu_id)?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
	
	  	 $("#selmenutype").change(function(e) {
			 if( $("#selmenutype").val()==1){
		  $(".mmenu").css({'display':'none'});
			 }
			 else if( $("#selmenutype").val()==2){
				   $(".mmenu").css({'display':'block'});
				 }
				
		 });
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>menu/addmenu";
  			var redirect = "<?php echo ADMIN_PATH?>menu";
  			var form = document.forms.namedItem("frmmenu");                        
			var oData = new FormData(document.forms.namedItem("frmmenu"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
				//alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Main Menu Already  Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					  if(oReq.responseText==2){
					// alert("Exist");
					swal("SubMenu Already  Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						swal({
						  title: '<div class="tst" >Success</div>',
						  html:'<div class="tst1" >Added</div>',
						  type: 'success',
						  customClass: 'swal-delete',
						})
 					 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

      $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'menuname':$('#menuname').val(),
									 'menuicon':$('#menuicon').val(),
									 'menupath':$('#menupath').val()

                                 }

        if(values.menuname == ''){
            $('#menuname').addClass('errors');
            $('#menuname').attr("placeholder", "Please enter name.")
			 $('#menuname').parent().children('label').addClass('labelerror');
            error=1;
        } 
		   if(values.menuicon == ''){
            $('#menuicon').addClass('errors');
            $('#menuicon').attr("placeholder", "Please enter icon.")
			 $('#menuicon').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		    if(values.menupath == ''){
            $('#menupath').addClass('errors');
            $('#menupath').attr("placeholder", "Please enter path.")
			 $('#menupath').parent().children('label').addClass('labelerror');
            error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmmenu').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Menu",
							   type: "warning",
							   showCancelButton: true,
							   customClass:"swal-delete",
							   confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							  
                          }).then(function(){
			
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>menu/deleteMenu",
				

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											
                                               // $(".loader").remove();
											location.reload() ;
												 swal({
												  title: '<div class="tst" >Success</div>',
												  html:'<div class="tst1" >Menu Deleted</div>',
												  type: 'success',
												  customClass: 'swal-delete',
												})
                                 // 	document.location = redirect;
	//cmswal("Sucessfully!", "Sucessfully Deleted!", "success")
                                            }

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
	
});
</script>


    
    
    
    
    
    
    
    
    

