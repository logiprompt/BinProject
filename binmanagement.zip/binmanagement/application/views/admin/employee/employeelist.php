
						 <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m12 l12">
                    <div class="card-panel">
                      <h4 class="header2">All Employees</h4>
                      <div class="row">
						
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
						  <thead>
							  <tr class="text-center">
								  <th style="width:50px;text-align:left">Sl.no</th>
								 <!-- <th>Shop name</th>-->
                                   <th style="text-align:left;">Employee name</th>
                                 <th style="text-align:left;">Phone Number</th>
                                 <th style="text-align:left;">Qualification</th>   
                                 <th style="text-align:left;">Action</th>
                                  <!--  
								  <th>Edit</th>
                                  
                                  <th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($employee) { $i=1; foreach($employee as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:50px;text-align:left;"><?php echo $i ?></td>
                                    	<td style="text-align:left;"><?php echo $val->name?> </td>
                                 <td style="text-align:left;"><?php echo $val->phoneno?> </td>
                                        <td style="text-align:left;"><?php echo $val->emp_qualification?> </td>
								     
								<td style="text-align:left;">
									<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH?>employee/employeeedit/<?php echo encode($val->salesmanid);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                               
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt"  id="btndelt"rel="<?php echo encode($val->salesmanid);?>">
										<i class="material-icons">delete</i>
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
						
								
								
							
						
				</div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

$(document).ready(function(e) {
   	
	
	
	
	// ---------- < Delete Employee   > ---------- //
	
	
	   $(document).on('click', '#btndelt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Employee",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>employee/deleteEmployee",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){// alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                                 location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
});
</script>


    
    
    
    
    
    
    
    
    

