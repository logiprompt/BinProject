  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
	.panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}

</style>		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Add Product</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmproduct" id="frmproduct">
							
<fieldset>
							 
							  	 <div class="form-group">
									
									<select class="form-control form-control1" id="selcat" name="selcat">
                                    	<option value="0"> Category</option>
										<?php foreach($category as $key){?>
											
											<option value="<?php echo $key->cat_id;?>"><?php echo $key->cat_name;?></option>
											
									<?php		}?>
									</select>
								</div>
                                 <div class="form-group">
									
									<select class="form-control" id="selsubcats" name="selsubcat">
                                    	<option value="0">Sub Category</option>
										
									</select>
								</div>
							<div class="form-group">
								<input class="form-control " placeholder="Products" id="txtproduct" name="txtproduct" type="text" >
							</div>
                            <div class="form-group">
								<input class="form-control " placeholder="Amount" id="txtamount" name="txtamount" type="text" >
							</div>
							<!--<div class="text-center"><a href="index.html" class="btn btn-primary btn-block lg">Submit</a></div>-->
                            
                             <div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnsubmit" style="float:right;">Submit</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
								
                            </fieldset>								
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
    
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading1">Total Product</div>
                    <div class="box-icon">
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					<div class="panel-body">
						<div class="col-md-12">
							<form role="form" name="frmsubcat" method="post" action="">
							
						<table class="text-center table table-striped table-bordered bootstrap-datatable datatable tbl_cat index_table" id="viewcategory">
						  <thead>
							  <tr class="text-center">
								  <th>Sl.no</th>
								  <th>Category name</th>
                                   <th>Subcategory name</th>
                                   <th>Product name</th>
                                    <th>Create date</th>
								  <th>Edit</th>
                                  <th>Delete</th>
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php if($product) { $i=1; foreach($product as $val  ){ ?>
                         
                          
							<tr>
								<td><?php echo $i ?></td>
								<td class="center"><?php echo $val->cat_name?> </td>
									<td class="center"><?php echo $val->subcat_name?> </td>
                                    	<td class="center"><?php echo $val->product_name?> </td>
                                    	<td class="center"><?php echo $val->create_date?> </td>
								<td class="center">
								
									<a class="glyphicon glyphicon-edit" href="<?php echo ADMIN_PATH.'product/proedit/'.$val->product_id?>">
										<i class="halflings-icon white edit"></i>  
									</a>
                                  </td>  
                                <td>    
									<a class="glyphicon glyphicon-trash btndlt" rel="<?php echo $val->product_id?>" href="#">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
							</form>	
								
								
							
						
					</div>
				</div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
        
        
        
        
	</div>
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>


<script type="text/javascript">

$(document).ready(function(e) {
	
	//-----changing subcategory on selecting category-------//
		$("#selcat").change(function(e) {
	//alert(1);
	var catid=$( this).val();
//	alert(catid);
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>Product/getsubcategorybycategoryid",
			  	data:"catid="+catid,
				success:function(data){
				//	alert(data);
					$("#selsubcats").html(data);
					}		   
			   			});
        });
	
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>product/addproduct";
  			var redirect = "<?php echo ADMIN_PATH?>product";
  			var form = document.forms.namedItem("frmproduct");                        
			var oData = new FormData(document.forms.namedItem("frmproduct"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					
				 if(oReq.responseText==1){
					 
					  alert("Exist");
					 }
					 else
					 {
 					document.location = redirect;
					 }}
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

        var values = {
                                    'category':$('#selcat').val(),
									'sucategory':$('#selsubcats').val(),
									'product':$('#txtproduct').val(),

                                 }

        if(values.category == 0){

            $('#selcat').addClass('errors');

            $('#selcat').attr("placeholder", "Select");

            $('#selcat').addClass('errorInput');

            error=1;

        } 
		if(values.sucategory == 0){

            $('#selsubcats').addClass('errors');

            $('#selsubcats').attr("placeholder", "Select");

            $('#selsubcats').addClass('errorInput');

            error=1;

        } 
				if(values.product == ''){

            $('#txtproduct').addClass('errors');

            $('#txtproduct').attr("placeholder", "Please enter product name");

            $('#txtproduct').addClass('errorInput');

			$('#txtproduct').css({'border':'1px solid red'});
            error=1;

        } 

        return error;
    }
//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsubcat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
		// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this service",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          },
						   function(isConfirm) {
                              if (isConfirm) { 
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>product/deleteproduct",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully Added!", "success")
                                            }

                                        });
					   }

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
	
	
	
	
	
	
	
	
});
</script>
