 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script>
          <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  


<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Change Password</h4>
                      <div class="row">
                       <form role="form" name="changepwd" action="" method="post" id="changepwd">
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter old password" name="txtopwd" id="txtopwd" type="password">
                              <label for="first_name">Old Password</label>
                            </div>
                          </div>
                          <div class="row"> 
                         <!-- <input type="button" id="map" value="Get From Map" class="map" />-->
                          
                            <div class="input-field col s12">
                              <input placeholder="Enter new password" name="txtnpwd" id="txtnpwd" type="password">
                            <label for="first_name">New Password</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Re-enter password" name="txtcpwd" id="txtcpwd" type="password">
                              <label for="first_name">Confirm Password</label>
                            </div>
                          </div>
                          
                          
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Reset
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                   
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">
   
$(document).ready(function(e) {
	 
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			
			var e=validation();
			if(e==0){ 
			$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>changepwd/reset";
  			var redirect = "<?php echo ADMIN_PATH?>changepwd";
  			var form = document.forms.namedItem("changepwd");                        
			var oData = new FormData(document.forms.namedItem("changepwd"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					 customSwalFunD("Mismatch", "Old password incorrect", "error")					   
					 }
				 else if(oReq.responseText==2){
					 customSwalFunD("Missmatch!", "New & Confirm password missmatch!", "error")					   
					 }
					 else
					 {
						
						 	swal({
								  title: '<div class="tst" >Success</div>',
								  html:'<div class="tst1" >Password updated</div>',
								  type: 'success',
								  customClass: 'swal-delete',
								})
						document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

       $('input').removeClass('errors');
	   $('label').removeClass('labelerror');
       $('select').removeClass('errors');

            var values = {
                                    'oldpwd':$('#txtopwd').val(),
									'newpwd':$('#txtnpwd').val(),
									'cpwd':$('#txtcpwd').val(),
                                 }

        if(values.oldpwd == ''){
			  $('#txtopwd').addClass('errors');
              $('#txtopwd').attr("placeholder", "Please enter Old password.");
			  $('#txtopwd').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.newpwd == ''){
			  $('#txtnpwd').addClass('errors');
              $('#txtnpwd').attr("placeholder", "Please enter new password.");
			  $('#txtnpwd').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.cpwd == ''){
			  $('#txtcpwd').addClass('errors');
              $('#txtcpwd').attr("placeholder", "Re-Enter password.");
			  $('#txtcpwd').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.cpwd != values.newpwd){
			  $('#txtcpwd').addClass('errors');
              $('#txtcpwd').attr("placeholder", "Password Missmatch.");
			  $('#txtcpwd').parent().children('label').addClass('labelerror');
              customSwalFunD("Missmatch!", "New & Confirm password missmatch!", "error")
			  error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	 
	
	
	
	
	
	
	
});
</script>
    
    <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>




    
    
    
    
    
    
    
    
    

