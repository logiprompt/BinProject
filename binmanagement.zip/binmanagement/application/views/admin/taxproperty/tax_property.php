

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section" style=" min-height:262px;">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6">
                <div class="card-panel">
                <h4 class="header2">Tax Attributes</h4>
                  <div class="row">
                  <style>
				  hr {
						display: block;
						height: 1px;
						border: 0;
						border-top: 1px solid #008cd2;
						margin: 1em 0;
						padding: 0; 
					}
				  .addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 10px;
							right: -52px;
							color: #0092d3;
							cursor:pointer;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:0.7;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 35px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
				  @keyframes spin{
					0%{ transform:rotate(0deg)}
					100%{transform:rotate(360deg)}  
				  }
				  .rembg{
					      background: rgba(255, 0, 0, 0.25); 
				  }
                  </style>
                   <form role="form" aria-describedby="frmsubtaxproperty" name="frmsubtaxproperty" id="frmsubtaxproperty">
                      <div class="row">
                        <div class="input-field col s10">
                          <select class="form-control form-control1" id="selcat" name="selcat">
                                    	<option value="0">Select Tax</option>
										<?php foreach($tax as $key){?>
													<option value="<?php echo encode($key->tax_id);?>"><?php echo $key->tax_name;?></option>	
                                                <?php }?>
									</select> 
                          <label for="first_name">Tax Names</label><a class="addDynamicfield"><i class="material-icons">add_circle</i></a>
                        </div>
                      </div>
                      <hr /> 
                      <div class="row" aria-describedby="fieldfor new items" id="field-new-item">
                      		<div id="exist">
                            
                            </div>
                               <!-- <div class="input-field col s6">
                                        <input  class="form-control" id="txtproduct" name="txtproduct" type="text" >
                                        <label for="email">Product Name</label>
                                  <a class="removeDynamicfield"><i class="material-icons">remove_circle</i></a>
                                </div>-->
                      </div>
 
                        <div class="row">
                          <div class="input-field col s12">
                            <button  class="btn cyan waves-effect waves-light right" type="button" id="frm-submit-btn" name="action">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
              <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Tax Names</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Tax Names</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($tax) { $i=1; foreach($tax as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php  echo $i ?></td>
								<td style="text-align:left;"><?php  echo $val->tax_name?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan btnedit"  data-id="<?php  echo encode($val->tax_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php  echo $val->tax_id?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php  $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>

        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">
//Exist
$(document).on('change','#selcat', function(){
	 $('.overlay').css({'display':'flex'});
		//$(this).parent('.select-wrapper').children('.select-dropdown').prop("disabled", true);
	//	$('.load').addClass('loading');
		var catid=$(this).val();
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>taxproperty/seltaxproperty",
			data:'catid='+catid,
			success: function(data){
				 $('.overlay').css({'display':'none'});
					$('#exist').html(data);
				}
			})
	});



//ADD NEW Field
$(document).ready(function(e) {
	$count=0;
	 $(".addDynamicfield").click(function(e) {
			$contentappenTo=$('#field-new-item');
			$html='';
			$html+='<div class="input-field col s10 dynamicaddfield" aria-controls="'+$count+'" style="display:none;">';
			$html+='<input  class="form-control txtproperty" id="txtproperty" name="txtproperty[]" type="text" >';
    		$html+='<label for="email">Enter Property name</label>';
            $html+='<a class="removeDynamicfield"><i class="material-icons">close</i></a>';
            $html+=' </div><div class="clearfix"></div>';
			$contentappenTo.append($html);
			$('.dynamicaddfield').fadeIn(1500);
			//console.log($( 'div[ area-controls=' + $count + ']' ));//.fadeIn(1000);
			$count++;
			//	$('[area-controls='$count]).fadeIn(1000);
			//$('area-controls'+$count).fadeIn(1000);
	 });
	 //Remove clicked Field
	 $(document).on('click','.removeDynamicfield', function(e) {
		$(this).children().addClass('removing').html('refresh')
		 $elm=$(this).parent();
			//$elm.addClass('rembg');
		 setTimeout(function(){
			  $elm.slideUp().delay(300).remove();
			 },300)
		
	 });
	 //SUBMIT BUTTON CLICK
	  $(document).on('click','#frm-submit-btn', function(e) {
		  $('.overlay').css({'display':'flex'});
	 		formdata=$('#frmsubtaxproperty').serialize();
			console.log(formdata);
			$.ajax({
				type:'POST',
				url:'<?php echo ADMIN_PATH ?>taxproperty/addsubtax',
				data:formdata,
				success: function(data){
						$('.overlay').css({'display':'none'});
					//	alert(data)
					}
				})
			
	  });
	 
	 
});








$(document).on('click', '.btndlt', function(){
	$btn=$(this);
	$tr=$btn.parent().parent();
	console.log($tr);
	var id=$(this).attr('rel');  
	swal({
  title: "Are you sure?",
  text: "Your will not be able to recover this Data!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  customClass: 'swal-delete',
  cancelButtonText: "No, cancel!",
  
}).then(function(){
		$('.overlay').css({'display':'flex'});
			 $.ajax({
                                            type:"post",
                       						url: "<?php echo ADMIN_PATH ?>tax/deletetax",
                                            data:"id="+id,
                                            success:function(data){
													$('.overlay').css({'display':'none'});
												 //alert(data);
												/*swal({
												  title: '<div class="tst" >Deleted</div>',
												  html:'<div class="tst1" >Employee has been deleted</div>',
												  type: 'success',
												  customClass: 'swal-delete',
												})*/
												customSwalFunD(
														  'Success!',
														  'Data has been Deleted',
														  'success'
														)
												$tr.remove();
											//	location.reload() ;
											 }
								});
			});
			/*
function(isConfirm) {
  if (isConfirm) {
	  alert(0)
	  $.ajax({
                    type:"post",
					url: "<?php  echo ADMIN_PATH ?>tax/deletetax",
					data:"id="+id,
					success:function(data){ 
					alert(data);
								swal("Sucessfully!", "Sucessfully Deleted!", "success");
								location.reload() ;
          						}
						});//AJAX END
  //  swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } 
  else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");
}*/

});


	// ---------- < Delete Category ENDS > ----------
	$(document).on('click', '.btnedit', function(){	
	  var eid=$(this).attr('data-id');
	    var name='';
	getval();
	function getval(){
	
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>tax/getdetails",
														data:"eid="+eid,
														success:function(data){  
														
															name=data;
															updateform()
												}
			 		
										 })
		
		
		}
	
	
	function updateform(){
		  					//  var name=$("#ad").val();
							
				swal({
						  title: 'Edit Data',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Tax Name" name="txtptax" spellcheck="false" id="txtptax" type="text" value="'+name+'" ><label for="first_name">Tax Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Update',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var taxname=$("#txtptax").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(taxname==''){
											$('#txtptax').parent().children('label').addClass('labelerror');
											$('#txtptax').addClass('errors');
											$('#txtptax').attr("placeholder", "Please enter Tax Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>tax/updatetax",
														data:"taxname="+taxname+"&eid="+eid,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									swal({
		  title: '<div class="tst" >Update</div>',
		  html:'<div class="tst1" >Date Updated</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		setTimeout(function(){
			location.reload() ;
			},600)
		
			 
			  	});
	}
	});
</script>


    
    
    
    
    
    
    
    
    

