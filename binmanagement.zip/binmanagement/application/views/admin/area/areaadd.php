 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script>
          <!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" /> --> 
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" type="text/javascript"></script>
    <link href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />  

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">New Area</h4>
                      <div class="row">
                       <form role="form" name="frmaddarea" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Area Name" name="addarea" id="addarea" type="text">
                              <label for="first_name">New Area</label>
                            </div>
                          </div>
                          <div class="row"> 
                         <!-- <input type="button" id="map" value="Get From Map" class="map" />-->
                         <i class="material-icons" id="map" style="color: #00bdd5;margin-left:11px;cursor: pointer;">pin_drop</i>
                            <div class="input-field col s12">
                              <input placeholder="Latitude" name="latitude" id="latitude" type="text">
                            <label for="first_name">Latitude</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Longitude" name="longitude" id="longitude" type="text">
                              <label for="first_name">Longitude</label>
                            </div>
                          </div>
                          
                          
                          
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Area</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Area</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                          <?php if($area) { $i=1; foreach($area as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td  style="text-align:left;"><?php echo $val->area_name?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>area/editArea/<?php echo encode($val->area_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->area_id)?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">

$(document).ready(function(e) {
	$('#latitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
		  $('#longitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });

   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>area/addarea";
  			var redirect = "<?php echo ADMIN_PATH?>area";
  			var form = document.forms.namedItem("frmaddarea");                        
			var oData = new FormData(document.forms.namedItem("frmaddarea"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					swal("Area Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucessfully!", "Sucessfully Added!", "success")
 					 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	/*$('label').removeClass('labelerror');
$('#txttax').parent().children('label').addClass('labelerror');
*/	function validation(){

        error=0;

        $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'addarea':$('#addarea').val(),
									'latitude':$('#latitude').val(),
									'longitude':$('#longitude').val(),
                                 }

        if(values.addarea == ''){
			
			  $('#addarea').addClass('errors');
              $('#addarea').attr("placeholder", "Please enter Area.");
			  $('#addarea').parent().children('label').addClass('labelerror');
		 error=1;
             } 
		     if(values.latitude == ''){
				 
            $('#latitude').addClass('errors');
            $('#latitude').attr("placeholder", "Please enter Latitude.");
			$('#latitude').parent().children('label').addClass('labelerror');
	        error=1;
		  }
		    if(values.latitude == ''){
				
            $('#longitude').addClass('errors');
            $('#longitude').attr("placeholder", "Please enter Longitude.");
			$('#longitude').parent().children('label').addClass('labelerror');
			 error=1;
			 }  
		  
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Area",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  $('.overlay').css({'display':'flex'});
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>area/deleteArea",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
	
});
</script>
  <script type="text/javascript">
  
	$(document).ready(function(e) {
		if($('#latitude').val()=='' ||$('#longitude').val()==''  ){
			vlat=8.8932118;
			vlong=76.6141396;
			}
			else{
			vlat=$('#latitude').val();
			vlong=$('#longitude').val();
				}
		$('.ui-dialog').remove();
		$('.ui-widget-content').remove();
		$('.mapclass').each(function(index, element) {
            $(this).remove();
        });
    });
        $(function () {
			
			$(window).resize(function(){
           $('.ui-dialog').css({"width":"75%"});
		   $('.ui-dialog').css({"left":"12%"});
              });
			 $(document).delegate("#map","click",function(){  
			$('.ui-dialog').remove();
				$('.ui-widget-content').remove();
				$("#dialog").addClass("mapclass");
				 var map = ''; 
                $("#dialog").dialog({
                    modal: true,
                    title: "Pick your Google Map Value",
                    width: 900,
                    hright: 500,
                    buttons: {
                        Close: function () {
                            $(this).dialog('close');
                        }
                    },
                    open: function () {
					var map = ''; 
					$('.ui-dialog').css({"width":"75%"});
		                 $('.ui-dialog').css({"left":"12%"});
						 var markers = [];
						  var markers = "";
						  var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
                        var mapOptions = {
                            center: new google.maps.LatLng(vlat, vlong),
                            
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
					 styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						/* marker = new google.maps.Marker({
                           map: map,
						   draggable: true,
						   position: new google.maps.LatLng(23.8859, 45.0792),
                          });
						  markers.push(marker);*/
				 google.maps.event.addDomListener(window, "resize", function() {
						 var map="";
						 var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
						  var mapOptions = {
							  
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
                            center: new google.maps.LatLng( vlat, vlong),
                          styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						  });
		 google.maps.event.addListener(map, 'click', function(event) {
				addMarker(event.latLng, map);
				$('#longitude').val(event.latLng.lng());
	            $('#latitude').val(event.latLng.lat());
			  });
         function addMarker(location, map) {
			 
				clearMarkers();
                  markers = [];
			   marker = new google.maps.Marker({
				position: location,
				draggable: true,
				map: map
			  });
			   markers.push(marker);
			}
		function setMapOnAll(map) {
			for (var i = 0; i < markers.length; i++) {
			  markers[i].setMap(map);
			}
		  }
		  function clearMarkers() {
			setMapOnAll(null);
		  }
		 google.maps.event.addListener(marker, 'dragend', function (event) {
			$('#longitude').val(event.latLng.lng());
	        $('#latitude').val(event.latLng.lat());
			});
			
           
                    }
					
                });
				 
				
            });
        });
    </script>
    
    <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>




    
    
    
    
    
    
    
    
    

