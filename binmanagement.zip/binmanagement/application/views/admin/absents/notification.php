 <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" type="text/javascript"></script>
    <link href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />  
    
    
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script>
          <!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  -->

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  
			  <div class="col ">
                    <div class="card-panel">
                      <h4 class="header2">Notification</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Employee ID</th>
                           <th style="text-align:left;">Employee Name</th>
                          <th style="text-align:left;">Reason</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($absents){ $i=1; foreach($absents as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->emp_id?> </td>
                                <td style="text-align:left;"><?php echo $val->emp_name?> </td>
                                <td style="text-align:left;"><?php if($val->reason==1){ echo "N/A"; }elseif($val->reason==2){ echo "Sick During"; }elseif($val->reason==3){ echo "Reported"; } ?> </td>
								
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >




	
	
	
	
$(document).ready(function(e) {
	
	
	$('#latitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
		  $('#longitude').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
	
	
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	//------insert -------------//
	
	
	
		 $("#optionsRadios1").click(function(e) {
			 alert()
			 $("#vname").css({'diplay':'block'});
			  $("#vmid").css({'diplay':'none'});
  
});
		
		
		 $("#optionsRadios2").click(function(e) {
			  alert()
 			 $("#vname").css({'diplay':'none'});
			  $("#vmid").css({'diplay':'block'});
});
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgfile").change(function(){
    readURL(this);
});			
			
	
	
   
       	 $("#btnsub").click(function(e) {
			 
			var e=validation();
		 
			if(e==0){
					$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>absents/addabsents";
  			var redirect = "<?php echo ADMIN_PATH?>absents";
  			var form = document.forms.namedItem("frmmarket");  
		              
			var oData = new FormData(document.forms.namedItem("frmmarket"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
					$('.overlay').css({'display':'none'});
				alert(oReq.responseText);
					
				 /* if(oReq.responseText==1){
					 customSwalFunD("Exist","Phone number already Exist");
					 }
					else if(oReq.responseText==2){
					// swal("Exist!", "Email already Exist!", "error");
					  customSwalFunD("Exist","Email already Exist");
					 }
					 else
					 {	 */
					  customSwalFunD("Success","Sucessfully Added");
					  document.location = redirect;
					 /* } */
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'cname':$('#cname').val(),
									'category':$('#category').val(),
									'address':$('#address').val(),
									'phone':$('#phone').val(),
									'mobile':$('#mobile').val(),
									'author':$('#author').val(),
									'require':$('#require').val(),
									'fdate':$('#fdate').val(),
									'feedback':$('#feedback').val(),
									'status':$('#status').val(),
									'prdctintro':$('#prdctintro').val(),
									'anyinfo':$('#anyinfo').val(),
								    'latitude':$('#latitude').val(),
									'longitude':$('#longitude').val()

                                 }
								 
			if(values.cname == ''){
		   $('#cname').addClass('errors');
			$('#cname').attr("placeholder", "Please enter Company name")
		    $('#cname').parent().children('label').addClass('labelerror');
            error=1;
        } 
			 if(values.category == ''){
		     $('#category').addClass('errors');
			$('#category').attr("placeholder", "Please enter category")
		    $('#category').parent().children('label').addClass('labelerror');
            error=1;
        } 
			  if(values.address == ''){
            $('#address').addClass('errors');
			$('#address').attr("placeholder", "Enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 

        if(values.phone == ''){
            $('#phone').addClass('errors');
			$('#phone').attr("placeholder", "Please enter phone")
		    $('#phone').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.mobile == ''){
            $('#mobile').addClass('errors');
            $('#mobile').attr("placeholder", "Please enter mobile")
		    $('#mobile').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.latitude == ''){
            $('#latitude').addClass('errors');
            $('#latitude').attr("placeholder", "Please enter latitude")
		    $('#latitude').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.longitude == ''){
            $('#longitude').addClass('errors');
            $('#longitude').attr("placeholder", "Please enter longitude")
		    $('#longitude').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.author == ''){
            $('#author').addClass('errors');
            $('#author').attr("placeholder", "Please enter authirised person")
		    $('#author').parent().children('label').addClass('labelerror');
            error=1;
        } 
				
		if(values.require == ''){
            $('#require').addClass('errors');
            $('#require').attr("placeholder", "Please enter requirements")
		    $('#require').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.fdate == ''){
            $('#fdate').addClass('errors');
            $('#fdate').attr("placeholder", "Please enter followup date")
		    $('#fdate').parent().children('label').addClass('labelerror active');
            error=1;
        }
        if(values.feedback == ''){
            $('#feedback').addClass('errors');
            $('#feedback').attr("placeholder", "Please enter feedback")
		    $('#feedback').parent().children('label').addClass('labelerror');
            error=1;
        }
		if(values.status == 0){
          //  $('.select-dropdown').addClass('errors');
			$('#status').parent().children('.select-dropdown').addClass('errors');
			$('#status').parent().parent().children('label').addClass('labelerror');
            error=1;
        }   	
         	
		if(values.prdctintro == 0){
            $('#prdctintro').addClass('errors');
            $('#prdctintro').attr("placeholder", "Please enter product introduction")
		    $('#prdctintro').parent().children('label').addClass('labelerror');
            error=1;
        }
		
		if(values.anyinfo == 0){
            $('#anyinfo').addClass('errors');
            $('#anyinfo').attr("placeholder", "Please enter any additional information")
		    $('#anyinfo').parent().children('label').addClass('labelerror');
            error=1;
        }   	
            	
         
	
        return error;
    }
	
	// Note: This example requires that you consent to location sharing when
      // prompted by your browser. If you see the error "The Geolocation service
      // failed.", it means you probably did not give permission for the browser to
      // locate you.
    /*  var map, infoWindow;
      
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 6
        });
        infoWindow = new google.maps.InfoWindow;

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
			  
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            $('#latitude').val(position.coords.latitude);
			$('#longitude').val(position.coords.longitude);  
            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            infoWindow.open(map);
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
     
      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }
	*/
	
	
	
});
	// ---------- < Delete salesman   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>absents/deleteAbsents",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});
	$(document).on('click', '.btnaddstatus', function(){	
	
		  				
							
				swal({
						  title: 'Add New Status',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Status Name" name="sname" spellcheck="false" id="sname" type="text"  ><label for="first_name">Status Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var stname=$("#sname").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(stname==''){
											$('#sname').parent().children('label').addClass('labelerror');
											$('#sname').addClass('errors');
											$('#sname').attr("placeholder", "Please enter a Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>marketing/newstatus",
														data:"sname="+stname,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New Status Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>marketing/getnewstatus",
													
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#status').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
																$('#btnaddstatus').remove(); 
																$('.stat').html(data);
																$('#status').material_select();
															
														}
										 			});
		/*setTimeout(function(){
			location.reload() ;
			},600)
		*/
			 
			  	});
})	
		
		
	</script>
    
      <script type="text/javascript">
  
	$(document).ready(function(e) {
		if($('#latitude').val()=='' ||$('#longitude').val()==''  ){
			vlat=8.8932118;
			vlong=76.6141396;
			}
			else{
			vlat=$('#latitude').val();
			vlong=$('#longitude').val();
				}
		$('.ui-dialog').remove();
		$('.ui-widget-content').remove();
		$('.mapclass').each(function(index, element) {
            $(this).remove();
        });
    });
        $(function () {
			
			$(window).resize(function(){
           $('.ui-dialog').css({"width":"75%"});
		   $('.ui-dialog').css({"left":"12%"});
              });
			 $(document).delegate("#map","click",function(){  
			$('.ui-dialog').remove();
				$('.ui-widget-content').remove();
				$("#dialog").addClass("mapclass");
				 var map = ''; 
                $("#dialog").dialog({
                    modal: true,
                    title: "Pick your Google Map Value",
                    width: 900,
                    hright: 500,
                    buttons: {
                        Close: function () {
                            $(this).dialog('close');
                        }
                    },
                    open: function () {
					var map = ''; 
					$('.ui-dialog').css({"width":"75%"});
		                 $('.ui-dialog').css({"left":"12%"});
						 var markers = [];
						  var markers = "";
						  var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
                        var mapOptions = {
                            center: new google.maps.LatLng(vlat, vlong),
                            
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
					 styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						/* marker = new google.maps.Marker({
                           map: map,
						   draggable: true,
						   position: new google.maps.LatLng(23.8859, 45.0792),
                          });
						  markers.push(marker);*/
				 google.maps.event.addDomListener(window, "resize", function() {
						 var map="";
						 var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
						  var mapOptions = {
							  
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
                            center: new google.maps.LatLng( vlat, vlong),
                          styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						  });
		 google.maps.event.addListener(map, 'click', function(event) {
				addMarker(event.latLng, map);
				$('#longitude').val(event.latLng.lng());
	            $('#latitude').val(event.latLng.lat());
			  });
         function addMarker(location, map) {
			 
				clearMarkers();
                  markers = [];
			   marker = new google.maps.Marker({
				position: location,
				draggable: true,
				map: map
			  });
			   markers.push(marker);
			}
		function setMapOnAll(map) {
			for (var i = 0; i < markers.length; i++) {
			  markers[i].setMap(map);
			}
		  }
		  function clearMarkers() {
			setMapOnAll(null);
		  }
		 google.maps.event.addListener(marker, 'dragend', function (event) {
			$('#longitude').val(event.latLng.lng());
	        $('#latitude').val(event.latLng.lat());
			});
			
           
                    }
					
                });
				 
				
            });
        });
    </script>
    
    <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>




    




    
    
    
    
    
    
    
    
    

