

          <!--breadcrumbs end-->
<style>
.picker__table th{
	color:#fff !important;
}
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l4">
                <div class="card-panel">
                   <h4 class="header2">Current Location</h4>
                  <div class="row">
                  <!--FORM Report ADD-->
                   <form role="form" action="" name="frmopeningbalance" id="frmopeningbalance">
                    <!-- Sales man-->
                 <div class="row">
                            <div class="input-field col s12">
									<select class="form-control form-control1" name="selsalesman" id="selsalesman">
                                    	<option value="0"> Salesman</option>
											  <?php foreach($salesman as $val){?>
											<option value="<?php  echo $val->salesmanid?>"><?php  echo $val->name?></option>
											<?php  }?>
									</select>
                              		<!--<label for="select Salesman">Salesman</label>-->
                            </div>
                        </div>
                     
                    </form>
                  </div>
                </div>
              </div>
              
           <div class="col s12 m12 l8">
               <div class="card-panel">
                  <div class="row">
                     <table  class="display" cellspacing="0" width="100%">
						 <thead>
						     <tr class="text-center">
								  <!--<th style="width:50px;">-->
                            <th >Date</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                            <th style="width:10%;">Map</th>
                            
                         </tr>   
						</thead>
						<tbody id="dat">
                                      
				 </tbody>
                             </table>               		
                  </div>
             	</div>
          </div>
</div>     
        
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDR07gIkjnjfMhUqqj5WPZ3oUAjoo49wKQ"></script>
          <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  
 
  
<script>


						
		$(document).ready(function(e) {	
		
		<!---- salesman wise report----->				
$("#selsalesman").change(function(e) {
	var sid=$( this).val();
			 	$.ajax({
			   	type:"post",
			   	url:"<?php echo ADMIN_PATH;?>currentlocation/location",
			  	data:"sid="+sid,
				success:function(data){
					//alert(data);
					$("#dat").html(data);
					}		   
			   			});
        });
	
		   });
						</script>
   <script type="text/javascript">
  
	$(document).ready(function(e) {
		
			
		$('.ui-dialog').remove();
		$('.ui-widget-content').remove();
		$('.mapclass').each(function(index, element) {
            $(this).remove();
        });
    });
        $(function () {
			
			$(window).resize(function(){
           $('.ui-dialog').css({"width":"75%"});
		   $('.ui-dialog').css({"left":"12%"});
              });
			 $(document).delegate("#map","click",function(){ 
			vlat=$(this).attr('lat');
			vlong=$(this).attr('long'); 
			$('.ui-dialog').remove();
				$('.ui-widget-content').remove();
				$("#dialog").addClass("mapclass");
				 var map = ''; 
                $("#dialog").dialog({
                    modal: true,
                    title: "Current Location",
                    width: 900,
                    hright: 500,
                    buttons: {
                        Close: function () {
                            $(this).dialog('close');
                        }
                    },
                    open: function () {
					var map = ''; 
					$('.ui-dialog').css({"width":"75%"});
		                 $('.ui-dialog').css({"left":"12%"});
						 var markers = [];
						  var markers = "";
                        var mapOptions = {
                            center: new google.maps.LatLng(parseFloat(vlat), parseFloat(vlong)),
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 10,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:parseFloat(vlat), lng:parseFloat(vlong)};
						 marker = new google.maps.Marker({
							position: haightAshbury,
							draggable: false,
							map: map
						  });
				 google.maps.event.addDomListener(window, "resize", function() {
						 var map="";
						  var mapOptions = {
							  
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
                            center: new google.maps.LatLng( vlat, vlong),
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:parseFloat(vlat), lng:parseFloat(vlong)};
						 marker = new google.maps.Marker({
							position: haightAshbury,
							draggable: false,
							map: map
						  });
						  });
		
                    }
					
                });
				 
				
            });
        });
    </script>
    
    <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>