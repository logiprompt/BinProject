<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

          <!--breadcrumbs end-->
<style>
.picker__table th{
	color:#fff !important;
}
</style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l4">
                <div class="card-panel">
                <h4 class="header2">Bin Report</h4>
                  <div class="row">
                  <!--FORM Report ADD-->
                   <form role="form" action="" name="frmdatesale" id="frmdatesale">
                    <!-- Sales man-->
                 <div class="row">
                            
                        </div>
                      <!--Sales date--> 
                     
                      
                       
					 <div class="row">
                        <div class="input-field col s12">
                       			<!--<input class="datepicker form-control" type="date" placeholder="Date" name="txtfromdate" id="txtfromdate" >-->
                                <input type="text" id="datepicker" name="txtfromdate"> 
                                <label for="dob">From</label>
                        </div>
                      </div>
                      
                      <div class="row">
                        <div class="input-field col s12">
                       			<!--<input class="datepicker form-control " type="date" placeholder="Date" name="txttodate" id="txttodate" >-->
                                <input type="text" id="datepickers" name="txttodate"> 
                                <label for="dob">To</label>
                        </div>
                      </div>

                      
                      <!--BUTTON SUBMIT-->
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn green accent-4 waves-effect waves-light right" type="button" id="btnsend" name="action">Search
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
           <div class="col s12 m12 l8">
               <div class="card-panel">
                  <div class="row">
                      <table id="datatable" class="mdl-data-table"  cellspacing="0" width="100%">
						   <thead>
                                  <tr class="text-center">
                                          
                                        <th style="width:10%;">Sl No</th>
                                        <th>Date</th>
                                        <th>Item</th>
                                        <th>Category</th>
                                        <th>Subcategory</th>
                                        <th>Amount</th>
                                  </tr>   
						   </thead>
                                            <tbody id="dat">            
                                            </tbody>
                     </table>               		
                  </div>
             	</div>
          </div>
</div>     
        
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->
 <script>
  $( function() {
   $( "#datepicker" ).datepicker({
	    format: 'yyyy-mm-dd'
    });
  } );
   $( function() {
    $( "#datepickers" ).datepicker({
		 format: 'yyyy-mm-dd'
		});
  } );
  </script>   
  
<script>


						
$(document).ready(function(e) {	
		
	 $("#btnsend").click(function(e) {
			alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>BinReport/getReport";
  			var redirect = "<?php echo ADMIN_PATH?>BinReport";
  			var form = document.forms.namedItem("frmdatesale");                        
			var oData = new FormData(document.forms.namedItem("frmdatesale"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
					  $('#datatable').dataTable().fnDestroy();
			//console.log(JSON.parse(oReq.responseText));
					$('#dat').html(oReq.responseText);
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
					}
   			});		
		
			
		
	<!---- date wise report----->				
	function validation(){
        error=0;
		$('label').removeClass('labelerror');
        $('input').removeClass('errors');
      //  $('input').removeClass('errorInput');
        $('select').removeClass('errors');
     //   $('select').removeClass('errorInput');
        var values = {'name':$('#txtfromdate').val(),'names':$('#txttodate').val()
						
							}
        if(values.name == ''){
			$('#txtfromdate').parent().children('label').addClass('labelerror');
            $('#txtfromdate').addClass('errors');
            $('#txtfromdate').attr("placeholder", "Please Enter Valid Date")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
		  if(values.names == ''){
			$('#txttodate').parent().children('label').addClass('labelerror');
            $('#txttodate').addClass('errors');
            $('#txttodate').attr("placeholder", "Please Enter Valid Date")
			//$('#txttax').css({'border':'1px solid red'});
		  //  $('#txttax').addClass('errorInput');
            error=1;
        } 
        return error;
	}
	
  });
	
	
		<!---- area wise report----->				
		
			<!---- merchant wise report----->				
						</script> 