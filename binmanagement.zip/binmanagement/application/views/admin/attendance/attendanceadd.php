 <!--breadcrumbs start-->
 <style>
 .mmenu{
	display:none; 
	 }

 </style>
          
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              
              <div id="basic-form" class="section">
                <div class="row">
                   <!-- Form with placeholder -->
                 <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Today Attendance</h4>
                      <div class="row">
                       <form role="form" name="frmatten" action="" method="post" id="frmatten" enctype="multipart/form-data">
                       <div class="row">
                            <input id="myFileInput" type="file" name="imgfile" accept="image/*" capture="camera" style="display:none" >

                          </div>
                          
                          <div class="row" >
                            <div class="input-field col s12">
                              <input placeholder="Enter Employee Name" name="attendname" id="attendname" type="text" value=" <?php echo $this->session->userdata('username');?>"  readonly="readonly">
                              
                            </div>
                          </div>
                          <div class="row">
                            <div class="input-field col s12">
                     <?php date_default_timezone_set("Asia/Calcutta"); $d=  date('d-m-Y H:i:s');?> 

                       <input placeholder="time" name="time" id="time" type="text" value=" <?php echo $d;?>"  readonly="readonly">

                             
                            </div>
                          </div>
                            
                            <div class="row"> 
                         <!-- <input type="button" id="map" value="Get From Map" class="map" />-->
                       <!--  <i class="material-icons" id="map" style="color: #00bdd5;margin-left:11px;cursor: pointer;">pin_drop</i>-->
                            <div class="input-field col s12">
                              <input placeholder="Latitude" name="latitude" id="latitude" type="hidden">
                            
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Longitude" name="longitude" id="longitude" type="hidden">
                             
                            </div>
                          </div>
                          
                          
                        
                          
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  
                  
                  <!--Basic Form-->
                  
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Current Location</h4>
                      <div class="row">
                         <div id="map"></div>
                      </div>
                    </div>
                  </div>
                  
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

   <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 250px;;
      }
      /* Optional: Makes the sample page fill the window. */
     
    </style>
    
  <script>
  $(document).ready(function(e) {
	  function attendanceadd()
	  {
		 if( $("#myFileInput").val()!=''){
		   swal({
                            title: "Are you sure?",
							   text: "You want to check the attendance",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
                          }).then(function(){ 
						  $('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>attendance/addattend";
  			var redirect = "<?php echo ADMIN_PATH?>index/home";
  			var form = document.forms.namedItem("frmatten");                        
			var oData = new FormData(document.forms.namedItem("frmatten"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { // alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					 customSwalFunD("Sucessfully!", "Sucessfully Added!");
 					// document.location = redirect;
					
					 }
					 else
					 {
					customSwalFunD("Error!", "Error!");
					  //alert("Exist");	
					 }
					
					 }
                oReq.send(oData);
               // ev.preventDefault();   
						  });
		 }
		  }
	   
	   $("#myFileInput").change(function(e) {
       attendanceadd();
    });
	<?php if($photo){ ?>
	 var photo=  <?php echo $photo->attendance_tracker; ?>
	 <?php }else{ ?>
	 	 var photo= 0;
	 <?php } ?>
	
	   $("#btnsubmit").click(function(e) {
		   if(photo==1){ 
		    $("#myFileInput").click();
			 
		   }
		   
		   else{
			   attendanceadd();  
			   
			   
			   }
   			});
	  
	  
	  
	  
	  
	  
	  
	  
	  
    
      // Note: This example requires that you consent to location sharing when
      // prompted by your browser. If you see the error "The Geolocation service
      // failed.", it means you probably did not give permission for the browser to
      // locate you.
      var map, infoWindow;
      
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 6
        });
        infoWindow = new google.maps.InfoWindow;

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
			  
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            $('#latitude').val(position.coords.latitude);
			$('#longitude').val(position.coords.longitude);  
            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            infoWindow.open(map);
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
     
      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }
	  });
    </script>


    
    
    
    
    
    
    
    
    

