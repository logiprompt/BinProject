<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
.addDynamicfield,.removeDynamicfield{
						    position: absolute;
							top: 16px;
							right: -10px;
							padding:0px;
							color: #0092d3;
							cursor:pointer;
							opacity:0.7;
							transition:opacity 0.2s;
							  -webkit-touch-callout: none; /* iOS Safari */
							-webkit-user-select: none; /* Safari */
							 -khtml-user-select: none; /* Konqueror HTML */
							   -moz-user-select: none; /* Firefox */
								-ms-user-select: none; /* Internet Explorer/Edge */
									user-select: none; /* Non-prefixed version, currently
														  supported by Chrome and Opera */
				  }
				   .addDynamicfield:hover,.removeDynamicfield:hover{
					   opacity:1;
				   }
				  .removeDynamicfield{
						color:#F30;  
				  }
                  .addDynamicfield i,.removeDynamicfield i{
					font-size: 22px;  
				  }
				  .removeDynamicfield i.removing{
					  animation:spin 2s linear infinite;
				  }
</style>

 <style>
					  		.merchant-reg-image{
								text-align:center;width: 150px;height: 181px;margin: 0 auto;overflow: hidden;
							}
                      		.merchant-reg-image img{
								border:none;width: 150px;height: 150px;/*float: right;border-radius:50%*/		
							}
							.merchant-reg-image .file-field .btn{
								float:none;	
							}
							.merchant-reg-image .file-field.input-field{
								margin-top:0rem;
							}
							.merchant-reg-image .btn{
								border-radius: 0;height: 2.1rem;line-height: 1;padding: 0.5rem 1.2rem;width: 150px;font-size: 14px;font-weight: 600;
							}
							.vdetails{
							display:none;	
								}
								.ulimit{
								display:none;
									
									}
                      </style>
<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                <div class="card-panel">
                                      <h4 class="header2">Register Return</h4>

                  <div class="row">
                  <form role="form" name="frmsalesmanreg" id="frmsalesmanreg"  method="post" enctype="multipart/form-data">
                      <div class="row">
                       
                      <div style="height:20px; clear:both;"></div>
                    
                         
                        
                         <div class="input-field col s12 m6 s6" id="vname">
                        
                          <select id="selEmpname" name="selEmpname">
                            <option value="0">Select</option>
                            <?php if($employee){ foreach($employee as $key){ ?>
                            <option value="<?php echo $key->name ?>"><?php echo $key->name ?></option>
                            <?php }} ?>
                          </select>
                            
                          <label for="first_name">Employee Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	
                          <select id="selEmpId" name="selEmpId">
                            <option value="0">Select</option>
                            <?php if($employee){ foreach($employee as $key){ ?>
                            <option value="<?php echo $key->empid ?>"><?php echo $key->empid ?></option>
                            <?php }} ?>
                          </select>
                          <label for="first_name">Employee ID</label>
                        </div>
                        
                        <div class="input-field col  s12 m3 l3">
                          <input type="text" id="datepicker" name="datefrm">
                          <label for="first_name">Date from</label>
                        </div>
                        <div class="input-field col s12 m3 l3">
                        
                          <input type="text" id="datepickers" name="dateto">
                            
                          <label for="first_name">Date to</label>
                        </div>
                        
                         <div class="input-field col s12 m3 s3">
                          <select id="selTfrm" name="selTfrm">
                            <option value="0">Select from time</option>
                            <?php for($i=1;$i<=24;$i++){ ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?>:00</option>
                            <?php } ?>
                          </select>
                          <label for="first_name">Time from</label>
                        </div>
                        <div class="input-field col s12 m3 s3">
                          <select id="selTto" name="selTto">
                            <option value="0">Select from time</option>
                            <?php for($i=1;$i<=24;$i++){ ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?>:00</option>
                            <?php } ?>
                          </select>
                          <label for="first_name">Time to</label>
                        </div>
                         
						 
                         
                        
                      </div>
                      
                      
                      
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                      <input type="hidden"  name="eduid" id="eduid" />
                        <input type="hidden"  name="areaid" id="areaid" />
                    </form>
                  </div>
                  
                </div>
              </div>
              
              
              
              <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Shift Details</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:60% !important;text-align:left;">Employee ID</th>
                          <th style="width:70% !important;text-align:left;">Date from</th>
                          <th style="width:70% !important;text-align:left;">Date to</th>
                          <th style="width:70% !important;text-align:left;">Time from</th>
                          <th style="width:70% !important;text-align:left;">Time to</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($shifts) { $i=1; foreach($shifts as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:60% !important;text-align:left;"><?php echo $val->emp_id?> </td>
								 
                                <td style="width:70% !important;text-align:left;"><?php echo $val->date_from?> </td>
                                <td style="width:70% !important;text-align:left;"><?php echo $val->date_to?> </td>
                                <td style="width:70% !important;text-align:left;"><?php echo $val->time_from?> </td>
                                <td style="width:70% !important;text-align:left;"><?php echo $val->time_to?> </td>
								<td> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>assignshifts/shiftedit/<?php echo encode($val->shift_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class=" btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->shift_id);?>" id="btndelt" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
              
              
              
              
              
              
              
              
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
<script>
  $( function() {
   $( "#datepicker" ).datepicker({
	    format: 'yyyy-mm-dd'
    });
  } );
   $( function() {
    $( "#datepickers" ).datepicker({
		 format: 'yyyy-mm-dd'
		});
  } );
  </script>   	
	
<script >
	//------insert -------------//
$(document).ready(function(e) {
	
		$(document).on('change', '#head', function(){
			
		if($('#head').val()==='0' ){
			
			$('.ulimit').show();
			}
		
			else{	
				$('.ulimit').hide();
				$('.empuserlimit').val('');
				}
		
		})	
	
	 $(document).on('keypress','.number-check', function(e) {	
				if ( event.keyCode == 46 || event.keyCode == 8 ) {
							
				}
				 else {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault(); 
						}  
				 }
			});
		 $('#email').blur(function(){
		
	
	 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	// console.log(pattern.test($('#txtemail').val()))
					//	 console.log( pattern.test( $scope.chkemail));
						 if(pattern.test($('#email').val())==false){
							 $('#email').addClass('errors');
			 				 $('#email').parent().children('label').addClass('labelerror');
							 
						
						  }
						  else{
							  $('#email').removeClass('errors');
			 				 $('#email').parent().children('label').removeClass('labelerror');
							  }
	
	  });
	
	 $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: false, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
	
	
	
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	
		
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgfile").change(function(){
    readURL(this);
});	


function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Tax Type Already Exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnaddeducation();
							  
							  });
	}


function btnaddeducation(){
								
		  					  $('#edu').material_select();
							  $('#edu').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Education',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Education " name="ename" spellcheck="false" id="ename" type="text"  ><label for="first_name">Education</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var education=$("#ename").val();
									//alert(education); 
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(education==''){ 
											$('#ename').parent().children('label').addClass('labelerror');
											$('#ename').addClass('errors');
											$('#ename').attr("placeholder", "Please enter Product type");
										err=1;
									}
									 
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/inserteducation",
														data:"ename="+education,
														//alert(data);
														success:function(data){//alert(data);
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Education Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>employee/geteducation1",
												//	data:"catval="+cat2,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																$('#edu').material_select('destroy');
																$('.educat').html(data);
																$('#edu').material_select();
															//	location.reload();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnaddeducation', function(){
		btnaddeducation();
		
		})	
	
function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Storage already exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnadddesig();
							  
							  });
	}


function btnadddesig(){
								
		  					  $('#designation').material_select();
							  $('#designation').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Storage',
						  type: 'info',
						  html:
						  '<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Storage Space " name="dname" spellcheck="false" id="dname" type="text"  ><label for="first_name">Storage Space</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var desi=$("#dname").val();
									//alert(education); 
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(desi==''){ 
											$('#dname').parent().children('label').addClass('labelerror');
											$('#dname').addClass('errors');
											$('#dname').attr("placeholder", "Please enter Designtion");
										err=1;
									}
									 
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>registerreturn/insertstorage",
														data:"dname="+desi,
														//alert(data);
														success:function(data){//alert(data);
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Storage Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		  
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>registerreturn/getStoragedetails",
												//	data:"catval="+cat2,
														success:function(data){// alert(data);
																$('.overlay').css({'display':'none'}); 
																$('#designation').material_select('destroy');
																$('.des').html(data);
																$('#designation').material_select();
																
															//	location.reload();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnadddesig', function(){
		btnadddesig();
		
		})		
	


		
function readURLB(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#biodate').attr('src', e.target.result);
			Materialize.fadeInImage('#biodate');
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#biodata").change(function(){
    readURLB(this);
});
			
	$(document).on('change', '#background1', function(){
	//alert($("#background1").val())
			 if( $("#background1").val()=='Yes'){
			 $(".vdetails").css({'display':'block'});
			 }
			 else {
			 $(".vdetails").css({'display':'none'});
			 }
			 });
			 
		 
   
       	 $("#btnsub").click(function(e) {
				//alert("tttt");
				/*$('#eduid').val( $('#edu').val());
				
					$('#areaid').val( $('#area').val());*/
		//	alert($('#area').val());
		//	alert(e);
			var e=validation();
			
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>assignshifts/shiftreg";
  			var redirect = "<?php echo ADMIN_PATH?>assignshifts";
  			var form = document.forms.namedItem("frmsalesmanreg");  
		              
			var oData = new FormData(document.forms.namedItem("frmsalesmanreg"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});	
				 if(oReq.responseText==1){
					 customSwalFunD("Exist","Phone number already Exist");
					 }
					else if(oReq.responseText==2){
					  customSwalFunD("Exist","Email already Exist");
					 }
					 else if(oReq.responseText==3){
					
					  customSwalFunD("Error","Employee User Limit Greater Than Organisation User Limit");
					 }
					  else if(oReq.responseText==4){
					
					  customSwalFunD("Error","Organisation User Limit To Add Employee Reached");
					 }
					 else if(oReq.responseText==5){
					
					  customSwalFunD("Error","Employee User Limit Greater Than Emloyee Head User Limit");
					 }
					  else if(oReq.responseText==6){
					
					  customSwalFunD("Error","Employee User Limit To Add Employee Reached");
					 }
					 
					 else
					 {
					  customSwalFunD("Success","Sucessfully Added");
 				     document.location = redirect;
					 }
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'name':$('#selEmpname').val(),
									'empid':$('#selEmpId').val(),
									'datefrm':$('#datepicker').val(),
									'dateto':$('#datepickers').val(),
									'tfrm':$('#selTfrm').val(),
									'tto':$('#selTto').val(),
                         }
			 
			if(values.name ==0){
		   	$('#selEmpname').parent().children('.select-dropdown').addClass('errors');
			$('#selEmpname').parent().parent().children('label').addClass('labelerror');
            error=1;
        	} 
		 
            if(values.empid == 0){
		    $('#selEmpId').parent().children('.select-dropdown').addClass('errors');
			$('#selEmpId').parent().parent().children('label').addClass('labelerror');
            error=1;
        	} 
		
		    if(values.datefrm == ''){
		    $('#datepicker').addClass('errors');
			$('#datepicker').attr("placeholder", "Please enter from date")
		    $('#datepicker').parent().children('label').addClass('labelerror');
            error=1;
        	} 
			if(values.dateto == ''){
		   	$('#datepickers').addClass('errors');
			$('#datepickers').attr("placeholder", "Please enter to date")
		    $('#datepickers').parent().children('label').addClass('labelerror');
            error=1;
        	} 
			if(values.tfrm == 0){
		    $('#selTfrm').parent().children('.select-dropdown').addClass('errors');
			$('#selTfrm').parent().parent().children('label').addClass('labelerror');
            error=1;
        	} 
			if(values.tfrm == 0){
		    $('#selTto').parent().children('.select-dropdown').addClass('errors');
			$('#selTto').parent().parent().children('label').addClass('labelerror');
            error=1;
        	} 
		
        return error;
    }
	
});

	
	</script>
    
   <script type="text/javascript">

$(document).ready(function(e) {
   	
	// ---------- < Delete Employee   > ---------- //
	
	
	   $(document).on('click', '#btndelt', function(){
		 
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Employee",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
			$('.overlay').css({'display':'flex'});
			//alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>assignshifts/deleteShift",
					//redirect : "<?php echo ADMIN_PATH?>Merchant",

                                            data:"id="+id,

                                            success:function(data){// alert(data);
											$('.overlay').css({'display':'none'});	
											
                                               // $(".loader").remove();
                                 location.reload() ;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
           
     

                                        });
					

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	
	
	
	
	
	
});
</script>
 
    

        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->


    




    
    
    
    
    
    
    
    
    

