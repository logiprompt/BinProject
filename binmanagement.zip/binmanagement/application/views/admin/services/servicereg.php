

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
	.pan{    background: #43b0ef;
    color: white;
    height: 26px;
    border-radius: 5px;
    padding: 5px 5px;}
	
	textarea{    background-color: transparent;
    border: none;
    border-bottom: 1px solid #9e9e9e;
    border-radius: 0;
    outline: none;
    height: 3rem;
    width: 100%;
    font-size: 1rem;
    margin: 0 0 20px 0;
    padding: 0;
    box-shadow: none;
    box-sizing: content-box;
    transition: all 0.3s;
}
 textarea:focus:not([readonly]) {
    border-bottom: 1px solid #ff9100;
    box-shadow: 0 1px 0 0 #ff9100;}
	a .remove{cursor:pointer !important;}a .addmore{cursor:pointer !important;}
	
	a .addmore {
    margin-top: 10px;
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6 ">
                <div class="card-panel">
				<h4 class="header2">Service User Registration</h4>
                  <div class="row">
                  <h6 class="pan">Personal Details</h6>
                  <?php $insdate='2018-07-01';
				    $insfrom =date('Y-m-d' ,strtotime('-7 days',strtotime($insdate)));
					echo $insfrom;?>
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">                    
                                          
                       
                        <div class="input-field col s12 m6 s6" id="vname">
                         
                          	<input type="text" class="form-conrol" id="sname" name="sname">
                            
                          <label for="first_name">Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	<textarea  type="text" class="form-conrol" id="address" name="address"></textarea>
                          <label for="first_name">Address</label>
                        </div>
                       
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="telr" id="telr"  class="form-conrol">
                          <label for="first_name">Telephone </label>
                        </div> 
                         <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="mobile" id="mobile"  class="form-conrol">
                          <label for="first_name">Mobile</label>
                        </div>
                        
                          
                        <div class="input-field col s12 m6 s6">
                          	<input  type="email" name="semail" id="semail"  class="form-conrol">
                          <label for="first_name">Email</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="password" name="password" id="password"  class="form-conrol">
                          <label for="first_name">password</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="password" name="password1" id="password1"  class="form-conrol">
                          <label for="first_name">Conform password</label>
                        </div>
                         </div>
                        <!--<div class="input-field col s12 m6 s6">
                        <select name="warranty" id="warranty">
                          <option value="">Select Warranty Type </option>
                          <option value="1">Under Warranty</option>
                          <option value="2">Out of Warranty </option>
                          </select>
                        </div>-->
                        
                        <!--<div class="input-field col s12 m6 s6">
                            <input type="text" class="datepicker" id="exdeldate" name="exdeldate">
                          	<label for="first_name">Expected delivery date</label>
                        </div>-->
                        
                       
                         <!---------amenity--------->
                       <!-- <h6 class="pan"><?php //if($amenity){echo ucfirst($amenity->amenity_title);} ?></h6>
                        
                       <div class="row">  
                        
                                   <?php //if($amtitle){foreach($amtitle as $bin){ ?>     
                        <div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" value="" class="form-conrol" id="amtitle" name="amtitle[]">
                       <input  type="hidden" value="<?php //echo $bin->titles; ?>"  id="amtitle" name="amlabel[]">
                          <label for="first_name"><?php //echo $bin->titles; ?></label>
                        </div>
                        <?php  //}  //}?>
                        </div> -->        
                      	<!----------service details-------->
                      <!-- <h6 class="pan">Vehicle Details</h6>
                       <div class="row">  
                        
                                    
                        <div class="input-field col s12 m6 s6" id="vname">
                          <textarea class="form-conrol" id="servicedet" name="servicedet"></textarea>
                          <label for="first_name">Details</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                          <textarea class="form-conrol" id="feedback" name="feedback"></textarea>
                          <label for="first_name">Service assistant/Feedback</label>
                        </div>
                      </div> -->
                       
                        <!------------------>
                        
                         <!---------items--------->
                       <!-- <h6 class="pan"><?php //if($amenity){echo ucfirst($amenity->Item_title);} ?></h6>
                        
                       <div class="row">  
                        
                                   <?php //if($itemtitle){foreach($itemtitle as $bin){ ?>     
                        <div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" value="" class="form-conrol" id="itemtitle" name="itemtitle[]">
                          <label  for="first_name"><?php //echo $bin->titles; ?></label>
                           <input  type="hidden" value="<?php //echo $bin->titles; ?>" class="form-conrol"  name="itemlabel[]">
                         
                        </div>
                        <?php // }  }?>
                        </div> -->  
                        
                        <!---------jobs--------->
                       <!-- <h6 class="pan">Jobs</h6>
                        
                       <div class="row" style="line-height:40px">  
                         
                                   <?php //$i=1; if($jobs){foreach($jobs as $bin){ ?>  
                                   <div class="col s12 m6 s6" id="vname">
                          <input  type="checkbox" value="<?php //echo $bin->jobs_id; ?>" class="form-conrol" id="itemjobs<?php //echo $i; ?>" name="itemjobs[]">
                          <label  for="itemjobs<?php //echo $i; ?>"><?php //echo $bin->titles; ?></label>
                           <input  type="hidden" value="<?php //echo $bin->titles; ?>" class="form-conrol"  name="itemlabel[]">
                        </div>
                        <?php //$i++; }  }?>
                        </div>   -->
                              
                      	<!--------history plus---------->
                          <h6 class="pan">Vehicle Details</h6>
                     
                         <div class="row plusbox">  
                        
                         <div class="box" > 
                                     
                        <div class="input-field col s12 m6 s6" id="vname">
                       <select name="bname[]" id="bname" class="bname">
                          <option value="0">Select Brand</option>
                          <?php if(!empty($brand)){ foreach($brand as $val){ ?>
                          <option value="<?php echo encode($val->man_id);?>"><?php echo $val->man_title ?></option>
                         <?php } }?>
                          </select>  
           <!-- <input  type="text" value="" class="form-conrol " id="bname" name="bname[]">-->                          <label for="first_name">Brand Name</label>
                        </div>
                      <div class="input-field col s12 m6 s6" id="vname">
                      
                     <select name="model[]" id="model" class="m">
                          <option value="0">Select model</option>
                         
                          </select>
           <!-- <input  type="text" value="" class="form-conrol " id="model" name="model[]">-->                          <label for="first_name">Model</label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol " id="engineno" name="engineno[]">                          <label for="first_name">Engine No</label>
                        </div>
                      <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol " id="chaiseno" name="chaiseno[]">                          <label for="first_name">Chaise No</label>
                        </div>
                         <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol " id="regno" name="regno[]">                          <label for="first_name">Reg.No</label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol datepicker " id="insurancedudate" name="insurancedudate[]">                          <label for="first_name">Insurance Due Date </label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol datepicker " id="motorvehicletest" name="motorvehicletest[]">                          <label for="first_name">Motor Vehicle Test Date </label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
            <input  type="text" value="" class="form-conrol datepicker " id="pollutiontest" name="pollutiontest[]">                          <label for="first_name">Pollution Test Date</label>
                        </div>
                      <div class="input-field col s12 m6 s6" id="vname">
     <select class="form-conrol" id="color" name="color[]">
     <option value=""> Select Color</option>
     <option value="red">Red</option>
     <option value="blue">Blue</option>
     </select>
                        </div>
                        
                        
                        
                        
                      <div class="input-field col s12 m6 s6" id="vname">
                       <a class="btnplus" style="right:12px;float: right;"><i class="material-icons addmore">add_circle</i></a>                     
                        </div>
                     	 </div>
                     
                        </div> 

                        
                         <!---------Job schedule--------->
                   <!--     <h6 class="pan">Job Schedule</h6>
                        
                       <div class="row">  
                        
                        <div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" class="form-conrol timepicker" id="timein" name="timein">
                          <label for="first_name">Time In</label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" class="form-conrol" id="team" name="team">
                          <label for="first_name">Team Allocated </label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
                        <input  type="text" class="form-conrol datepicker" id="delivarydate" name="delivarydate">
                          <label for="first_name"> Delivery Date</label>
                        </div>
                        <div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" class="form-conrol timepicker" id="deltime" name="deltime">
                          <label for="first_name">Delivery Time </label>
                        </div><div class="input-field col s12 m6 s6" id="vname">
                          <input  type="text" class="form-conrol " id="amt" name="amt">
                          <label for="first_name">Estimated Amount</label>
                        </div>
                        
                       
                        </div>  -->     
                        <!--------------------->
                        
                        
                        
                        
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              
			  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Registrations</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
             
                          <th style="text-align:left;">Name</th>
                         
                          <th style="text-align:left;">Mobile no</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($services){ $i=1; foreach($services as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
							
                                <td style="text-align:left;"><?php echo $val->name?> </td>
                                 
                       
                                 <td style="text-align:left;"><?php echo $val->mobile?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>services/edit/<?php echo encode($val->servicereg_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->servicereg_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >
	
	
$(document).ready(function(e) {
	
	
	$(document).on("change",".bname",function() {
		
			var brand=$(this).val(); 
			var det=$(this);
			if(brand!=''){
	$.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>services/getmodel",
                         data:"brand="+brand,
						 success:function(data){ 
						
					
			 det.parent().parent().parent().children().find('.m').material_select('destroy');		
					 det.parent().parent().parent().children().find('.m').html(data);	
					  det.parent().parent().parent().children().find('.m').material_select();		 
						 
						 
						/* $('#model').material_select('destroy');
               $('#model').html(data);
               $('#model').material_select();	*/						
												
	
											   }
			    
	});
			}
	 });
	
	
	document.getElementById("mobile").maxLength = "10";
	 $('#mobile').keyup(function(){
		  
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
	///////////////////////////////////////////////////////////////////////////////////////////
	  $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: true, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
	
	
date11();
	
	function date11(){
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	}
	
	$(document).on("click",".datepicker",function() {
		date11();
    });	
 $(document).on("click",".addmore",function() {
	 //date11();
		
        var tparent = $(this).parent();
        var rem='<i class="material-icons remove">cancel</i>';
        tparent.html(rem);
		var htm=' <div style="clear:both;"></div><div class="box" > <div class="input-field col s12 m6 s6" id="vname">  <select name="bname[]" id="bname" class="bname"><option value="0">Select Brand</option><?php if(!empty($brand)){ foreach($brand as $val){ ?><option value="<?php echo encode($val->man_id);?>"><?php echo $val->man_title ?></option><?php } }?></select>  <label for="first_name">Brand Name</label> </div><div class="input-field col s12 m6 s6" id="vname"> <select name="model[]" id="model" class="m"><option value="0">Select model</option></select><label for="first_name">Model</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="engineno" name="engineno[]"> <label for="first_name">Engine No</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="chaiseno" name="chaiseno[]"> <label for="first_name">Chaise No</label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol " id="regno" name="regno[]"> <label for="first_name">Reg.No</label> </div> <div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol datepicker" id="insurancedudate" name="insurancedudate[]"> <label for="first_name">Insurance Due Date </label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol datepicker" id="motorvehicletest" name="motorvehicletest[]"> <label for="first_name">Motor Vehicle Test Date </label> </div><div class="input-field col s12 m6 s6" id="vname"> <input type="text" value="" class="form-conrol datepicker" id="pollutiontest" name="pollutiontest[]"> <label for="first_name">Pollution Test Date</label> </div><div class="input-field col s12 m6 s6" id="vname"> <select class="form-conrol" id="color" name="color[]"> <option value=""> Select Color</option> <option value="red">Red</option> <option value="blue">Blue</option> </select> </div><div class="input-field col s12 m6 s6" id="vname"> <a class="btnplus" style="right:12px;float: right;"><i class="material-icons addmore">add_circle</i></a> </div></div></div>';
        /// htm+='<div class="box" ><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="bname" name="bname"><label for="first_name">Brand Name</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="bname" name="bname"><label for="first_name">Model</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="engineno" name="engineno"><label for="first_name">Engine No</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="chaiseno" name="chaiseno"><label for="first_name">Chaise No</label></div><div class="input-field col s12 m6 s6" id="vname"><input  type="text" value="" class="form-conrol " id="regno" name="regno"><label for="first_name">Reg.No</label></div>';
		 // htm+='<div class="input-field col s12 m6 s6" id="vname"><select class="form-conrol" id="color" name="color"><option value=""> Select Color</option><option value="red">Red</option><option value="blue">Blue</option></select> </div><div class="input-field col s12 m1 s1" id="vname"><a class="btnplus" style="right:12px"><i class="material-icons addmore">add_circle</i></a></div></div>';

        $('.plusbox').append(htm);
		 $('select').material_select();
		
    }) 
	 
	 
	  $(document).on("click",".remove",function() {
		 // alert('delet');
       $(this).parent().parent().parent().remove();
    });
	
	  
	
	///////////////////////////////////////////////////////////////////////////////////////////

		 $('#semail').blur(function(){
		
	
	 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	// console.log(pattern.test($('#txtemail').val()))
					//	 console.log( pattern.test( $scope.chkemail));
						 if(pattern.test($('#email').val())==false){
							 $('#semail').addClass('errors');
			 				 $('#semail').parent().children('label').addClass('labelerror');
							 
						
						  }
						  else{
							  $('#semail').removeClass('errors');
			 				 $('#semail').parent().children('label').removeClass('labelerror');
							  }
	    });
	
	
 $("#btnsub").click(function(e) {
	// alert(45645);
 var e=validation();
	 if(e==0){
		 $('.overlay').css({'display':'flex'});
  		 var url="<?php echo ADMIN_PATH?>services/insertdetails";
  		// var redirect = "<?php echo ADMIN_PATH?>services/";
  		 var form = document.forms.namedItem("frmservice");  
		 var oData = new FormData(document.forms.namedItem("frmservice"));           
         var oReq = new XMLHttpRequest();
          oReq.open("POST", url,  true);   
          oReq.onload = function(oEvent) { 
			$('.overlay').css({'display':'none'});
			//alert(oReq.responseText);
			var id=oReq.responseText;
			if(id==22)
			{swal({
  title: "Success!",
  text: "Inserted successfully",
  icon: "success",
  button: "Ok",
});
location.reload() ;
			}
			else if(id==33)
			{
				swal({ 
    title:"EXIST", 
    text:"Email alredy exist", 
    type:"info" 
});
			}
			else if(id==44)
			{
				swal({ 
    title:"EXIST", 
    text:"Mobile Number alredy exist", 
    type:"info" 
});
			}
			//location.reload() ;
			//document.location="<?php //echo ADMIN_PATH?>services/printpdf/"+id;
					//console.log(oReq.responseText);
					 }
                oReq.send(oData);
                //ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'sname':$('#sname').val(),
									'address':$('#address').val(),
									'mobile':$('#mobile').val(),
									'email':$('#semail').val(),
									'timein':$('#timein').val(),
									'team':$('#team').val(),
									'delivarydate':$('#delivarydate').val(),
									'deltime':$('#deltime').val(),
									'amt':$('#amt').val(),
                  'insurancedudate':$('#insurancedudate').val(),
									'motorvehicletest':$('#motorvehicletest').val(),
									'pollutiontest':$('#pollutiontest').val(),
									'bname':$('#bname').val(),
									'model':$('#model').val(),
									'engineno':$('#engineno').val(),
									'chaiseno':$('#chaiseno').val(),
									'regno':$('#regno').val(),
									'color':$('#color').val(),
									'password':$('#password').val(),
									'password1':$('#password1').val()

                                 }
								 
			if(values.sname == ''){
		   $('#sname').addClass('errors');
		   $('#sname').parent().children('label').addClass('active');
			$('#sname').attr("placeholder", "Please enter name")
		    $('#sname').parent().children('label').addClass('labelerror');
            error=1;
        } 
			if(values.address == ''){
		     $('#address').addClass('errors');
			 $('#address').parent().children('label').addClass('active');
			$('#address').attr("placeholder", "Please enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 				 
			if(values.email == ''){
		   $('#semail').addClass('errors');
			$('#semail').attr("placeholder", "Please enter valid mail id")
			$('#semail').parent().children('label').addClass('active');
		    $('#semail').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.mobile == ''){
            $('#mobile').addClass('errors');
            $('#mobile').attr("placeholder", "Please enter Mobile No.")
			 $('#mobile').parent().children('label').addClass('active');
		    $('#mobile').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
			if(values.password.trim() == ''){
			 $('#password').addClass('errors');
		   $('#password').parent().children('label').addClass('active');
			$('#password').attr("placeholder", "Please enter password")
		    $('#password').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.password != values.password1 ){
			   $('#password').addClass('errors');
		   $('#password').parent().children('label').addClass('active');
		    $('#password').val('');
			$('#password').attr("placeholder", "Password Mismatch")
		    $('#password').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.bname == ''){
		   $('#bname').addClass('errors');
		   $('#bname').parent().children('label').addClass('active');
			$('#bname').attr("placeholder", "Please enter brand name")
		    $('#bname').parent().children('label').addClass('labelerror');
            error=1;
        } 
			if(values.model == ''){
		     $('#model').addClass('errors');
			 $('#model').parent().children('label').addClass('active');
			$('#model').attr("placeholder", "Please enter Model")
		    $('#model').parent().children('label').addClass('labelerror');
            error=1;
        } 				 
			if(values.engineno == ''){
		   $('#engineno').addClass('errors');
			$('#engineno').attr("placeholder", "Please enter engine no")
			$('#engineno').parent().children('label').addClass('active');
		    $('#engineno').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.chaiseno == ''){
            $('#chaiseno').addClass('errors');
            $('#chaiseno').attr("placeholder", "Please enter Chaise No.")
			 $('#chaiseno').parent().children('label').addClass('active');
		    $('#chaiseno').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.regno == ''){
		   $('#regno').addClass('errors');
			$('#regno').attr("placeholder", "Please enter engine no")
			$('#regno').parent().children('label').addClass('active');
		    $('#regno').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.pollutiontest == ''){
		   $('#pollutiontest').addClass('errors');
			$('#pollutiontest').attr("placeholder", "Please enter pollution test date")
			$('#pollutiontest').parent().children('label').addClass('active');
		    $('#pollutiontest').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.insurancedudate == ''){
		   $('#insurancedudate').addClass('errors');
			$('#insurancedudate').attr("placeholder", "Please enter insurance due date ")
			$('#insurancedudate').parent().children('label').addClass('active');
		    $('#insurancedudate').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.motorvehicletest == ''){
		   $('#motorvehicletest').addClass('errors');
			$('#motorvehicletest').attr("placeholder", "Please enter motor vehicle test date")
			$('#motorvehicletest').parent().children('label').addClass('active');
		    $('#motorvehicletest').parent().children('label').addClass('labelerror');
            error=1;
        }  if(values.pollutiontest == ''){
		   $('#pollutiontest').addClass('errors');
			$('#pollutiontest').attr("placeholder", "Please enter pollution test date")
			$('#pollutiontest').parent().children('label').addClass('active');
		    $('#pollutiontest').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.insurancedudate == ''){
		   $('#insurancedudate').addClass('errors');
			$('#insurancedudate').attr("placeholder", "Please enter insurance due date ")
			$('#insurancedudate').parent().children('label').addClass('active');
		    $('#insurancedudate').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.motorvehicletest == ''){
		   $('#motorvehicletest').addClass('errors');
			$('#motorvehicletest').attr("placeholder", "Please enter motor vehicle test date")
			$('#motorvehicletest').parent().children('label').addClass('active');
		    $('#motorvehicletest').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 if(values.color == ''){
            $('#color').addClass('errors');
            $('#color').attr("placeholder", "Please select color.")
			 $('#color').parent().children('label').addClass('active');
		    $('#color').parent().children('label').addClass('labelerror');
            error=1;
        } 
		 var pattern =/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
		 if(pattern.test($('#semail').val())==false){
							 $('#semail').addClass('errors');
			 				 $('#semail').parent().children('label').addClass('labelerror');
							 
						 error=1;
						  }	
			if(values.timein == ''){
            $('#timein').addClass('errors');
            $('#timein').attr("placeholder", "Please enter  time in.")
			 $('#timein').parent().children('label').addClass('active');
		    $('#timein').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.team == ''){
            $('#team').addClass('errors');
            $('#team').attr("placeholder", "Please enter team.")
			 $('#team').parent().children('label').addClass('active');
		    $('#team').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.delivarydate == ''){
            $('#delivarydate').addClass('errors');
            $('#delivarydate').attr("placeholder", "Please enter  delivary date.")
			 $('#delivarydate').parent().children('label').addClass('active');
		    $('#delivarydate').parent().children('label').addClass('labelerror');
            error=1;
        } if(values.deltime == ''){
            $('#deltime').addClass('errors');
            $('#deltime').attr("placeholder", "Please enter delivary time.")
			 $('#deltime').parent().children('label').addClass('active');
		    $('#deltime').parent().children('label').addClass('labelerror');
            error=1;
        } 
if(values.amt == ''){
            $('#amt').addClass('errors');
            $('#amt').attr("placeholder", "Please enter  estimated amount.")
			 $('#amt').parent().children('label').addClass('active');
		    $('#amt').parent().children('label').addClass('labelerror');
            error=1;
        } 
        return error;
    }
	
	
});
	// ---------- < Delete service   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>services/deletereg",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});	
		
		
	</script>
    
      





    




    
    
    
    
    
    
    
    
    

