

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2"> Usergroup Permission</h4>
                      <div class="row">
                       <form role="form" name="frmaddgroup" action="" method="post">
                          <div class="row">
                            <div class="input-field col s12">
                               <label for="first_name"> Usergroup Permission</label>
                            <!--  <input placeholder="Enter Usergroup" name="group" id="group" type="text">-->
                            </div>
                            </div>
                              <input type="hidden" name="txtid" id="txtid" />
                             <div class="row">
                            <div class="input-field col s12">
                              <select multiple="multiple" id="selper" name="selper">
                          
                                <option disabled="disabled" value="0">Choose permission....</option>  
                                <?php   $res=menuorg(1);  if ($res==1)  {?>
                                <option value="1">Category</option>
                                <?php }  $res=menuorg(2);  if ($res==1)  { ?>
                                <option value="2">Sub Category</option>
                                  <?php }  $res=menuorg(3);  if ($res==1)  { ?>
                                 <option value="3">Manufacture</option>
                                   <?php }  $res=menuorg(4);  if ($res==1)  { ?>
                                 <option value="4">Tax Type</option>
                                   <?php }  $res=menuorg(5);  if ($res==1)  { ?>
                                 <option value="5">UOM ( Unit of Measurement)</option>
                                   <?php }  $res=menuorg(6);  if ($res==1)  { ?>
                                  <option value="6">User Group</option> 
                                    <?php }  $res=menuorg(7);  if ($res==1)  { ?>
                                   <option value="7">Employee Registration</option> 
                                     <?php }  $res=menuorg(8);  if ($res==1)  { ?>
                                   <option value="8"> Organisation Registration </option>
                                     <?php }  $res=menuorg(9);  if ($res==1)  { ?>
                            	  <option value="9"> Education </option>
                                    <?php }  $res=menuorg(10);  if ($res==1)  { ?>
                           		   <option value="10"> Designation </option>
                                   
                                       <?php }  $res=menuorg(11);  if ($res==1)  { ?>
                            	  <option value="11">Product List</option>
                                       <?php }  $res=menuorg(12);  if ($res==1)  { ?>
                         	      <option value="12">New Product</option>
                                  
                                       <?php }  $res=menuorg(13);  if ($res==1)  { ?>
                          	      <option value="13">Area</option>
                                       <?php }  $res=menuorg(14);  if ($res==1)  { ?>
                          	 	   <option value="14">Employee List</option>
                                        <?php }  $res=menuorg(15);  if ($res==1)  { ?>
                          		  <option value="15">View Organisation List </option>
                                  
                                       <?php }  $res=menuorg(16);  if ($res==1)  { ?>
                          		  <option value="16">Merchant List</option>
                                       <?php }  $res=menuorg(17);  if ($res==1)  { ?>
                        	    <option value="17">New Merchant </option>
                                
                                     <?php }  $res=menuorg(18);  if ($res==1)  { ?>
                         	   <option value="18">Attendance</option>
                               
                                    <?php }  $res=menuorg(19);  if ($res==1)  { ?>
                                  <option value="19">Sales</option>
                                   
                                        <?php }  $res=menuorg(20);  if ($res==1)  { ?>
                         	    <option value="20">Enquiry Form </option>
                                
                                     <?php }  $res=menuorg(21);  if ($res==1)  { ?>
                         	   <option value="21">Service Return </option>
                               
                                    <?php }  $res=menuorg(22);  if ($res==1)  { ?>
                         	   <option value="22">Cash Collection</option>
                               
                                    <?php }  $res=menuorg(23);  if ($res==1)  { ?>
                           <option value="23">Date Vice Sales Report</option>
                                <?php }  $res=menuorg(24);  if ($res==1)  { ?>
                            <option value="24">Date Vice Collection Report</option>
                                 <?php }  $res=menuorg(25);  if ($res==1)  { ?>
                             <option value="25">Employee Vice Sales Report</option>
                                  <?php }  $res=menuorg(26);  if ($res==1)  { ?>
                              <option value="26">Employee Vice Collection Report</option>
                                   <?php }  $res=menuorg(27);  if ($res==1)  { ?>
                               <option value="27">My Sales Report</option>
                                    <?php }  $res=menuorg(28);  if ($res==1)  { ?>
                                <option value="28">My Collection Report</option>
                                     <?php }  $res=menuorg(29);  if ($res==1)  { ?>
                                 <option value="29">Current Location</option>
                                      <?php }  $res=menuorg(30);  if ($res==1)  { ?>
                                  <option value="30">Route History</option>
                                  
                                       <?php }  $res=menuorg(31);  if ($res==1)  { ?>
                                      <option value="31">service</option>
                                      
                                           <?php }  $res=menuorg(32);  if ($res==1)  { ?>
                              <option value="32">Advertisement</option>
                                   <?php }   ?>
                                   
                                 </select>
                                   <input type="hidden" name="txthper" id="txthper" />
                           
                            </div>
                          </div>
                         <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Usergroup</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10px;text-align:left;">SN</th>
                          <th style="text-align:left;">Usergroup</th>
                          <th style="text-align:left;"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                       
                            <?php  if($group)   { $i=1; foreach($group as $val) {?>                          
							<tr>
								<td style="width:10px;text-align:left;"><?php echo $i ?></td>
								<td style="text-align:left;" ><?php echo $val->	usergroup_name?> </td>
								<td style="text-align:left;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>usergroup/editgroup/<?php echo encode($val->usergroup_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->usergroup_id);?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
				
                        <?php $i=$i+1; }}?>
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->





<script type="text/javascript">

$(document).ready(function(e) {
	
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
				$('#txthper').val($('#selper').val());
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>usergroup/updatepermission";
  			var redirect = "<?php echo ADMIN_PATH?>usergroup";
  			var form = document.forms.namedItem("frmaddgroup");                        
			var oData = new FormData(document.forms.namedItem("frmaddgroup"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) {//console.log(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					// alert("Exist");
					customSwalFunD(" Already Exist!", "Exist!", "error")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucessfully!", "Permission Added!", "success")
 				 document.location = redirect;
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	/*$('label').removeClass('labelerror');
$('#txttax').parent().children('label').addClass('labelerror');
*/	function validation(){

        error=0;

        $('input').removeClass('errors');
		$('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                    'per':$('#selper').val(),
                                 }

       if(values.per == 0){
			 $('#selper').parent().children('.select-dropdown').addClass('errors');
			$('#selper').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
	
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
					
 swal({
                            title: "Are you sure?",
							   text: "Delete this usergroup",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          }).then(function(){
						  
						  
			$('.overlay').css({'display':'flex'});
			
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>usergroup/deletegroup",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
										$('.overlay').css({'display':'none'});	
                                               // $(".loader").remove();
                        var redirect = "<?php echo ADMIN_PATH?>usergroup";	  
					document.location=redirect;
                                 // 	document.location = redirect;
	customSwalFunD("Sucessfully!", "Sucessfully deleted!", "success")
                                            }
                                  });
				          });
       });
		// ---------- < Delete Category ENDS > ----------
	
});
</script>
  
    





    
    
    
    
    
    
    
    
    

