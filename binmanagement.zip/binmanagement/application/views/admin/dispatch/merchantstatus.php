 <style>
   @media only screen and (min-width: 993px)
style-horizontal.css:34{
#content {
   /* margin-top: 65px;*/
    min-height: 497px !important;
} 
}
 </style>
<!--<link type="text/css" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />-->
<!--<link type="text/css" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" />--> 
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
 <!--breadcrumbs start-->
          <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
              <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
              <div class="row">
                <div class="col s10 m6 l6">
                  <h5 class="breadcrumbs-title">Search Merchant</h5>
                  <ol class="breadcrumbs">
                    <li><a href="<?php echo ADMIN_PATH?>index/home">Dashboard</a>
                    </li>
                    <li><a href="#">Search Merchant</a>
                    </li>
                  </ol>
                </div>
                
              </div>
            </div>
          </div>
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Search Merchant</h4>
                      <div class="row">
                       <form role="form" name="frmsermerchant" id="frmsermerchant" method="post" action="">
                       
                         <div class="row">
                            <div class="input-field col s12">
                              <input placeholder="Enter Merchant Number" name="mer_num" id="mer_num"  type="text">
                              <label for="first_name"> Merchant Number</label>
                            </div>
                          </div>
                       
                       
                          <div class="row">
                            
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Merchant Details</h4>
                      <!--form sreps--> 
                       <div class="mdl-card mdl-shadow--2dp">

  <div class="mdl-card__supporting-text">

    <div class="mdl-stepper-horizontal-alternative">
      <div class="mdl-stepper-step active-step step-done">
        <div class="mdl-stepper-circle"><span>1</span></div>
        <div class="mdl-stepper-title">Order Confirmed</div>
        <div class="mdl-stepper-bar-left"></div>
        <div class="mdl-stepper-bar-right"></div>
      </div>
      <div class="mdl-stepper-step active-step editable-step">
        <div class="mdl-stepper-circle"><span>2</span></div>
        <div class="mdl-stepper-title">Order Placed</div>
        <div class="mdl-stepper-optional">Optional</div>
        <div class="mdl-stepper-bar-left"></div>
        <div class="mdl-stepper-bar-right"></div>
      </div>
      <div class="mdl-stepper-step active-step">
        <div class="mdl-stepper-circle"><span>3</span></div>
        <div class="mdl-stepper-title">Item Delivered</div>
        <div class="mdl-stepper-optional">Optional</div>
        <div class="mdl-stepper-bar-left"></div>
        <div class="mdl-stepper-bar-right"></div>
      </div>
      <!--<div class="mdl-stepper-step">
        <div class="mdl-stepper-circle"><span>4</span></div>
        <div class="mdl-stepper-title">Share</div>
        <div class="mdl-stepper-optional">Optional</div>
        <div class="mdl-stepper-bar-left"></div>
        <div class="mdl-stepper-bar-right"></div>
      </div>-->
    </div>

  </div>

</div>
                        
				    </div>
                       
                       
                       
                      <!--form sreps-->  
                       
                       
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->


<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
  			var url="<?php echo ADMIN_PATH?>sales/merchantsearch";
  			//var redirect = "<?php echo ADMIN_PATH?>sales";
  			var form = document.forms.namedItem("frmsermerchant");                        
			var oData = new FormData(document.forms.namedItem("frmsermerchant"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { alert(oReq.responseText);
					
				/* if(oReq.responseText==1){
					  customSwalFunD("Error","Already Exist");
						//swal("Alreadt Exist!", "Exist!", "error");
					 }
					 else
					 {
						 document.location = redirect;
						   customSwalFunD("Sucess","Succesfully Added");
						// swal("Succesfully Added!", "Sucess!", "sucess")
 					
					 }}*/
                oReq.send(oData);
               // ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

        var values = {
                                    'category':$('#selcat').val(),
									'sucategory':$('#txtsubcategory').val(),

                                 }

        if(values.category == 0){
			
			/*	  $('#selcat').addClass('errors');
			$('#selcat').attr("placeholder", "Please enter category")
		    $('#selcat').parent().children('label').addClass('labelerror');*/
			
			$('#selcat').parent().children('.select-dropdown').addClass('errors');
			$('#selcat').parent().parent().children('label').addClass('labelerror');

          
			  error=1;
        } 
		if(values.sucategory == ''){

			 $('#txtsubcategory').addClass('errors');
			$('#txtsubcategory').attr("placeholder", "Please enter subcategory")
		    $('#txtsubcategory').parent().children('label').addClass('labelerror');
			
			  error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsubcat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	
	// ---------- < Delete Category   > ---------- //
		 		    $(document).on('click', '.btndlt', function(){
						//alert()
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Sub Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:'swal-delete',
							   closeOnConfirm: true,
							   closeOnCancel: true 
                         }).then(function(){
                             
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Subcategory/deletesubategories",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											location.reload() ;
                                               // $(".loader").remove();

                                 // 	document.location = redirect;
	//swal("Sucessfully!", "Sucessfully Added!", "success")
	   customSwalFunD("Sucess","Succesfully Deleted");
                                            }

                                        });
					

				          });

		
			  
        });
	
	
	
	
	
	
});
</script>










