

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
.clear{
	clear:both !important;
	}
.select-wrapper input.select-dropdown{
	/* border-bottom: none !important;
	 height:1rem !important;*/
	}
</style>
 <!--breadcrumbs start-->
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6 ">
                <div class="card-panel">
				<h4 class="header2">Add to Bin</h4>
                  <div class="row">
                   <form role="form" action="" name="frmbin" id="frmbin">
                    <!--Product Type-->
                  
                           
                        	 
						<div class="row">
                        
                          <div class="input-field col s11 m6 l6">
                          <select class="form-control ncat" id="selcat" name="selcat" >
                                    	<option value="0">Select Category</option>
										<?php foreach($category as $key){	?>
													<option value="<?php echo $key->category_id;?>"><?php echo $key->cat_name;?></option>	
                                                <?php }	?>
									</select>
                          <label for="first_name">Category</label>  
                        </div>
                        <div class="input-field col s11 m6 l6 nsubcat" id="append">
                      <select class="form-control selsubcats" id="selsubcats" name="selsubcat">
                                   <option value="0">Select Sub Category</option>
									</select>
                                      <label for="first_name">Sub Category</label>  
                        </div> 
                      
                     
						 
                        </div>
                        <div class="row">
                           
                           <div class="input-field col s11 m6 l6 nsubcat" id="append">
                      <select class="form-control selsubcats" id="selproducts" name="selproduct">
                                   <option value="0">Select Product</option>
									</select>
                                      <label for="first_name">Product</label>  
                        </div>
                           
                           
                           <div class="input-field col s11 m6 l6 nunit">
									<select class="form-control" id="selunit" name="selunit" >
                                    	<option value="0" >Product Unit</option>
										<?php foreach($measurement as $measurement){	?>
													<option value="<?php echo $measurement->measurement_id;?>"><?php echo $measurement->measurement_name;?></option>	
                                                <?php }	?>
									</select>
                                      <label for="price">Product Unit</label>
                          </div>
                          
                          
                        </div> 
                        <div class="row">
                           <div class="input-field col s12 m6 s6">
                              <input  class="form-control "  id="quantity" name="quantity" type="text" >
                              <label for="hsn code">Quantity</label>
                           </div>
                           <div class="input-field col s12 m6 s6">
                              <input  class="form-control "  id="reason" name="reason" type="text" >
                              <label for="hsn code">Reason for Bin</label>
                           </div>
                            
                           
                          
                        </div>
                      <!--PRODUCT NAME-->
                      
                      <!--PRICE & DESCOUNT-->
                      <div class="row">
                      	 <!--<div class="input-field col s12 m6 l6">
                               <input  class="form-control input_field-tax_properties" spellcheck="false" value="" id="txtdiscount" name="txtdiscount" type="text" >
                              <label for="discount">Enter Discount </label><div class="iconunit">%</div>
                         </div>-->
                             
                             	
                            
                        
                          
                        	 		
                      </div>
                      <div class="row">
                      	      <div class="input-field col s6">
                           <input  class="form-control " id="description" name="description" type="text"   >
 						   <label for="description">Additional Notes</label>
                        </div>                
                         <!--<div class="input-field col s6">
                               <input  class="form-control input_field-amount input_field-tax_properties" data-handel="allow-input-numeric-field" title="input-field-role-for-product-net-amount" spellcheck="false" id="txtnetamount" name="txtnetamount" type="text" readonly placeholder="Net Amount" >
                              <label for="net amount" class="active">Enter Net Amount</label>
                        </div>-->
                        
						 <!--<div class="input-field col s6">
									<select class="form-control form-control1" id="seltax" name="seltax" >
                                    	<option value="0" >Select Tax</option>
										 
									</select>
                              		<label for="product tax">Tax</label>
                         </div>-->
                      
                        <div class="input-field col s12 m6 l6">
                               <input  class="form-control "  id="txtrack" name="txtrack" type="text" >
                              <label for="hsn code">Rack/Storage Description</label>
                             </div>
                      </div>
                          
                        
                        <div class="row">
                            <div class="col s12" id="taxproperty" role="show-tax-property">
                              
                                     
                            </div>
                       </div> 
                        
                        
                        
                        
                        
                        
                      <!--BUTTON SUBMIT-->
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right" type="button" id="prdct-add-btn" name="action">Add to Bin
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
			  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Services</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Category</th>
                          <th style="text-align:left;">Subcategory</th>
                          <th style="text-align:left;">Product</th>
                          <th style="text-align:left;">Qty</th>
                          <th style="width:75px"></th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($bin){ $i=1; foreach($bin as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->cat_name?> </td>
                                <td style="text-align:left;"><?php echo $val->subcat_name?> </td>
                                <td style="text-align:left;"><?php echo $val->product_name?> </td>
                                 <td style="text-align:left;"><?php echo $val->qty?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>service/seredit/<?php echo encode($val->bin_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->bin_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
 <script type="text/javascript">
 $(document).ready(function(){
    $('#tooltipped').tooltip({delay: 50});
  });
$(document).ready(function(e) {
	$(document).on('focusout','input',function(){
		if($(this).val()!=''){$(this).removeClass('errors');$(this).parent().children('label').removeClass('labelerror');}
	});
	//GET Sub Categorie
	$(document).on('change','#selcat', function(){
	 $('#selcat').material_select();
		$('.overlay').css({'display':'flex'});
		var catid=$('#selcat').val();
	//	alert(catid);
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>product/newgetsubcategoriey",
			data:'catid='+catid,
			success: function(data){
			//	alert(data);
					$('.overlay').css({'display':'none'});
					//$('#selsubcats').parent('.select-wrapper').children('.select-dropdown').addClass('selsubinp');
					$('#selsubcats').html(data);
					$('#selsubcats').trigger('contentChanged');
				}
			})
	});
	//GET Tax Property	
	$(document).on('change','#selsubcats', function(){

		$('.overlay').css({'display':'flex'});
		var id=$(this).val();
		$.ajax({
			type:'POST',
			url:"<?php echo SITE_PATH ?>service/newgetproduct",
			data:'id='+id,
			success: function(data){ //alert(data);
					$('.overlay').css({'display':'none'});
					$('#selproducts').html(data);
					 
					$('#selproducts').trigger('contentChanged');
				 
				}
			});
	});
	//Materialize Select Calling
	$('select').on('contentChanged', function() {
    // re-initialize (update)
    $(this).material_select();
  });

//*Field Validation*//	
$('#prdct-add-btn').click(function(e) {
	 //alert(0);
     data=$('#frmbin').serialize();
	
	 var errorfield=FieldValidation();
	 if(errorfield!=1){
	 $('.overlay').css({'display':'flex'});
			$.ajax({
					type:'POST',
					url:"<?php echo  SITE_PATH ?>service/addbin",
					data:data,
					success: function(data)
					{
						alert(data);
						$('.overlay').css({'display':'none'});
						customSwalFunD("Added!", "Product item Successfully Added!", "success");
						location.reload() ;
					}
				 });
		}
		
//	
function FieldValidation(){   //error_result=1; return error_result;
error_result=0;
$('input').removeClass('errors');$('label').removeClass('labelerror');$('select').removeClass('errors');
var values = {
	
	'category':$('#selcat').val(),
	'subc':$('#selsubcats').val(),
	'product':$('#selproducts').val(),
	'units':$('#selunit').val(),
	'quantity':$('#quantity').val(),
	'reason':$('#reason').val()
  }
    	if(values.category == 0){
           $('#selcat').parent().children('.select-dropdown').addClass('errors');
		   $('#selcat').parent().parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		
		if(values.subc == 0){
		    $('#selsubcats').parent().children('.select-dropdown').addClass('errors');
		    $('#selsubcats').parent().parent().children('label').addClass('labelerror');
            error_result=1;
        }  
		if(values.product == 0){
		   $('#selproducts').parent().children('.select-dropdown').addClass('errors');
		   $('#selproducts').parent().parent().children('label').addClass('labelerror');
            error_result=1;
        }
		 if(values.units == 0){
		     $('#selunit').parent().children('.select-dropdown').addClass('errors');
		     $('#selunit').parent().parent().children('label').addClass('labelerror');
            error_result=1;
             
        }
		
		if(values.quantity == ''){
            $('#quantity').addClass('errors');
			$('#quantity').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		    if(values.reason == ''){
           $('#reason').addClass('errors');
		   $('#reason').parent().children('label').addClass('labelerror');
            error_result=1;
        } 
		return error_result;
	}
  });	
});

function alreadyexistalert(){
	
	 swal({
                            title: "Error",
							   text: "Tax Type Already Exist",
							   showCancelButton: true,
							   confirmButtonText: "OK",
							   cancelButtonText: "Cancel ",
							   customClass:"swal-delete",
                         	 }).then(function(){
							  
							   btnaddprotype();
							  
							  });
	}
function btnaddprotype(){
								
		  					  $('#selptype').material_select();
							  $('#selptype').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Tax Type',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Tax Type " name="txtprotype" spellcheck="false" id="txtprotype" type="text"  ><label for="first_name">Tax Type</label></div></div><div class="row"><div class="input-field col s12"><input autofocus="autofocus" placeholder="Enter Tax Type Percentage" name="txtproper" spellcheck="false" id="txtproper" type="text" class="number-check"  ><label for="first_name" class="active">Tax Type Percentage</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtprotype=$("#txtprotype").val();
									var txtproper=$("#txtproper").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   if(txtprotype==''){ 
											$('#txtprotype').parent().children('label').addClass('labelerror');
											$('#txtprotype').addClass('errors');
											$('#txtprotype').attr("placeholder", "Please enter Product type");
										err=1;
									}
									if(txtproper==''){ 
											$('#txtproper').parent().children('label').addClass('labelerror');
											$('#txtproper').addClass('errors');
											$('#txtproper').attr("placeholder", "Please enter Product type percentage");
										err=1;
									}
									return err;	
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newprotype",
														data:"txtprotype="+txtprotype+"&txtproper="+txtproper,
														success:function(data){
															 $('.overlay').css({'display':'none'}); 
														if(data==1){
															alreadyexistalert();
															//reject('Tax Type Already Exist');
															}
															else{
															
																resolve();	  
															}
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >Product Type Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewprotypes",
												//	data:"catval="+cat2,
														success:function(data){ 
																$('.overlay').css({'display':'none'}); 
																$('#selptype').material_select('destroy');
																$('.nprotype').html(data);
																$('#selptype').material_select();
														}
										 			});
			  	});
	
		}
						
						
	$(document).on('click', '.btnaddprotype', function(){
		btnaddprotype();
		
		})

//Adding Sub Category Direct//
	$(document).on('click', '.btnaddsubcat', function(){	
	
		  					  $('#subcat').material_select();
							  $('#subcat').css({'display':'block'});
							//  var cat=$("#cat").val();
				swal({
						  title: 'Add New Sub Category',
						  type: 'info',
						  html:
							'<div class="row"><select style="display:block;" class="form-control form-control1" id="cat" name="cat" ><option value="0">Select Category</option><?php foreach($category as $key){	?><option value="<?php echo $key->category_id;?>"><?php echo $key->cat_name;?></option><?php }	?></select></div><div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Sub Category Name" name="txtsubcats" spellcheck="false" id="txtsubcats" type="text"  ><label for="first_name">Sub Category Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var subcatname=$("#txtsubcats").val();
								var cat=$("#cat").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors'); 
								    $('select').removeClass('errors');
								   	if(cat==0){ 
											$('#cat').parent().children('label').addClass('labelerror');
											$('#cat').addClass('errors');
											$('#cat').attr("placeholder", "Please Select a Category ");
										err=1;
									}
								   
									if(subcatname==''){ 
											$('#txtsubcats').parent().children('label').addClass('labelerror');
											$('#txtsubcats').addClass('errors');
											$('#txtsubcats').attr("placeholder", "Please enter Sub Category Name");
										err=1;
									}
								
									
									return err;	
									
									
									
							}
								if(ev==0){
								
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newsubcategory",
														data:"txtsubcats="+subcatname+"&cat="+cat,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
								  $('#subcat').material_select();
								  var cat2=$("#cat").val();
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >CategoryAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewsubcats",
													data:"catval="+cat2,
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selsubcats').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
															//	$('#btnadnsub').remove(); 
																$('.nsubcat').html(data);
																$('#selsubcats').material_select();
															
														}
										 			});
	/*	setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
	
	//adding category Direct//
		$(document).on('click', '.btnaddcat', function(){	
	
		  				
							
				swal({
						  title: 'Add New Category',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Category Name" name="txtcats" spellcheck="false" id="txtcats" type="text"  ><label for="first_name">Category Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var catname=$("#txtcats").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtcats==''){
											$('#txtcats').parent().children('label').addClass('labelerror');
											$('#txtcats').addClass('errors');
											$('#txtcats').attr("placeholder", "Please enter Category Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newcategory",
														data:"txtcats="+catname,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									  $('#selcat').material_select();
								var cat2= $('#selcat').val();
									$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New Category Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewcats",
														data:"cat="+cat2,
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selcat').material_select('destroy');
																$('.ncat').html(data);
																$('#selcat').material_select();
														
														}
										 			});
		
		/*setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
	
	$(document).on('click', '.btnaddunit', function(){	
	
		  				
							
				swal({
						  title: 'Add New Mesurement unit',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Mesurement Name" name="munit" spellcheck="false" id="munit" type="text"  ><label for="first_name">Mesurement Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var unitname=$("#munit").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(unitname==''){
											$('#munit').parent().children('label').addClass('labelerror');
											$('#munit').addClass('errors');
											$('#munit').attr("placeholder", "Please enter a Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/newmesureunit",
														data:"munit="+unitname,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New MesurmentAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewmesureunit",
													
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#selunit').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
																$('#btnaddunit').remove(); 
																$('.nunit').html(data);
																$('#selunit').material_select();
															
														}
										 			});
		/*setTimeout(function(){
			location.reload() ;
			},600)
		*/
			 
			  	});
})
	$(document).on('click', '.btnaddhsn', function(){	
	
		  				
							
				swal({
						  title: 'Add New Hsn Code',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Hsn Code" name="hsn" spellcheck="false" id="hsn" type="text"  ><label for="first_name">Hsn Code</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var name=$("#hsn").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(name==''){
											$('#hsn').parent().children('label').addClass('labelerror');
											$('#hsn').addClass('errors');
											$('#hsn').attr("placeholder", "Please enter a valid Code.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/hsn",
														data:"hsn="+name,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
										$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Suscess</div>',
		  html:'<div class="tst1" >New HsnAdded</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		
			 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewhsn",
													
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#txthsncode').material_select('destroy');
															//console.log(data);
																//  $('#selunit').remove();  
																$('#btnaddhsn').remove(); 
																$('.nhsn').html(data);
																$('#txthsncode').material_select();
															
														}
										 			});
		/*setTimeout(function(){
			location.reload() ;
			},600)
		*/
			 
			  	});
	})
	
		//adding category Direct//
		$(document).on('click', '.btnaddmanu', function(){	
	
		  				
							
				swal({
						  title: 'Add New Manufacturer',
						  type: 'info',
						  html:
							'<div class="row"><div class="input-field col s12"><input role="tax-name-content" autofocus="autofocus" placeholder="Enter Manufacturer Name" name="txtmanus" spellcheck="false" id="txtmanus" type="text"  ><label for="first_name">Manufacturer Name</label></div></div>',
						  showCloseButton: true,
						  showCancelButton: true,
						  customClass: 'swal-form',
						  focusConfirm: false,
						  confirmButtonText:'Ok',
						  cancelButtonText: 'Cancel',
						  	    preConfirm: function() {
    						return new Promise(function(resolve,reject) {
      								var txtmanus=$("#txtmanus").val();
    								var ev=val();
							function val(){
								err=0;
									$('label').removeClass('labelerror');
     							   $('input').removeClass('errors');
									if(txtmanus==''){
											$('#txtmanus').parent().children('label').addClass('labelerror');
											$('#txtmanus').addClass('errors');
											$('#txtmanus').attr("placeholder", "Please enter Manufacturer Name.");
										err=1;
										}
									return err;	
							}
								if(ev==0){
										$('.overlay').css({'display':'flex'});
										 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/addnewmanufacturer",
														data:"txtmanus="+txtmanus,
														success:function(data){ 
															$('.overlay').css({'display':'none'}); 
																resolve();	  
														}
										 			});
								}
								else{
								  reject();
									}
						})
								}
								}).then(function () {
									//  $('#manufacturer').material_select();
							//	var txtmanus2= $('#txtmanus').val();
									$('.overlay').css({'display':'flex'});
									swal({
		  title: '<div class="tst" >Success</div>',
		  html:'<div class="tst1" >New Manufacturer Added</div>',
		  type: 'success',
		  customClass: 'swal-delete',
		})
		 $.ajax({
														type:"post",
														url: "<?php echo ADMIN_PATH ?>product/getnewmanufacturer",
													
														success:function(data){ 
														
															$('.overlay').css({'display':'none'}); 
															//	resolve();
														  $('#manufacturer').material_select('destroy');
																$('.nmanu').html(data);
																$('#manufacturer').material_select();
														
														}
										 			});
		
		/*setTimeout(function(){
			location.reload() ;
			},600)*/
		
			 
			  	});
	
	
	
	})
</script>
    
      





    




    
    
    
    
    
    
    
    
    

