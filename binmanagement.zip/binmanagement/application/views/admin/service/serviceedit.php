

  <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
	float:right;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
.file-field .btn {
        float: right;
    position: relative;
}
/*.vname{
display:none;	
	}*/
	#vmid{
display:none;	
	}
</style>
 <!--breadcrumbs start-->
          
          <!--breadcrumbs end-->

<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6">
                <div class="card-panel">
                  <div class="row">
                  <form role="form" name="frmservice" id="frmservice"  method="post" enctype="multipart/form-data">
                      <div class="row">

                        
                        <div class="input-field col s12 m6 s6" id="vname">
                        
                          <input  type="text" placeholder="Name" id="sname" name="sname" value="<?php echo $edit[0]->ser_name;?>">
                          <input type="hidden" id="hdnid" name="hdnid" value="<?php echo encode($edit[0]->ser_id); ?>">    
                          <label for="first_name">Name</label>
                        </div>
                                                                    
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Address" id="address" name="address" value="<?php echo $edit[0]->ser_address;?>">
                          <label for="first_name">Address</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                          	<input  type="text" placeholder="Product" id="product" name="product" value="<?php echo $edit[0]->ser_product;?>">
                          <label for="first_name">Product</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                            <input type="text" class="datepicker" id="yrofmanu" name="yrofmanu" value="<?php echo $edit[0]->yr_of_manu;?>">
                          	<label for="first_name">Year of Manufacturing</label>
                        </div>
                        
                        <div class="input-field col s12 m6 s6">
                        <select name="warranty" id="warranty">
                          <option value="">Select Warranty Type </option>
                          <option value="1"<?php if($edit[0]->ser_warranty==1) { echo 'selected';} ?>>Under Warranty</option>
                          <option value="2"<?php if($edit[0]->ser_warranty==2) { echo 'selected';} ?>>Out of Warranty </option>
                          </select>
                        </div>
                          <div class="input-field col s12 m6 s6">
                          	<input  type="text" name="cmplnts" id="cmplnts"  placeholder="Complaints description" value="<?php echo $edit[0]->ser_complaints;?>">
                          <label for="first_name">Complaints</label>
                        </div>
                        <div class="input-field col s12 m6 s6">
                            <input type="text" class="datepicker" id="exdeldate" name="exdeldate" value="<?php echo $edit[0]->ser_delivery_date;?>">
                          	<label for="first_name">Expected delivery date</label>
                        </div>
                        
                      
                        
                        <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="mobile" id="mobile"  placeholder="Mobile No." value="<?php echo $edit[0]->ser_mobile;?>">
                          <label for="first_name">Mobile</label>
                        </div>
                        
                         <div class="input-field col s12 m6 s6">
                          	<input  type="number" name="altnumber" id="altnumber"  placeholder="Alternative No." value="<?php echo $edit[0]->ser_alternative;?>">
                          <label for="first_name">Alternative Contact No.</label>
                        </div>  
                         <div class="input-field col s12 m6 s6">
                          	<input  type="email" name="semail" id="semail"  placeholder="Email"  value="<?php echo $edit[0]->ser_email;?>">
                          <label for="first_name">Email</label>
                        </div>
                                  </div>
                      
                      <div class="row">
                       
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnsub" type="button"  name="btnsub">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
			  <div class="col s12 m6 l6">
                    <div class="card-panel">
                      <h4 class="header2">All Product</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:20px;text-align:center;">SN</th>
                          <th style="text-align:left;">Product</th>
                          <th style="text-align:left;">Name</th>
                          <th style="text-align:left;">Mobile No.</th>
                          <th style="width:75px">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php  if($service){ $i=1; foreach($service as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:20px;text-align:center;"><?php echo $i ?></td>
								<td style="text-align:left;"><?php echo $val->ser_product?> </td>
                                <td style="text-align:left;"><?php echo $val->ser_name?> </td>
                                <td style="text-align:left;"><?php echo $val->ser_mobile?> </td>
								<td style="width:75px"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>service/seredit/<?php echo encode($val->ser_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->ser_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
			  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>


	
	
	
<script >


	
$(document).ready(function(e) {
		
	$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false, // Close upon selecting a date,
	format: 'yyyy-mm-dd',
    container: undefined // ex. 'body' will append picker to body
  });
	//------insert -------------//
	

		
	
	
   
       	 $("#btnsub").click(function(e) {
			 
			var e=validation();
		 
			if(e==0){
			$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>service/updateservice";
  			var redirect = "<?php echo ADMIN_PATH?>service";
  			var form = document.forms.namedItem("frmservice");  
		              
			var oData = new FormData(document.forms.namedItem("frmservice"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
				$('.overlay').css({'display':'none'});
				//alert(oReq.responseText);
					
				 /* if(oReq.responseText==1){
					 customSwalFunD("Exist","Phone number already Exist");
					 }
					else if(oReq.responseText==2){
					// swal("Exist!", "Email already Exist!", "error");
					  customSwalFunD("Exist","Email already Exist");
					 }
					 else
					 {	 */
					  customSwalFunD("Success","Sucessfully Added");
					  document.location = redirect;
					 /* } */
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

            var values = {
                                    'sname':$('#sname').val(),
									'address':$('#address').val(),
									'product':$('#product').val(),
									'yrofmanu':$('#yrofmanu').val(),
									'warranty':$('#warranty').val(),
									'exdeldate':$('#exdeldate').val(),
									'cmplnts':$('#cmplnts').val(),
									'mobile':$('#mobile').val(),
									'altnumber':$('#altnumber').val()

                                 }
								 
		if(values.sname == ''){
		    $('#sname').addClass('errors');
			$('#sname').attr("placeholder", "Please enter name")
		    $('#sname').parent().children('label').addClass('labelerror');
            error=1;
        } 
	   if(values.address == ''){
		     $('#address').addClass('errors');
			$('#address').attr("placeholder", "Please enter address")
		    $('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 
			  if(values.product == ''){
            $('#product').addClass('errors');
			$('#product').attr("placeholder", "Please enter product")
		    $('#product').parent().children('label').addClass('labelerror');
            error=1;
        } 

        if(values.yrofmanu == ''){
            $('#yrofmanu').addClass('errors');
			$('#yrofmanu').attr("placeholder", "Please enter Year of Manufacturing")
		    $('#yrofmanu').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		 if(values.warranty == ''){
		    $('#warranty').parent().children('.select-dropdown').addClass('errors');
			$('#warranty').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
				
		if(values.exdeldate == ''){
            $('#exdeldate').addClass('errors');
            $('#exdeldate').attr("placeholder", "Please enter Expected delivery date")
		    $('#exdeldate').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.cmplnts == ''){
            $('#cmplnts').addClass('errors');
            $('#cmplnts').attr("placeholder", "Please enter Complaints")
		    $('#cmplnts').parent().children('label').addClass('labelerror');
            error=1;
        }
        if(values.mobile == ''){
            $('#mobile').addClass('errors');
            $('#mobile').attr("placeholder", "Please enter Mobile No.")
		    $('#mobile').parent().children('label').addClass('labelerror');
            error=1;
        } 	
         	
		if(values.altnumber == 0){
            $('#altnumber').addClass('errors');
            $('#altnumber').attr("placeholder", "Please enter Alternative No.")
		    $('#altnumber').parent().children('label').addClass('labelerror');
            error=1;
        }  	
         	
         	
	
        return error;
    }
	
	// Note: This example requires that you consent to location sharing when
      // prompted by your browser. If you see the error "The Geolocation service
      // failed.", it means you probably did not give permission for the browser to
      // locate you.
    /*  var map, infoWindow;
      
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 6
        });
        infoWindow = new google.maps.InfoWindow;

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
			  
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            $('#latitude').val(position.coords.latitude);
			$('#longitude').val(position.coords.longitude);  
            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            infoWindow.open(map);
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
     
      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }*/
	
	
	
	
});
	// ---------- < Delete salesman   > ---------- //

$(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
				
 swal({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then(function () {
						 $.ajax({
                         type:"post",
                         url: "<?php echo ADMIN_PATH ?>service/deleteService",
                         data:"id="+id,
						 success:function(data){ 											
												 swal(
														'Deleted!',
														'Your file has been deleted.',
														'success'
													 )
														location.reload() ;
	
											   }
			    
	});
  	})                    
			  
});
		
		
		
	</script>
    
          





    




    
    
    
    
    
    
    
    
    

