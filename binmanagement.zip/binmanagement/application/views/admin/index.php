<?php
//include("header.php");
?>
	<style>
	.red.accent-2 {
    background-color: #4ab3ec !important;
}
.deep-orange.accent-2 {
    background-color: #5081bb !important;
}
	</style>	

        <!-- START CONTENT -->
        <section id="content">
          <!--start container-->
          <div class="container">
            <!--card stats start-->
            <div id="card-stats">
               <?php if($advtop){?>
              <div class="row">
        
              <a href="https://<?php echo $advtop[0]->adv_website?>">
            <img src="<?php echo SITE_PATH.$advtop[0]->adv_img?>" style="width: 100%;max-height: 130px;padding: 0px 12px;" /><a>
              </div>   <?php } ?>
              <div class="row">
                
                <div class="col s12 m6 l4">
                  <div class="card">
                    <div class="card-content red accent-2 white-text">
                      <p class="card-stats-title">
                       Total Categories</p>
                      <h4 class="card-stats-number"><?php echo $categories ?></h4>
                      
                    </div>
                    <!--<div class="card-action red darken-1">
                      <div id="sales-compositebar" class="center-align"></div>
                    </div>-->
                  </div>
                </div>
                <div class="col s12 m6 l4">
                  <div class="card">
                    <div class="card-content teal accent-4 white-text">
                      <p class="card-stats-title">
                       Total Sub Categories</p>
                      <h4 class="card-stats-number"><?php echo $subcategories; ?></h4>
                      
                    </div>
                    <!--<div class="card-action teal darken-1">
                      <div id="profit-tristate" class="center-align"></div>
                    </div>-->
                  </div>
                </div>
                <div class="col s12 m6 l4">
                  <div class="card">
                    <div class="card-content deep-orange accent-2 white-text">
                      <p class="card-stats-title">
                         Total items in Bin</p>
                      <h4 class="card-stats-number"><?php echo $totalbin; ?></h4>
                      
                    </div>
                    <!--<div class="card-action  deep-orange darken-1">
                      <div id="invoice-line" class="center-align"></div>
                    </div>-->
                  </div>
                </div>
              </div>
            </div>
            <!--card stats end-->
            <!--chart dashboard start-->
            <div id="chart-dashboard">
              <div class="row">
                <?php foreach($catbin as $key){ ?>
                <div class="col s12 m6 l4">
                <div class="card-move-up teal accent-4 waves-effect waves-block waves-light">
                      <div class="move-up">
                        <p class="margin white-text" style="text-align:center;font-size:20px;">Product in Bins</p>
                        <p style="text-align:center;color:#fff;font-weight:bold;font-size:16px;"><?php echo $key->product_name; ?></p>
                        <p style="text-align:center;color:#fff;font-weight:bold;font-size:26px;"><?php echo $key->total; ?></p>
                         
                      </div>
                    </div>
                  
                </div>
                <?php } ?>
                 
                <?php //var_dump( $radarchart); ?>
				 
				
				
              </div>
            </div>
            <?php if($advbtm){?>
            <div class="row" style="    margin-bottom: 40px;">
        
              <a href="https://<?php echo $advbtm[0]->adv_website?>">
            <img src="<?php echo SITE_PATH.$advbtm[0]->adv_img?>" style="width: 100%;max-height: 130px;padding: 0px 12px;" /><a>
              </div>    <?php  } ?>
            <!-- //////////////////////////////////////////////////////////////////////////// -->
          </div>
          <!--end container-->
        </section>
       
      </div>
      <!-- END WRAPPER -->
    </div>
    <!-- END MAIN -->
    <!-- //////////////////////////////////////////////////////////////////////////// -->
 <script>

    


 var canvas = document.getElementById('trending-bar-chart');
fitToContainer(canvas);

function fitToContainer(canvas){
  // Make it visually fill the positioned parent
  canvas.style.width ='100%';
  canvas.style.height='100%';
  // ...then set the internal size to match
  canvas.width  = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;

}




	var dataBarChart = {
		labels: [<?php  foreach($barchart as $bchart1) {  echo '"'.$bchart1->sweek.'",';} ?>],
		datasets: [{
			label: "Bar dataset",
			fillColor: "#5081bb",
			strokeColor: "#5081bb",
			highlightFill: "rgba(70, 191, 189, 0.4)",
			highlightStroke: "rgba(70, 191, 189, 0.9)",
			data: [<?php  foreach($barchart as $bchart) {  echo (int)$bchart->tamt.",";  } ?>]
		}]
	};


var radarChartData = {
		labels: [<?php  foreach($radarchart as $rchart1) {  echo '"'.$rchart1->cat_name.'",';} ?>],
		datasets: [{
			label: "First dataset",
			fillColor: "rgba(255,255,255,0.2)",
			strokeColor: "#fff",
			pointColor: "#00796b",
			pointStrokeColor: "#fff",
			pointHighlightFill: "#fff",
			pointHighlightStroke: "#fff",
			data: [<?php  foreach($radarchart as $rchart) {  echo (int)$rchart->pcount.",";  } ?>]
		}],
	};
 </script>