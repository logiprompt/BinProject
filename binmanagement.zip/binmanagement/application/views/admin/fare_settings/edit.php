 

<!--start container-->
<style>
  .addnew{
    margin: 25px 0px;
    text-align: right;
  }
  .close-icon{
    background: #ff4081;
    border-radius: 50%;
    font-size: 16px;
    padding: 2px;
    color: #fff;

  }
</style>
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Edit Fare</h4>
                      <div class="row">
                       <form role="form" name="frmfare" id="frmfare" method="post">
                         
                        
                      
                          <div class="row"> 
                          <div class="col s12"> 
                            <label for="first_name">Brand Name</label>
                              <select name="brand" id="brand">
                                <option value="">Choose brand....</option>
                                <?php foreach($brands as $bval) {?>
                                
                                
                                <option <?php if($details->brand_id==$bval->man_id){ echo 'selected="selected"';} ?> value="<?php echo encode($bval->man_id);?>"><?php echo $bval->man_title ;?></option>
                              <?php } ?>
                              </select>
                          </div>
                        </div>
                       
                       <div class="row"> 
                          <div class="col s12 nmodel" > 
                            <label for="first_name">Model</label>
                              <select name="model" id="model" >
                                <option value="">Choose model....</option>
                              <?php foreach($model as $val3) {
								  if($details->brand_id==$val3->brand_id){
								  
								  ?>
                                <option <?php if($details->model_id==$val3->model_id){ echo 'selected="selected"';} ?> value="<?php echo encode($val3->model_id);?>"><?php echo $val3->model_name ;?></option>
                              <?php }} ?>
                              </select>
                          </div>
                        </div>
                        
                         <div class="row"> 
                          <div class="col s6"> 
                            <label for="first_name">Minimun Charge</label>
                              <input type="text" value="<?php if(isset($details)){ echo $details->min_charge;} ?>" name="mincharge" id="mincharge" >
                               <input type="hidden" value="<?php if(isset($details)){ echo encode($details->fare_settings_id);} ?>" name="hdid" id="hdid" >
                          </div>
                        
                          <div class="col s6"> 
                            <label for="first_name">Minimun Charge KM</label>
                              <input value="<?php if(isset($details)){ echo $details->min_charge_km;} ?>" type="text" name="minkm" id="minkm">
                          </div>
                        </div>
                         <div class="row"> 
                          <div class="col s12"> 
                            <label for="first_name">Km/rate</label>
                              <input value="<?php if(isset($details)){ echo $details->rate_per_km;} ?>" type="text" name="kmrate" id="kmrate" >
                          </div>
                        </div>
                        <div class="row"> 
                          <div class="col s12"> 
                            
                            <label for="first_name"> Waiting Time ( in HH:mm )</label>
                             <!--  <input type="text" name="waittime" id="waittime"> -->
                             <input value="<?php if(isset($details)){ echo $details->wait_time;} ?>" type="text" class="timepicker" name="waittime" id="waittime">
                          </div>
                        </div>
                         <div class="row"> 
                          <div class="col s6"> 
                            <label for="first_name">After Waiting Time</label>
                            <input value="<?php if(isset($details)){ echo $details->after_wait_time;} ?>" type="text" class="timepicker" name="afterwaittime" id="afterwaittime">
                              <!-- <input type="text" name="afterwaittime" id="afterwaittime"> -->
                          </div>
                        
                          <div class="col s6"> 
                            <label for="first_name">Amount</label>
                              <input value="<?php if(isset($details)){ echo $details->after_wait_time_amt;} ?>" type="text" name="amount" id="amount">
                          </div>
                        </div>
                         
                        
                        
                         
                        
                          <div class="row">
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit" style="margin-right:9px;">Update
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2"> All Fare</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                           <th style="width:100% !important;text-align:left;">Brand</th>
                          <th style="width:100% !important;text-align:left;">Model</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                       
                           
              <?php $i=1; foreach($fare as $val ) {?>
           
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i;?></td>
                <td style="width:100% !important;text-align:left;"><?php echo $val->man_title;?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->model_name;?></td>
								<td > 
     <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH.'faresettings/edit/'.encode($val->fare_settings_id);?>">
								<i class="material-icons">mode_edit</i>
								</a>
                                    
								<a class="btndlts btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->fare_settings_id)?>">
									<i class="material-icons">delete</i>
								</a>
                </td>
								
							</tr>
              <?php $i++; }?>
						
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

  
<script type="text/javascript">

 
$(document).ready(function(e) {

  $(document).on('change','#brand', function()
{

var brand=$(this).val();			
	
	$.ajax({
		type:'post',
		url:"<?php echo ADMIN_PATH ?>faresettings/get_model",
		data:"brand="+brand,
	
		success:function(data)
		{
			console.log(data);
			// $('.overlay').css({'display':'none'});
               $('#model').material_select('destroy');
               $('#model').html(data);
               $('#model').material_select();
			
		}
	
	});
				
});

   
   $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: false, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button,
    container: undefined, // ex. 'body' will append picker to body
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });

    $("#btnsubmit").click(function(e) {
			
			var ev=validation();
  //ev=1;
			if(ev==0){ 
			$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH;?>faresettings/update";
  		var redirect="<?php echo ADMIN_PATH;?>faresettings";
  			var form = document.forms.namedItem("frmfare");                        
			  var oData = new FormData(document.forms.namedItem("frmfare"));           
        var oReq = new XMLHttpRequest();
        oReq.open("POST", url,  true);   
        oReq.onload = function(oEvent) { console.log(oReq.responseText);

  				$('.overlay').css({'display':'none'});
  				if(oReq.responseText==1){
  					  swal("Exist", "Model Alredy Exist in Fare settings", "error");
  					 }
  					 else
  					 {
  					  customSwalFunD("Success", "Fare settings has been Added");		
  						document.location=redirect;
  					 }
					
					 }
                oReq.send(oData);
                e.preventDefault();   
      
						}
   	});
	//----end insert--------------------//	
	function validation(){

        error=0;

      $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
      $('select').removeClass('errors');
      $('textarea').removeClass('errors');
      $('.file_wrap').removeClass('errors'); 


         var array=[$('#brand'),$('#model'),$('#mincharge'),$('#minkm'),$('#kmrate'),$('#waittime'),$('#afterwaittime'),$('#amount')];


        for(var i=0;i<array.length;i++){
        
         if( $(array[i]).length<=0){
            error=1;
            continue;
          }

          if(array[i].val()==''){

             if($(array[i]).is("select")) {
             array[i].parent().children('.select-dropdown').addClass('errors');
             array[i].parent().parent().children('label').addClass('labelerror');
             error=1;
            }
            else  if($(array[i]).is("input:text")){
             
              array[i].addClass('errors');
              array[i].parent().children('label').addClass('labelerror');
              error=1;
            }
          }

        }
 
        return error;
    }
	


	
	// ---------- < Delete Category   > ---------- /
		
		   $(document).on('click', '.btndlts', function(){
                var id=$(this).attr('rel');  
				var redirect="<?php echo ADMIN_PATH;?>faresettings";
          swal({
                 title: "Are you sure?",
							   text: "Delete this Fare settings",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:"swal-delete",
							   closeOnConfirm: true,
							   closeOnCancel: true 
              }).then(function(){
							  $('.overlay').css({'display':'flex'});
                                      $.ajax({
                                          type:"post",
                                          url: "<?php echo ADMIN_PATH;?>faresettings/delete",
                                          data:"id="+id,
                                          success:function(data){ 
                    											  $('.overlay').css({'display':'none'});
                    											 	customSwalFunD("Success", "Fare settings has been Deleted");	
                                    				document.location=redirect;
                                          }

                                      });
					
				          });

			  
        });
		// ---------- < Delete Category ENDS > ----------
	
});
</script>


 
