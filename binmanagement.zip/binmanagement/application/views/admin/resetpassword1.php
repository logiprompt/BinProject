
<style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
			 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
</style>


		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Reset Password</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmresetpwd" id="frmresetpwd" action="" method="post">
							

	<fieldset>
							  	<div class="form-group">
								<input class="form-control form-control1" placeholder="Old password" name="oldpwd" id="oldpwd" type="password" onblur="checkoldpwd()" >
							</div>
                            <div class="form-group">
								<input class="form-control form-control1" placeholder="New Password" name="newpwd" id="newpwd" type="password" >
							</div>
                            <div class="form-group">
								<input class="form-control form-control1" placeholder="Confirm Password" name="cnfrmpwd" id="cnfrmpwd" type="password" >
							</div>
                     
                            <div class="col-md-6" >
                              <a href="javascript:void(0)" class="btn btn-primary btn-block lg" id="btnsubmit" style="float:right:">Submit</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
								
                            
						<!--	    <div class="col-md-5"></div>   <div class="text-center "><a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                    <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Submit</a>
                         
                          </div>
                            <div class="col-md-4">
                    
                          
                         <a href="index.php" class="btn btn-primary btn-block lg">Cancel</a>
                        </div></div>-->
                      
                            </fieldset>
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
    <!-- /.row -->
		
        
        
        
        
	</div>
    
    <script src="<?php echo ADMIN_STYLEPATH ?>js/jquery-1.11.1.min.js" type="text/javascript"></script>
        <script src="<?php echo ADMIN_STYLEPATH ?>js/SweetAlert.min.js" type="text/javascript"></script>



<script type="text/javascript">

$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				//alert(1);
  			var url="<?php echo ADMIN_PATH?>resetpassword/checkoldpwd";
  			//var redirect = "<?php echo ADMIN_PATH?>area";
  			var form = document.forms.namedItem("frmresetpwd");                        
			var oData = new FormData(document.forms.namedItem("frmresetpwd"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { 
				//alert(oReq.responseText)//);
					 
				 if(oReq.responseText==1){
					
					swal("Sucessfully!", "Sucessfully Added!", "success")
					
					 }
					 else if(oReq.responseText==2)
					 {
						swal("error!", "Old Password wrong!", "error")
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
        

            var values = {
                                    'oldpwd':$('#oldpwd').val(),
									'newpwd':$('#newpwd').val(),
									'cnfrmpwd':$('#cnfrmpwd').val(),

                                 }

        if(values.oldpwd == ''){
            $('#oldpwd').addClass('errors');
            $('#oldpwd').attr("placeholder", "Please enter old password.")
			$('#oldpwd').css({'border':'1px solid red'});
		    $('#oldpwd').addClass('errorInput');
            error=1;
        } 
		 if(values.newpwd == ''){
            $('#newpwd').addClass('errors');
            $('#newpwd').attr("placeholder", "Please enter new password.")
			$('#newpwd').css({'border':'1px solid red'});
		    $('#newpwd').addClass('errorInput');
            error=1;
        } 
		 if(values.cnfrmpwd == ''){
            $('#cnfrmpwd').addClass('errors');
            $('#cnfrmpwd').attr("placeholder", "Please enter confirm password.")
			$('#cnfrmpwd').css({'border':'1px solid red'});
		    $('#cnfrmpwd').addClass('errorInput');
            error=1;
        } 
		 if(values.cnfrmpwd != values.newpwd){
			
			 
            $('#cnfrmpwd').addClass('errors');
            $('#cnfrmpwd').attr("placeholder", "Please enter confirm password.")
			$('#cnfrmpwd').css({'border':'1px solid red'});
		    $('#cnfrmpwd').addClass('errorInput');
			swal("error!", "new password and confirm password mismatch!", "error")
			document.getElementById("cnfrmpwd").value="";
            error=1;
        } 
		
		
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this service",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          },
						   function(isConfirm) {
                              if (isConfirm) { 
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>area/deleteArea",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully deleted!", "success")
                                            }

                                        });
					   }

				          });

		
			  
        });
		
		// ---------- < Delete Category ENDS > ----------
	});	
		function checkoldpwd(){
	//	alert(0);
	if( $('#oldpwd').val()!=''){
			var textboxvalue = $('#oldpwd').val();
			//alert(textboxvalue);
			
			 $.ajax({

                          type:"post",

                          url: "<?php echo  ADMIN_PATH ?>resetpassword/checkoldpwds",

                          data:"id="+textboxvalue,


                    success:function(data){ //alert(data);
					
					 if(data==2){
						  swal("error!", "Old Password Wrong!", "error")
						//   
			document.getElementById("oldpwd").value="";

				 }
                    }

                });
				

			  }

		}

/*$(document).on('focusout','#oldpwd', function(){
	alert(0)
			var id=$(this).val();
			if(id!='')
			{
				alert(1)*/
				//ajax checking
		/*	$.ajax({
                type:"post",
                 url: "<?php echo  ADMIN_PATH ?>resetpassword/checkoldpwd",
                 data:"id="+id,
                 success:function(data){ 
				 alert(data);
				)};
			}
			else{
				alert('requred');
			}*/

//});

</script>


    
    
    
    
    
    
    
    
    

