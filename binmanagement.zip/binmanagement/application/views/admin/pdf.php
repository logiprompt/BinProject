<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require('pdf/fpdf.php'); 
class RPDF extends FPDF
{
//Page header
function Title($row){
	$this->SetFont('Arial','B',15);
	$this->Cell(0,10,$row,0,0,'L');
	$this->Ln(15);
}
function Header()
{	 
}
//Page footer
function Footer()
{
	//Position at 1.5 cm from bottom
	$this->SetY(-15);
	//Arial italic 8
	$this->SetFont('Arial','I',8);
	//Page number
	$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$name=$edit->c_name;
$addr=$edit->c_address;
$tele_o=$edit->tele_o;
$tele_r=$edit->tele_r;
$mob=$edit->mob;
$email=$edit->mail;
$title=$amenity->amenity_title;
$bike=$bike;
$s_details=$edit->s_details;
$feedback=$edit->s_feedback;
$service=$edit->service_id;

$Item_title=$amenity->Item_title;
$bikeaccess=$bikeaccess;
$serjobs=$serjobs;

$his=$hist;

$time_in=$schedule->time_in;
$team=$schedule->team;
$delivary_date=$schedule->delivary_date;
$delivary_time=$schedule->delivary_time;
$amt=$schedule->amt;

$mypdf = new RPDF();
$mypdf->AddPage();

$mypdf->SetTextColor(194,8,8);
$mypdf->SetMargins(19,1,'');
$mypdf->SetX(11);
$mypdf->Title('Service Id');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);	
/*$mypdf->SetY(-12);*/
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','',$service));

$mypdf->SetMargins(19,1,'');
$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title('Customer Details');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);
$mypdf->SetX(65);	
/*$mypdf->SetLeftMargin(16);*/
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Name : '.$name)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Address : '.$addr));
$mypdf->SetX(65); 
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Telephone (Office) : '.$tele_o)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Telephone (residency) : '.$tele_r));
$mypdf->SetX(65);
 
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Mobile : '.$mob)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Email : '.$email)); 


$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title($title);
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);

foreach($bike as $val)
{
	$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','',$val->am_label.' : '.$val->am_det)); 
}
$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title('Service Details');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Details : '.$s_details)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Feedback : '.$feedback)); 

$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title($Item_title);
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);
foreach($bikeaccess as $val)
{
	$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','',$val->item_label.' : '.$val->item_det)); 
}


$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title('Jobs');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-10);
foreach($serjobs as $val)
{
	$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','',$val->titles)); 
}
$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title('Previous History');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);
foreach($his as $val)
{
	$mypdf->SetX(65);
$mypdf->MultiCell(188,9,str_replace('&nbsp;','','Description : '.$val->history_desc)); 
}
$mypdf->SetTextColor(194,8,8);
$mypdf->SetX(9);
$mypdf->Title('Job Schedule');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-14);
$mypdf->SetX(65);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','','Time in : '.$time_in)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','','Team : '.$team)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','','Delivary date : '.$delivary_date)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','','Delivary time : '.$delivary_time)); 
$mypdf->SetX(65);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','','Estimated Amount : '.$amt)); 

/*$mypdf->SetTextColor(194,8,8);
$mypdf->Title('Our Nature');
$mypdf->SetFont('Arial','',11);
$mypdf->SetTextColor(0,0,0);
$mypdf->Ln(-30);
$mypdf->MultiCell(188,6,str_replace('&nbsp;','',$nature)); 
*/
$mypdf->Output();