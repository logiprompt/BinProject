 <style>
.show-exist-sub-cat label{
	display: inline-block;
    background: rgba(100, 149, 237, 0.23);
    color: rgb(4, 4, 4);
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 1px;
    margin: 0 4px 4px;
    padding: 3px 8px;
    border-radius: 3px;
}
.show-exist-sub-cat label:first-child{
  margin-right: 0px !important; 
}
</style>


<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">New Sub Category</h4>
                      <div class="row">
                       <form role="form" name="frmsubcat" method="post" action="">
                       
                         <div class="row">
                            <div class="input-field col s12">
                              <select class="form-control form-control1" name="selcat" id="selcat">
                                    <option value="0">Choose Category</option>
                                    	<?php foreach($category as $key){?>
											
											<option value="<?php echo encode($key->category_id)?>"><?php echo $key->cat_name?></option>
											
									<?php }	?>
										
										 
									</select>
                              <label for="first_name">Select Category</label>
                            </div>
                          </div>

                        <div class="row">
                            <div class="col s12 show-exist-sub-cat" id="show-exist-sub-cat"></div>
                        </div>    
                       
                          <div class="row" style="margin-top:12px;">
                            <div class="input-field col s12">
                              <input placeholder="Enter Sub Category Name" name="txtsubcategory" id="txtsubcategory"  type="text">
                              <label for="first_name">New Sub Category</label>
                            </div>
                          </div>
                            <div class="row">
                              <div class="input-field col s12">
                                <button class="btn cyan waves-effect waves-light right" type="button" name="action" id="btnsubmit">Submit
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Sub Category</h4>
                      <div class="row">
                        <table id="datatablesub" class="mdl-data-table ajaxdatatable" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Sub Category</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody id="subcat">
                      <?php //if($subcategory) { $i=1; foreach($subcategory as $val  ){ ?>
                         
                          
							<!--<tr>
								<td style="width:10% !important;text-align:center;"><?php //echo $i ?></td>
								<td style="width:100% !important;text-align:left;" ><?php //echo $val->subcat_name?> </td>
								<td style="width:20% !important;"> 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php //echo ADMIN_PATH.'subcategory/editsubcategories/'.encode($val->subcategory_id);?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange btndlt" rel="<?php //echo encode($val->subcategory_id)?>" >
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>-->
					<?php //$i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div>
                  <!-- Form with placeholder -->
                  
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->
<style>
.btnall
{
	height:32px;
}
</style>
<script type="text/javascript">

$(document).on('change','#selcat', function(){
		$('#show-exist-sub-cat').hide();
		var catid=$(this).val();
		$('.overlay').css({'display':'flex'});
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>subcategory/getexistsubcategoriey",
			data:'catid='+catid,
			success: function(data){ 
			$('#datatablesub').dataTable().fnDestroy();
				$('.overlay').css({'display':'none'});
					$('#subcat').html(data).fadeIn('fast');
					 
				}
			})
	});

$(document).on('click','.btnall', function(){
		$('#show-exist-sub-cat').hide();
		var catid=1;
		$('.overlay').css({'display':'flex'});
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>subcategory/getallsubcategoriey",
			data:'catid='+catid,
			success: function(data){ 
			$('#datatablesub').dataTable().fnDestroy();
				$('.overlay').css({'display':'none'});
					$('#subcat').html(data).fadeIn('fast');
					 
				}
			})
	});







/*-----------------******************************------------------------------------------------------------*/
$(document).ready(function(e) {
   	//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>subcategory/addsubcategory";
  			var redirect = "<?php echo ADMIN_PATH?>subcategory";
  			var form = document.forms.namedItem("frmsubcat");                        
			var oData = new FormData(document.forms.namedItem("frmsubcat"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					$('.overlay').css({'display':'none'});
				 if(oReq.responseText==1){
					  customSwalFunD("Error","Already Exist");
					 }
					 else
					 {
						
    customSwalFunD("Sub Category has been Added"," ");   //swal alert
 setTimeout(function(){  document.location = redirect; },600)
						
						 

 					
					 }}
                oReq.send(oData);
               // ev.preventDefault();   
      
						}
   			});
	//----end insert--------------------//	
	function validation(){

        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');
        

        var values = {
                                    'category':$('#selcat').val(),
									'sucategory':$('#txtsubcategory').val(),

                                 }

        if(values.category == 0){
			
			/*	  $('#selcat').addClass('errors');
			$('#selcat').attr("placeholder", "Please enter category")
		    $('#selcat').parent().children('label').addClass('labelerror');*/
			
			$('#selcat').parent().children('.select-dropdown').addClass('errors');
			$('#selcat').parent().parent().children('label').addClass('labelerror');

          
			  error=1;
        } 
		if(values.sucategory == ''){

			 $('#txtsubcategory').addClass('errors');
			$('#txtsubcategory').attr("placeholder", "Please enter subcategory")
		    $('#txtsubcategory').parent().children('label').addClass('labelerror');
			
			  error=1;
        } 
        return error;
    }
	

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmsubcat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	
	// ---------- < Delete Category   > ---------- //
		 		    $(document).on('click', '.btndlt', function(){
						//alert()
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Sub Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   customClass:'swal-delete',
							   closeOnConfirm: true,
							   closeOnCancel: true 
                         }).then(function(){
                             
			$('.overlay').css({'display':'flex'});
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Subcategory/deletesubategories",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												$('.overlay').css({'display':'none'});
											 customSwalFunD("Success","Sub Category has been  Deleted"); 
setTimeout(function(){
    	location.reload() ;
},600)
	                              
								
                                            }

                                        });
					

				          });

		
			  
        });
	
	
	
	
	
	
});
</script>










