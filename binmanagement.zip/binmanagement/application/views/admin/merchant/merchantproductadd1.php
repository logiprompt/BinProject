
<style>

.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
		.chkbx1{
		width:100%;
		height:156px;
		/*border:1px solid red;*/
		
		
		}
		.chkbx2{
		    width: 26%;
    height: 55px;
 /*   border: 1px solid black;*/
    float: left;
    margin-left: 38px;
    margin-top: 15px;
		}
		.chkbx3{
		width:50%;
		height:100px;
		/*border:1px solid black;*/
	    float: right;
    margin-right: 20px;
		    margin-top: 5px;
		}
</style>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		</br>
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Merchant Products</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form">
							
<fieldset>
							  <div class="form-group">
									
									<select class="form-control form-control1">
                                    	<option>Product Category</option>
										<option>Option 1</option>
										<option>Option 2</option>
										<option>Option 3</option>
										<option>Option 4</option>
									</select>
								</div>
							 <div class="form-group">
									
									<select class="form-control ">
                                    	<option>Product Subcategory</option>
										<option>Option 1</option>
										<option>Option 2</option>
										<option>Option 3</option>
										<option>Option 4</option>
									</select>
								</div>
                            
                        <div class="form-group">
									
                                    <div class="chkbx1">
                                        <div class="chkbx2">
                                      <label>Products</label>
                                    </div>
                                    <div class="chkbx3">
									<div class="checkbox">
                                  
									
                                        
                                        	<label>
											<input type="checkbox" 

value="">Sim
										</label>
                                        
                                        <label>
											<input type="checkbox" 

value="">Nano Sim
										</label>
									</div>
								
									<div class="checkbox">
												<label>
											<input type="checkbox" 

value="">Reacharge Card
										</label>
									
										<label>
											<input type="checkbox" 

value="">Net Card
										</label>
									</div>
                                 
                                    </div>
						
                          </div>
                          </div>
                              <div class="col-md-6" >
                              <a href="index.php" class="btn btn-primary btn-block lg" style="float:right;">Submit</a></div>
                            	<div class="col-md-6">  <a href="index.php" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
								
							<!--<div class="text-center"><a href="index.html" class="btn btn-primary btn-block lg">Submit</a></div>-->
                            </fieldset>
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->

