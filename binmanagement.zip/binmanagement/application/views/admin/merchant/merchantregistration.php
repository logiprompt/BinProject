    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
    <link href="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />  
<style>
.file-field .btn {
    float: right;
    position: relative;
}

</style>


<!--start container-->
          <div class="container">
            <div class="section">
              <!--Basic Form-->
              <div id="basic-form" class="section">
                <div class="row">
                  
                  <!-- Form with placeholder -->
                  <div class="col s12 m6 l6">
                <div class="card-panel">
                <h4 class="header2">Add Merchant</h4>
                  <div class="row">
                   <form role="form" name="frmmerchant" id="frmmerchant">
                      <div class="row">
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Merchant Name" id="txtmerchantname" name="txtmerchantname" >
                          <label for="first_name">Merchant Name</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Merchant Id" id="txtmerchantid" name="txtmerchantid" >
                          <label for="first_name">Merchant Id</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="text"   name="address" id="address" rows="3" placeholder="Address">
                          <label for="first_name">Address</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Mobile Phone No." name="txtphone" id="txtphone"  >
                          <label for="first_name">Mobile Phone No</label>
                        </div>
                        
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Land Phone No:" id="txtlandphone" name="txtlandphone" >
                          <label for="first_name">Land Phone No:</label>
                        </div>

                         <div class="input-field col s1 m2 l2">
						   <select id="selAuth" name="selAuth">
						     <option value="Mr.">Mr</option>
							 <option value="Miss.">Miss</option>
							 <option value="Mrs.">Mrs</option>
						   </select>
						 </div>
                        <div class="input-field col s12 m4 l4">
                          <input  type="text" placeholder="Authorised Person" name="txtauthor" id="txtauthor" >
                          <label for="first_name">Authorised Person</label>
                        </div>
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="GST Resgistration No:" id="txtgst" name="txtgst" >
                          <label for="first_name">GST Reg No:</label>
                        </div>
                        
                                                
                        <div class="input-field col s12 m6">
                          	<input  type="text" placeholder="Designation" name="txtdesg" id="txtdesg" >
                          <label for="first_name">Designation</label>
                        </div>
                        <div class="input-field col m6 s12">
                          	<select  name="area" id="area">
                                    	<option value="0">Select Area</option>
										<?php foreach($area as $key){?>
											
											<option value="<?php echo $key->area_id;?>"><?php echo $key->area_name;?></option>
											
									<?php		}?>
									</select>
                                      <label for="first_name">Location</label>
                        </div>
                        <div class="input-field col m6 s12">
                        <input  type="text" placeholder="Enter Credit Date" name="date" id="date">
                          <label for="first_name" >Credit Periods</label>
                        </div>
                        <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="Latitude" name="latitude" id="citylatitude" > 
                          <label for="first_name">Latitude</label>
                        </div>
                         
                          	
               
                        <div class="input-field col m5 s10">
                          	<input  type="text" placeholder="Longitude" name="longitude" id="citylongitude" >
                          <label for="first_name">Longitude</label>
                        </div>
                      <div class="input-field col m1 s2">
                       <i class="material-icons mapview" id="map" style="color:#00bdd5;cursor: pointer;">pin_drop</i>
                        <label id="maptext" style="/*margin-top:4px;*/top:16px;left: 0;letter-spacing: 0.54px;" for="map">View Map</label>
                      </div>
                      <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="Credit Limit" name="credit" id="credit" >
                          <label for="first_name">Credit Limit</label>
                        </div>
                          <div class="input-field col m6 s12">
                          
                            	<select  name="txttaxtype" id="txttaxtype">
                                    	<option value="0">Select Tax Type</option>
                                        <option value="1">Same state sale</option>
                                        <option value="2">Inter state sale</option>
                                        </select>
                          <label for="first_name">Tax Type</label>
                        </div>
                         <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="Bank name" name="txtbankname" id="txtbankname" >
                          <label for="first_name">Bank name</label>
                        </div>
                         <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="Account name" name="txtaccountname" id="txtaccountname" >
                          <label for="first_name">Account name</label>
                        </div>
                         <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="Account number" name="txtaccountno" id="txtaccountno" >
                          <label for="first_name">Account number</label>
                        </div>
                         <div class="input-field col m6 s12">
                          	<input  type="text" placeholder="IFSC code" name="txtifsccode" id="txtifsccode" >
                          <label for="first_name">IFSC code</label>
                        </div>
                   </div>
                        
                        <!--Logo & Image-->                        
                       <!--<div class="input-field col m4 s6">
                        
                    <img src="<?php echo SITE_PATH; ?>dummy.jpg" id="imgfiles" style="border:none;width: 100px;height: 100px;float: right;border-radius:50%"">
                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Select Logo</span>
                            <input type="file" id="logofile"  name="logofile" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                            </div>-->
                             <!--<div class="input-field col m4 s6">
                        
<img src="<?php echo SITE_PATH; ?>dummy.jpg" id="imagefile" style="border:none;width: 100px;height: 100px;float: right; border-radius:50%"  ><!-- deleted ID name `imgfile` for duplicate-->
                        <!-- <div class="file-field input-field">
                            <div class="btn">
                            <span>Select Image</span>
                            <input type="file" id="imgfile"  name="imgfile" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                         <!-- <input type="file" id="imgfile"  name="imgfile" class="form-control col-md-7 col-xs-12">
                          <label for="first_name">Image</label>-->
                       <!--    </div>-->
                      
                      <!--Logo & Image new start-->
                      <style>
					  		.merchant-reg-image{
								text-align:center;width: 150px;height: 181px;margin: 0 auto;overflow: hidden;
							}
                      		.merchant-reg-image img{
								border:none;width: 150px;height: 150px;/*float: right;border-radius:50%*/		
							}
							.merchant-reg-image .file-field .btn{
								float:none;	
							}
							.merchant-reg-image .file-field.input-field{
								margin-top:0rem;
							}
							.merchant-reg-image .btn{
								border-radius: 0;height: 2.1rem;line-height: 1;padding: 0.5rem 1.2rem;width: 150px;font-size: 14px;font-weight: 600;
							}
                      </style>
                      <div class="row">
                        	  <div class="input-field col m6 s12">
                              			<div class="merchant-reg-image">
                                        <img src="<?php echo SITE_PATH; ?>dummy.jpg" id="imgfiles"/>
                                        <div class="file-field input-field">
                            <div class="btn">
                            <span>Select Logo</span>
                            <input type="file" id="logofile"  name="logofile" >
                            </div>
                            <div class="file-path-wrapper" style="display:none;" >
                            <input class="file-path validate" type="text">
                            </div>
                            </div>
                                        </div>
                              </div>
                                <div class="input-field col m6 s12">
                                	<div class="merchant-reg-image">
<img src="<?php echo SITE_PATH; ?>dummy.jpg" id="imagefile" /><!-- deleted ID name `imgfile` for duplicate-->
                     					<div class="file-field input-field">
                                <div class="btn">
                                <span>Select Image</span>
                                <input type="file" id="imgfile"  name="imgfile" >
                                </div>
                                <div class="file-path-wrapper" style="display:none;" >
                                <input class="file-path validate" type="text">
                                </div>
                            </div>
                            		</div>
                                </div>
                       </div>
                      <!--Logo & Image new end -->
                      
                      
                      <div class="row" style="margin: 10px 0 23px;">
                        <div class="row">
                          <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right"  id="btnnsubmit" type="button"  name="btnsubmit">Submit
                              <i class="material-icons right">send</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              
              
              
              
             <div class="col s12 m12 l6">
                    <div class="card-panel">
                      <h4 class="header2">Merchant List</h4>
                      <div class="row">
                        <table id="datatable" class="mdl-data-table" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="width:10% !important;text-align:center;">SN</th>
                          <th style="width:100% !important;text-align:left;">Merchant</th>
                          <th style="width:20% !important;">Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($merchant) { $i=1; foreach($merchant as $val  ){ ?>
                         
                          
							<tr>
								<td style="width:10% !important;text-align:center;"><?php echo $i ?></td>
								<td style="width:100% !important;text-align:left;"><?php echo $val->merchantname?> </td>
								<td > 
                                <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo ADMIN_PATH ?>merchant/merchantedit/<?php echo encode($val->merchant_id); ?>">
										<i class="material-icons">mode_edit</i>
									</a>
                                    
									<a class="btndlt btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange" rel="<?php echo encode($val->merchant_id);?>" href="#">
										<i class="material-icons">delete</i>
									</a>
                                
                                </td>
								
							</tr>
					<?php $i=$i+1;}}?>
                        
                      </tbody>
                    </table>
                      </div>
                    </div>
                  </div> 
              
              
                </div>
              </div>
              <!-- Form with icon prefixes -->
              
            </div>
            <!-- Inline Form -->
            
            <!-- Inline form with placeholder -->
            
            <!--Form Advance-->
            
          </div>
        </section>
        <!-- END CONTENT -->
        <!-- //////////////////////////////////////////////////////////////////////////// -->

<script type="text/javascript">


 



$(document).ready(function(e) {
	
	 document.getElementById("date").maxLength = "3";
	 
	 $('#date').keyup(function(){
		   // $('#date').val('');
		   if(isNaN($(this).val())){
               $(this).val('');
			   $(this).focus();
			}
			
		  });
	 
	
	//GET Sub Categorie
	$(document).on('change','#selcat', function(){
		var catid=$(this).val();
		alert(catid);
		$.ajax({
			type:'POST',
			url:"<?php echo ADMIN_PATH ?>product/newgetsubcategoriey",
			data:'catid='+catid,
			success: function(data){
					$('#selsubcats').html(data);
					$('#selsubcats').trigger('contentChanged');
				}
			})
	});
	
	$('select').on('contentChanged', function() {
    // re-initialize (update)
    $(this).material_select();
  });
	
	
	
   	//------insert -------------//
       	 $("#btnnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
			if(e==0){
				$('.overlay').css({'display':'flex'});
  			var url="<?php echo ADMIN_PATH?>Merchant/merchantadd";
  			var redirect = "<?php echo ADMIN_PATH?>Merchant";
  			var form = document.forms.namedItem("frmmerchant");                        
			var oData = new FormData(document.forms.namedItem("frmmerchant"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					 $('.overlay').css({'display':'none'});	
					
				 if(oReq.responseText==1){
					// alert("Exist");
						customSwalFunD("Error", "Mobile number already Exist!")
					  //alert("Exist");
					 }
					 else
					 {
						 customSwalFunD("Sucessfully!", "Sucessfully Added!", "success")
 					location.reload();
					 }
					
					 }
                oReq.send(oData);
                ev.preventDefault();   
      
						}
						else{
							
							customSwalValErr();
							}
   			});
				function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgfiles').attr('src', e.target.result);
			Materialize.fadeInImage('#imgfiles');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#logofile").change(function(){
    readURL(this);
});	
function readUR(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imagefile').attr('src', e.target.result);
			Materialize.fadeInImage('#imagefile');
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgfile").change(function(){
    readUR(this);
});	
	//----end insert--------------------//	
function validation(){
//alert($('#area').val());
        error=0;

        $('input').removeClass('errors');
	    $('label').removeClass('labelerror');
        $('select').removeClass('errors');

            var values = {
                                   
									 'merchant':$('#txtmerchantname').val(),
									  'merchant_id':$('#txtmerchantid').val(),
  								     'address':$('#address').val(),
									  'phoneno':$('#txtphone').val(),
									  'authorised':$('#txtauthor').val(),
									  'gst_regis':$('#txtgst').val(),
									 
									  'designation':$('#txtdesg').val(),
									  'location':$('#area').val(),
									  'latitude':$('#citylatitude').val(),
									  'longitude':$('#citylongitude').val(),
									   'credit':$('#credit').val(),
									    'date':$('#datepicker').val(),
										  'txttaxtype':$('#txttaxtype').val(),
										
										'logofile':$('#logofile').parent().parent().find('.file-path').val(),
										'imgfile':$('#imgfile').parent().parent().find('.file-path').val()
                                 }
								 
				 if(values.txttaxtype == 0){
           	$('#txttaxtype').parent().children('.select-dropdown').addClass('errors');
			$('#txttaxtype').parent().parent().children('label').addClass('labelerror');
            error=1;
        } 
      if(values.merchant == ''){
            $('#txtmerchantname').addClass('errors');
            $('#txtmerchantname').attr("placeholder", "Please enter merchantname.")
			$('#txtmerchantname').parent().children('label').addClass('labelerror');
            error=1;
        } 
		   if(values.credit == ''){
            $('#credit').addClass('errors');
            $('#credit').attr("placeholder", "Please enter credit.")
		  $('#credit').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.date == ''){
            $('#date').addClass('errors');
            $('#date').attr("placeholder", "Please choose date.")
		  $('#date').parent().children('label').addClass('labelerror');
            error=1;
        } 
		  if(values.imgfile == ''){
            $('.file-path').addClass('errors');
			$('.file-path').attr("placeholder", "Please select file")
		    $('.file-path').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		if(values.gst_regis == ''){
            $('#txtgst').addClass('errors');
            $('#txtgst').attr("placeholder", "Please enter GST No.");
		   $('#txtgst').parent().children('label').addClass('labelerror');
            error=1;
        }
		
		 if(values.logofile == ''){
			 
            $('.file-path2').addClass('errors');
			$('.file-path2').attr("placeholder", "Please select file")
		    $('.file-path2').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.merchant_id == ''){
            $('#txtmerchantid').addClass('errors');
            $('#txtmerchantid').attr("placeholder", "Please enter merchant id.")
			$('#txtmerchantid').parent().children('label').addClass('labelerror');
            error=1;
        } 
        if(values.address == ''){
            $('#address').addClass('errors');
            $('#address').attr("placeholder", "Please enter address.");
			$('#address').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.phoneno == ''){
            $('#txtphone').addClass('errors');
            $('#txtphone').attr("placeholder", "Please enter phone number.");
		   $('#txtphone').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
		
        if(values.authorised == ''){
            $('#txtauthor').addClass('errors');
            $('#txtauthor').attr("placeholder", "Please enter Authorised Person.");
				 $('#txtauthor').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.designation == ''){
            $('#txtdesg').addClass('errors');
            $('#txtdesg').attr("placeholder", "Please enter Designation.");
			  $('#txtdesg').parent().children('label').addClass('labelerror');
            error=1;
        } 
		
        if(values.location =='0'){
			$('#area').parent().children('.select-dropdown').addClass('errors');
			$('#area').parent().parent().children('label').addClass('labelerror');
		
            error=1;
        } 
		if(values.latitude == ''){
            $('#citylatitude').addClass('errors');
            $('#citylatitude').attr("placeholder", "Please select Latitude.")
			 $('#citylatitude').parent().children('label').addClass('labelerror');
            error=1;
        } 
		if(values.longitude == ''){
            $('#citylongitude').addClass('errors');
            $('#citylongitude').attr("placeholder", "Please select Longitude.")
			 $('#citylongitude').parent().children('label').addClass('labelerror');
            error=1;
        } 
        return error;
    }

//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmncat').each (function(){  
                    this.reset();
               }); 		 
        });
	//---------End cancel------//	
	
	
	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this Category",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          },
						   function(isConfirm) {
                              if (isConfirm) { 
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>category/deleteCategories",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully Deleted!", "success")
                                            }

                                        });
					   }

				          });

		
			  
        });
		// ---------- < Delete  ENDS > ----------
	
});
</script>
  <script type="text/javascript">
  
	$(document).ready(function(e) {
		if($('#citylatitude').val()=='' ||$('#citylongitude').val()==''  ){
			vlat=8.8932118;
			vlong=76.6141396;
			}
			else{
			vlat=$('#citylatitude').val();
			vlong=$('#citylongitude').val();
				}
		$('.ui-dialog').remove();
		$('.ui-widget-content').remove();
		$('.mapclass').each(function(index, element) {
            $(this).remove();
        });
    });
        $(function () {
			
			$(window).resize(function(){
           $('.ui-dialog').css({"width":"75%"});
		   $('.ui-dialog').css({"left":"12%"});
              });
			 $(document).delegate("#map","click",function(){  
			$('.ui-dialog').remove();
				$('.ui-widget-content').remove();
				$("#dialog").addClass("mapclass");
				 var map = ''; 
                $("#dialog").dialog({
                    modal: true,
                    title: "Pick your Google Map Value",
                    width: 900,
                    hright: 500,
                    buttons: {
                        Close: function () {
                            $(this).dialog('close');
                        }
                    },
                    open: function () {
					var map = ''; 
					$('.ui-dialog').css({"width":"75%"});
		                 $('.ui-dialog').css({"left":"12%"});
						 var markers = [];
						  var markers = "";
						  var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
                        var mapOptions = {
                            center: new google.maps.LatLng(vlat, vlong),
                            
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
					 styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						/* marker = new google.maps.Marker({
                           map: map,
						   draggable: true,
						   position: new google.maps.LatLng(23.8859, 45.0792),
                          });
						  markers.push(marker);*/
				 google.maps.event.addDomListener(window, "resize", function() {
						 var map="";
						 var styles =   [
					{
						"featureType": "all",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "all",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry",
						"stylers": [
							{
								"color": "#ffebc5"
							},
							{
								"lightness": "-10"
							}
						]
					},
					{
						"featureType": "administrative",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.country",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#b70046"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4b"
							},
							{
								"weight": "0.50"
							}
						]
					},
					{
						"featureType": "administrative.province",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "administrative.locality",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#ff850a"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "geometry",
						"stylers": [
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "administrative.neighborhood",
						"elementType": "labels",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "all",
						"stylers": [
							{
								"color": "#f2f2f2"
							}
						]
					},
					{
						"featureType": "landscape",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"saturation": "-71"
							},
							{
								"lightness": "-2"
							},
							{
								"color": "#ffebc5"
							}
						]
					},
					{
						"featureType": "poi",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "poi.park",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#70bfaf"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "all",
						"stylers": [
							{
								"saturation": -100
							},
							{
								"lightness": 45
							},
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "geometry.stroke",
						"stylers": [
							{
								"color": "#675a4c"
							}
						]
					},
					{
						"featureType": "road.highway",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#ffffff"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#675a4b"
							}
						]
					},
					{
						"featureType": "road.arterial",
						"elementType": "labels.icon",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "road.local",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "simplified"
							}
						]
					},
					{
						"featureType": "transit",
						"elementType": "all",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "all",
						"stylers": [
							{
								"color": "#7ccff0"
							},
							{
								"visibility": "on"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "geometry.fill",
						"stylers": [
							{
								"color": "#cfeae4"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.fill",
						"stylers": [
							{
								"color": "#109579"
							}
						]
					},
					{
						"featureType": "water",
						"elementType": "labels.text.stroke",
						"stylers": [
							{
								"visibility": "off"
							}
						]
					}
				];
						  var mapOptions = {
							  
				 zoomControl: true,
                  zoomControlOptions: {
                 position: google.maps.ControlPosition.LEFT_CENTER
                   },
				   fullscreenControl: true,
				   scrollwheel: false,
					navigationControl: false,
					mapTypeControl: false,
					scaleControl: false,
			         zoom: 6,
                            center: new google.maps.LatLng( vlat, vlong),
                          styles: styles,
			  disableDefaultUI: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
                        }
                        var map = new google.maps.Map($("#dvMap")[0], mapOptions);
						 var haightAshbury = {lat:vlat, lng: vlong};
						addMarker(haightAshbury, map);
						  });
		 google.maps.event.addListener(map, 'click', function(event) {
				addMarker(event.latLng, map);
				$('#citylongitude').val(event.latLng.lng());
	            $('#citylatitude').val(event.latLng.lat());
			  });
         function addMarker(location, map) {
			 
				clearMarkers();
                  markers = [];
			   marker = new google.maps.Marker({
				position: location,
				draggable: true,
				map: map
			  });
			   markers.push(marker);
			}
		function setMapOnAll(map) {
			for (var i = 0; i < markers.length; i++) {
			  markers[i].setMap(map);
			}
		  }
		  function clearMarkers() {
			setMapOnAll(null);
		  }
		 google.maps.event.addListener(marker, 'dragend', function (event) {
			$('#longitude').val(event.latLng.lng());
	        $('#latitude').val(event.latLng.lat());
			});
			
           
                    }
					
                });
				 
				
            });
        });
    </script>
    
    <div id="dialog" style="display: none">
        <div id="dvMap" style="height: 500px; width: 100%;">
        </div>
    </div>




    
    
    
    
    
    
    
    
    

