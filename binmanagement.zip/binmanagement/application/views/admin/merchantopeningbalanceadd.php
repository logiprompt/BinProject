	
    <style>
.model{
	background: rgba(34, 33, 33, 0.65) !important;
}
.lg{
    width: 67%;
    margin: 0 auto;
}
.form-control1{
	border-bottom:2px solid #13a20a;
	width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
	}
	.btnsub{
		margin-left: 138px;
    width: 72%;
    border: 1px solid red;
    height: 71px;
    margin-top: 11px;
	float:left;}
		 .panel-heading1 {
		 font-size: 18px;
    font-weight: 300;
    letter-spacing: 0.025em;
    height: 66px;
    line-height: 45px;
    background: ##ddd;
    border-bottom: 1px solid #eee;
    color: #333;
	padding: 10px 15px;
    /* background: #428bca; */
}
.h1.page-header1 {
    margin-top: 5px;
    border-bottom: 0;
}

</style>		
    
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			

		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header1"></h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Add Merchant Opening Balances</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form" name="frmopeningbalance" id="frmopeningbalance" action="" method="post">
							
<fieldset>
							  	 <div class="form-group">
									
									<select class="form-control form-control1" name="selcat" id="selcat">
                                    	<option value="0"> Category</option>
                                        <?php foreach($merchant as $val){?>
											<option value="<?php echo $val->merchant_id?>"><?php echo $val->merchantname?></option>
											
											<?php }?>
										
										
									</select>
			<!--<span id="cater" style="color:red; display:none;">errors</span>-->
            					</div>
                                	<div class="form-group">
								<input class="form-control " placeholder="Date" name="txtdate" id="date" type="date" >
							</div>
							<div class="form-group">
								<input class="form-control " placeholder="Opening Balances" id="txtopeningbalance" name="txtopeningbalance" type="text" >
							</div>
                            
							<div class="col-md-6" >
                              <a href="#" class="btn btn-primary btn-block lg" id="btnsubmit" style="float:right;">Submit</a></div>
                            	<div class="col-md-6">  <a href="" id="btncancel" class="btn btn-default btn-block lg" style="float:left;">Cancel</a></div>
                            </fieldset>
								
								
								
							
								
							</form>	
								
								
							
						
					</div>
				</div>
                	 <div class="panel-footer"></div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->


<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading1">Merchant</div>
                    <div class="box-icon">
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					<div class="panel-body">
						<div class="col-md-12">
							<form role="form" name="frmsubcat" method="post" action="">
						
						<table class="table table-striped table-bordered bootstrap-datatable datatable tbl_cat index_table" id="viewcategory">
						  <thead>
							  <tr>
								  <th>Sl.no</th>
								  <th>Category</th>
                                   <th>Opening Balance</th>
                                   <th>Date</th>
								  <th>Edit</th>
                                  <th>Delete</th>
							  </tr>
						  </thead>   
						  <tbody>
                          
                          
                           <?php  if($openigbalance) { $i=1; foreach($openigbalance as $val  ){ ?>
                         
                          
							<tr>
								<td><?php echo $i ?></td>
								<td class="center"><?php echo $val->merchantname?> </td>
                                    	<td class="center"><?php echo $val->openingbalance?> </td>
                                        <td class="center"><?php echo $val->date?> </td>
                                       
								<td class="center">
								
									<a class="glyphicon glyphicon-edit" href="<?php echo ADMIN_PATH ?>Merchantopeningbalance/edit/<?php echo $val->openbalance_id; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
                                </td>
                                <td>    
									<a class="glyphicon glyphicon-trash btndlt" rel="<?php echo $val->openbalance_id?>" href="#">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
					<?php $i=$i+1;}}?>
							
						
							
							
						  </tbody>
					  </table>   
							</form>	
								
								
							
						
					</div>
				</div>
                     </div>
                     </div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
        
        
        
        
	</div>













      <script src="<?php echo ADMIN_STYLEPATH ?>js/SweetAlert.min.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready(function(e) {
    //alert(1);


//------insert -------------//
       	 $("#btnsubmit").click(function(e) {
			//alert(1);
			var e=validation();
		if(e==0){
  			var url="<?php echo ADMIN_PATH?>Merchantopeningbalance/addopeningbalance";
  			var redirect = "<?php echo ADMIN_PATH?>Merchantopeningbalance";
  			var form = document.forms.namedItem("frmopeningbalance");                        
			var oData = new FormData(document.forms.namedItem("frmopeningbalance"));           
            var oReq = new XMLHttpRequest();
                oReq.open("POST", url,  true);   
                oReq.onload = function(oEvent) { //alert(oReq.responseText);
					//document.location = redirect;
						 if(oReq.responseText==1){
					  alert("1");
					  alert("Exist");
					 }
					 else
					 {  swal("Success!", "Products added!", "success")
 					document.location = redirect;
					 }}					
                oReq.send(oData);
                ev.preventDefault();   
      
					}
   			});
			function validation(){

        error=0;

        $('input').removeClass('errors');

        $('input').removeClass('errorInput');

        $('select').removeClass('errors');

        $('select').removeClass('errorInput');
    

            var values = {
                                    'openingbalance':$('#txtopeningbalance').val(),
									 'date':$('#date').val(),
									  'category':$('#selcat').val()

                                 }

        if(values.openingbalance ==''){
            $('#txtopeningbalance').addClass('errors');
            $('#txtopeningbalance').attr("placeholder","Please enter.")
			$('#txtopeningbalance').css({'border':'1px solid red'});
		    $('#txtopeningbalance').addClass('errorInput');
            error=1;
        } 
		 if(values.category ==0){
            $('#selcat').addClass('errors');
		  
            $('#selcat').after( "Please select category.")
			
			$('#selcat').css({'border':'1px solid red'});
		    $('#selcat').addClass('errorInput');
            error=1;
        } 
		
		 if(values.date ==''){
            $('#date').addClass('errors');
            $('#date').attr("placeholder", "Please select.")
			$('#date').css({'border':'1px solid red'});
		    $('#date').addClass('errorInput');
            error=1;
        } 
        return error;
    }
	
			//---------Cancel------//
		$('#btncancel').click(function (){
          	 $('#frmopeningbalance').each (function(){  
                    this.reset();
               }); 		 
      
	    });
	//---------End cancel------//	



	
	// ---------- < Delete Category   > ---------- //
		    $(document).on('click', '.btndlt', function(){
                var id=$(this).attr('rel');  
 swal({
                            title: "Are you sure?",
							   text: "Delete this service",
							   type: "warning",
							   showCancelButton: true,
							   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, delete it!",
							   cancelButtonText: "No, cancel ",
							   closeOnConfirm: true,
							   closeOnCancel: true 
                          },
						   function(isConfirm) {
                              if (isConfirm) { 
			
			//	alert(id);
                                        $.ajax({

                                            type:"post",

                          url: "<?php echo ADMIN_PATH ?>Merchantopeningbalance/delete",
					//	 redirect : "<?php echo ADMIN_PATH?>category",

                                            data:"id="+id,

                                            success:function(data){ //alert(data);
												
											
                                               // $(".loader").remove();
location.reload() ;
                                 // 	document.location = redirect;
	swal("Sucessfully!", "Sucessfully Added!", "success")
                                            }

                                        });
					   }

				          });

		
			  
        });
		// ---------- < Delete Category ENDS > ----------
	



});
	</script>