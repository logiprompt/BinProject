<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <title>Bin Management - A basic smart Digital Manager</title>
    <!-- Favicons-->
    <link rel="icon" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/favicon-32x32.png" sizes="32x32">
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="<?php echo ADMIN_STYLEPATH ?>images/favicon/apple-touch-icon-152x152.png">
    <!-- For iPhone -->
    <meta name="msapplication-TileColor" content="#00bcd4">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.html">
    <!-- For Windows Phone -->
    <!-- CORE CSS-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/materialize.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>css/themes/horizontal-menu/style.css" type="text/css" rel="stylesheet">
    <!-- CSS style Horizontal Nav-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/layouts/style-horizontal.css" type="text/css" rel="stylesheet">
    <!-- Custome CSS-->
    <link href="<?php echo ADMIN_STYLEPATH ?>css/custom/custom.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>css/layouts/page-center.css" type="text/css" rel="stylesheet">
    <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
    <link href="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet">
    <link href="<?php echo ADMIN_STYLEPATH ?>vendors/sweetalert/dist/sweetalert2.min.css" type="text/css" rel="stylesheet">
    <style>
    .o-v-f-p{
    position: fixed;
    background: rgba(0,0,0,0.3);
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
	display: none;
    align-items: center;
    justify-conten
	t: center;	
	z-index: 999;
}
	.f-p-p{
	display:none;
	position:fixed;
	width: 35%;
    min-height: 58px;
    top: 20%;
    left: 0;
    right: 0;
    background-color: #fafafa;
    overflow-y: auto;
    margin: auto;
    padding: 0px 26px;
    z-index: 1000;
	transform:scale(0);
	transition:scale 0.3s ease-in; 
    /*width: 405px;
    background: #fff;
    height: 325px;*/
	}
	.f-p-p .modal-content{
		padding:14px;	
	}
	.f-p-p-h-o{
	text-align: center;
    font-size: 24px;
    color: #333;	
	}
	.f-p-p-p-o{
	text-align: center;
    color: #333;	
	}
.f-p-e-show-div{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    background: rgb(228, 87, 63);
    min-height: 46px;
    padding: 0 5px;
    text-align: center;
    display: none;
    z-index: 1004;
    color: #fff;
	cursor:no-drop;
}
.successfp{
	background:rgb(65, 199, 94) !important;	
}
.m-header{
    position: absolute;
    top: 19px;
    right: 17px;
	cursor:pointer;
}
@media only screen and (max-width: 667px){
	.f-p-p{
   		width: 96%;
	    top: 10%;
	}
	.login-form {
    	width: 290px;
	}
}
    </style>
  </head>
  <body class="cyan">
    <!-- Start Page Loading -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Page Loading -->
    <div class="error f-p-e-show-div"><p id="error-p"></div></div>
    <div id="login-page" class="row">
      <div class="col s12 z-depth-4 card-panel">
					<form role="form" name="frmlogin" id="frmlogin" method="post" class="login-form">
          <div class="row">
            <div class="input-field col s12 center">
              <img src="<?php echo ADMIN_STYLEPATH ?>images/logo/login-logo.jpeg" alt="" class="circle responsive-img valign profile-image-login">
              <p class="center login-form-text">Bin Management - A basic smart Digital Manager</p>
            </div>
          </div>
          <div class="row margin">
            <div class="input-field col s12">
              <i class="material-icons prefix pt-5">person_outline</i>
              <input name="email" id="email" type="text">
              <label for="username" class="center-align">Username</label>
            </div>
          </div>
          <div class="row margin">
            <div class="input-field col s12">
              <i class="material-icons prefix pt-5">lock_outline</i>
              <input name="password" id="password" type="password">
              <label for="password">Password</label>
            </div>
          </div>
          <!--<div class="row">
            <div class="col s12 m12 l12 ml-2 mt-3">
              <input type="checkbox" id="remember-me" />
              <label for="remember-me">Remember me</label>
            </div>
          </div>-->
          <div class="row">
            <div class="input-field col s12">
              <a class="btn waves-effect waves-light col s12" id="btnlogin">Login</a>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s6 m6 l6">
              <p class="margin medium-small"></p>
            </div>
            <div class="input-field col s6 m6 l6">
            <!--<a href="<?php echo SITE_PATH ?>index/forgot">Forgot password ?</a>-->
              <p class="margin right-align medium-small"><a href="#" data-id="btn-f-l-p" class="modal-trigger" id="btn-f-l-p" data-rol="forgot login password">Forgot password ?</a></p>
            </div>
          </div>
        </form>
      </div>
    </div>
    <!-- Modal Structure -->

    <!-- ================================================
    Scripts
    ================================================ -->
    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/jquery-3.2.1.min.js"></script>
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/materialize.min.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>js/custom-script.js"></script>
     <script type="text/javascript" src="<?php echo ADMIN_STYLEPATH ?>vendors/sweetalert/dist/sweetalert2.min.js"></script>
    <script>
   //validation
       $(document).on('click', '#btnlogin', function(){
		   $(this).removeClass('btn-primary').addClass('btn-warning').val('checking....').fadeIn(1000);
		    var e = loginvalidation();
			if(e==1){
					$('#btnlogin').fadeTo(1000,0.1,function(){ 
                        $(this).html('error').removeClass('btn-warning').addClass('btn-danger').fadeTo(1200,1,function(){ 
	   					 $('#btnlogin').val('Resubmit');		 });
						});
				return false;
			}
			else{
				
				var url ="<?php echo ADMIN_PATH ?>index/login";

                var form = document.forms.namedItem("frmlogin");                        

                var oData = new FormData(document.forms.namedItem("frmlogin"));           

                var oReq = new XMLHttpRequest();

                oReq.open("POST", url,  true);   

                oReq.onload = function(oEvent) {
					

					 if(oReq.responseText==3){
					
					customSwalFunD("Error", "Trial Period Ended");
				
					 }
			else if(oReq.responseText==2){
					
					$('#frmlogin')[0].reset();
				
					 customSwalFunD("Error", "Username or password is incorrect");
					  $('#btnlogin').val('Resubmit') ;
				
					 }
				 else{
					
			document.location ="<?php echo ADMIN_PATH ?>index/home";
					 }
		};
                oReq.send(oData);
            
			return true;
			
			}
			
//validation			
function loginvalidation(){

        error=0;
 		$('input').removeClass('errors');
        $('input').removeClass('errorInput');
        var values = {
                                    'username':$('#email').val(),
									'password':$('#password').val(),
                                 }
        if(values.username==''){
            $('#email').addClass('errors');
            $('#email').attr("placeholder", "Please enter username.")
			$('#email').css({'border':'1px solid red'});
		    $('#email').addClass('errorInput');
            error=1;
        } 
		if(values.password==''){
            $('#passwordtxtPwd').addClass('errors');
            $('#password').attr("placeholder", "Please enter password");
			$('#password').css({'border':'1px solid red'});
            $('#password').addClass('errorInput');
            error=1;
        } 
        return error;
    }
}); 	
$(document).on('click','.a-u-f-p-r-b',function(e){
$('.f-p-e-show-div').hide().removeClass('successfp').children('p').html('');
$btn=$(this);
$(this).text('Checking...').fadeIn(1000);
var fieldvalues=$('#f-f-p').serialize();
$.ajax({
	type:"POST",
	url:"<?php echo ADMIN_PATH ?>index/forpasssend",
	data:fieldvalues,
	success: function(data){
		data=JSON.parse(data);
		$('#f-f-p')[0].reset();
		if(data.res==0){
			$btn.fadeTo(900,1,function(){ $(this).text('Send Password'); });$('.f-p-e-show-div').fadeIn().children('#error-p').html(data.errormsg);}
			else{
				$btn.fadeTo(900,1,function(){ $(this).text('Send Password'); });
				$('.f-p-e-show-div').addClass('successfp').fadeIn().children('#error-p').html(data.successmsg);
				}
		}
	});
	//
		
});
$(document).ready(function(e) {
	$(document).on('click','#close', function(e){
		$('.f-p-e-show-div').hide().removeClass('successfp').children('p').html('');
		$('.o-v-f-p').css('display','none');
		$('.f-p-p').css({'display':'none'});
	});
});
$('#close').click(function(){
		

	})	;
	
	 function customSwalFunD(sw_title,sw_html){
							swal({
											  title: '<div class="tst" >'+sw_title+'</div>',
											  html:'<div class="tst1" >'+sw_html+'</div>',
											  customClass: 'swal-delete',
											})	
		}
     </script>
<div data-role="forgotpanel"  class="f-p-p" id="f-p-p">
<form role="form" class="f-f-p" id="f-f-p" name="f-f-p">
<div class="m-header"><a id="close" href="#"><i class="material-icons prefix pt-5">close</i></a></div>
  <div class="modal-content">
      <h4 class="f-p-p-h-o">Forgot Password ? </h4>
          <div class="row margin">
                <div class="input-field col s12">
                  <i class="material-icons prefix pt-5">person_pin</i>
                  <input name="i-n-p-f-p-u-t" id="i-n-p-f-p-u-t" role="text-field" class="i-n-p-f-p-u-t" data-role="i-n-p-f-p-u-t" type="text">
                  <label for="user-for-pass-username" class="center-align">Enter Your username</label>
                </div>
        </div>
        
        <div class="row margin">
                <div class="input-field col s12">
                  <i class="material-icons prefix pt-5">email</i>
                  <input name="i-n-p-f-p-e-t" id="i-n-p-f-p-e-t" role="text-field" class="i-n-p-f-p-e-t" data-role="i-n-p-f-p-e-t" type="text">
                  <label for="user-for-pass-email" class="center-align">Enter Your Email</label>
                </div>
        </div>
        
        <div class="row">
            <div class="input-field col s12">
              <a class="btn waves-effect blue waves-light col s12 a-u-f-p-r-b" id="a-u-f-p-r-b" data-role="a-u-f-p-r-b">Send Password</a>
            </div>
          </div>
    </div>
    </form>
  </div>       
<div class="o-v-f-p"></div>   
 
  </body>
</html>
