<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Attendance_model','model');
	 }	
	public function index()
	{
		//$data['mainatten']=$this->model->getmainatten();
		//$data['attent']=$this->model->getattent();
		$data['menu']='attendance';
		$data['submenu']='attendance'; 
			$data['photo']=$this->model->getprodetails(); 
		$this->load->view('admin/header',$data);
		$this->load->view('admin/attendance/attendanceadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addattend(){
	$this->model->addattend();	
	}
	
	
}

