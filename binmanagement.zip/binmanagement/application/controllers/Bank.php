<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Bank extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('bank_model','model');
	 }	
	 public function index()
	{
	//Bank Table & Adding Field
		$data['bank']=$this->model->getbankname();//fetch all tax Names	default
		$this->load->view('admin/header');
		$this->load->view('admin/bank/bank',$data);
		$this->load->view('admin/footer');
	}
	
	//ADD New Bank
	public function addbank()
	{
		$this->model->addbank();	
	}	
	//Get Bank Names
	public function getbank()
	{
		$this->model->getbank();	
	}
	//GET Bank Details for edit	
	public function getbdetails()
	{
		$this->model->getbdetails();	
	}
	//Bank Update 
	public function updatebank()
	{
		$this->model->updatebank();	
	}
	//Bank Delete 
	public function deletebank()
	{
		$this->model->deletebank();	
	}

/*____________________________________________________________________________________________________________*/	



}

