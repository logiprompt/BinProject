<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authorisedperson extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Authorisedperson_model','model');
	 }	
	 public function index()
	{
		//$data['area']=$this->model->getarea();
		$data['employee']=$this->model->getemployeelist();
		$headdata['menu']='organization';
		$headdata['submenu']='employee';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/authorised/employeelist',$data);
		$this->load->view('admin/footer');
	}
	
	 public function addemployee()
	{
		$data['employee']=$this->model->getemployee();
		$data['designation']=$this->model->getdesig();
		$data['edu']=$this->model->geteducation();
		$data['menu']='organizer';
		$data['submenu']='Authorisedreg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/authorised/employeeregistration',$data);
		$this->load->view('admin/footer');
		
	}
	public function autheedit($id=false)
	{ 
	$data['employee']=$this->model->getemployee();
	$data['edu']=$this->model->geteducation();
	$data['designation']=$this->model->getdesig();
	$data['details']=$this->model->getemployeebyid($id);
	$data['menu']='organizer';
	$data['submenu']='editauthperson';
		$headdata['menu']='organizer';
		$headdata['submenu']='Authorisedreg';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/authorised/editemployeeregistration',$data);
		$this->load->view('admin/footer');
	}
	public function permission()
	{
	//	$data['id']=decode($id);
	$data['allorg']=$this->model->getallorg();
		$data['menu']='organization';
		$data['submenu']='orgreg';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/authpermission/orgpermission',$data);
		$this->load->view('admin/footer');
	}
	public function updatereg(){
		//echo "yyyy";
	  $this->model->updatereg();
	}
	public function inserteducation(){
		$this->model->addeducation();	
	}
	public function insertdesig(){
		$this->model->adddesi();
		}
	public function getdesig(){
		$this->model->getdesig();
		
	}
	public function getdesignation(){
		$this->model->getdesignation();
		
	}
	public function geteducation(){
		$this->model->geteducation();
		}
		public function geteducation1(){
		$this->model->geteducation1();
		}
	 public function employeereg()
	{
		
		$this->model->addemployee();	
		
	}
	public function  updatepermission()
	{
		$this->model->updatepermission();
	}
	
	
	 
		public function deleteEmployee(){
		//echo $id;
		$this->model->deleteEmployee();
		}
/*	public function salesmanproductsadd()
	{
		
		$data['salesman']=$this->model->getsalesmanid();
		$data['productcat']=$this->model->getcategory();
		//var_dump($data['productcat']);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/salesmanproductsadd ',$data);
		$this->load->view('admin/footer');
	}
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
		
	}
	public function getproductsbysubcategoryid()
	{ //fetching products by sucbcategory 
		$this->model->getproductsbysubcategoryid();
		
	}
	public function addsalesmanproduct()
	{ //add salesman product
		$this->model->addsalesmanproduct();
		
	}*/

/*	public function editsalesmanproducts($id=false)
	{ 
	$data['salesman']=$this->model->getsalesmanprobyid($id);
	$data['salesmancat']=$this->model->getsalesmancatbyid($id);
	$data['salesmansubcat']=$this->model->getsalesmansubcatbyid($id);
	    $data['salesmanid']=$id;
		$data['productcat']=$this->model->getcategory();
		$data['productsubcat']=$this->model->getsubcategory();
		$data['products']=$this->model->getproducts($data['salesmansubcat'][0]);
		$this->load->view('admin/header');
		$this->load->view('admin/salesman/editsalesmanproducts',$data);
		$this->load->view('admin/footer');
	}
	 public function upsalespro()
	{
		
			$this->model->upsalespro();
		
	}*/

}
