<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mobilelogin extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Mobilelogin_model','model');
	 }	
	 public function index($id=false)
	{
		if($id){
			
			$this->model->mobilelogin($id);
			}
	/*	if($this->session->userdata('loggedIn')==true)
		{
			header('location:'.SITE_PATH.'index/home');
		}*/
	
	
	}
	
	
}
