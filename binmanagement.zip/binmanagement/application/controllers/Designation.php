<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Designation extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Designation_model','model');
	 }	
	 public function index()
	{
		//$headdata['status']='active';
		$data['designation']=$this->model->getdesig();
		$headdata['menu']='organizer';
		$headdata['submenu']='designation';
		$this->load->view('admin/header',$headdata);//,$headdata);
		$this->load->view('admin/designation/designation_add',$data);
		$this->load->view('admin/footer');
	}
	public function adddesi()
	{
		$this->model->adddesi();
	}
	public function deletedesi()
	{
	$this->model->deletedesi();	
	}
	
	public function getdesi()
	{
	$this->model->getdesi();	
	}
	public function updatedesi()
	{
		$this->model->updatedesi();
	}
	

}

