<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Smsorg extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Smsorg_model','model');
	 }	public function index()
	{
		$data['menu']='smsorg';
		$data['submenu']='smsorg';
		$data['org']=$this->model->getallorg();
		$data['subcategory']=$this->model->getallsms();
		
		$this->load->view('admin/header',$data);
		$this->load->view('admin/smsorg/add',$data);
		$this->load->view('admin/footer');
	}
	
	public function insert()
	{
	$this->model->insert();	
	}
	public function edit($id=false){
			$data['menu']='smsorg';
		$data['submenu']='smsorg';
			$data['details']=$this->model->getdet($id);
			$data['org']=$this->model->getallorg();
		$data['subcategory']=$this->model->getallsms();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/smsorg/edit',$data);
		$this->load->view('admin/footer');
		}
		public function update(){
		$this->model->update();	
	}
	
	
	public function delete()
	{
	$this->model->delete();
	}
		
		
		
		
	

	
	
}
