<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms extends CI_Controller 
{
	 function __construct()
	 {
		parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Sms_model','model');
	 }
	 
	 	
		 public function index()
		{
			$data['menu']='services';
			$data['submenu']='sms';
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/user_sms');
			$this->load->view('admin/footer');
		
			}
		 public function send_sms()
		{
			$this->model->send_sms();
		}
	

}

