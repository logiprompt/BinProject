<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesreport extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Salesreport_model','model');
	 }
	 /*	public function index()
	{
		$data['salesman']=$this->model->getsalesman();
		$data['area']=$this->model->getarea();
		$data['merchant']=$this->model->getmerchant();
		$this->load->view('admin/header');
		$this->load->view('admin/salesreport');
		$this->load->view('admin/footer');
	}*/
	public function getdetailsbysid()
	{
		$this->model->getdetailsbysid();
		
		}
	public function getdetailsbydate()
	{
		$this->model->getdetailsbydate();
		
	}	
	public function getdetailsbyarea()
	{
		$this->model->getdetailsbyarea();
		
	}	
	public function getdetailsbymid()
	{
		$this->model->getdetailsbymid();
		
	}
//--/---------------------- New------------------------*/
	public function index()
	{
		$data['salesman']=$this->model->getsalesman();
		$data['area']=$this->model->getarea();
		$data['merchant']=$this->model->getmerchant();
		$this->load->view('admin/header');
		$this->load->view('admin/salesreport_page',$data);
		$this->load->view('admin/footer');
	}
	public function get()
	{
		$this->load->view('admin/header');
		$this->load->view('admin/salesreport_collectionpage');
		$this->load->view('admin/footer');
		
	}

	
	
	
}
