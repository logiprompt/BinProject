<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Education extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Education_model','model');
	 }	
	 public function index()
	{
		$headdata['status']='active';
		$headdata['menu']='organizer';
		$headdata['submenu']='education';
		$data['edu']=$this->model->geteducation();
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/education/educationadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function inserteducation(){
		$this->model->addeducation();	
	}
	
	
		public function updateeducation()
	{
		$this->model->updateedu();	
	}
	public function getdetails()
	{
		$this->model->getdetails();	
	}
	
	public function deleteeducation()
	{
		$this->model->deleteedu();	
	}

}

