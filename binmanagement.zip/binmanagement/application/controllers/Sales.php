<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Sales_model','model');
	 }	
	 public function index()
	{
		//$data['category']=$this->model->getcategory();
		//$data['subcategory']=$this->model->getsubcategory();
		//var_dump($data['subcategory']);
		$data['menu']='sales';
		$data['submenu']='sales';
		$data['products']=$this->model->getproducts();
		$data['merchant']=$this->model->getmerchant();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/sales/merchantsearch',$data);
		$this->load->view('admin/footer');
	}
	
	public function merchantsearch()
	{
		
		$this->model->merchantsearch();
		
		}
		public function selproamount()
	{
		
		$this->model->selproamount();
		
		}
	public function addorder()
	{
		$this->model->addorder();
		}
	public function selectMerchant(){
		echo "hfghfg";
		
	}
	public function checkprostock()
	{
		$this->model->checkprostock();
		}
	
}
