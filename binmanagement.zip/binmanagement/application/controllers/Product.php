<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Product_model','model');
	 }	
	 public function index()
	{
		//product list & adding page
		$headdata['status']='active';
		$data['category']=$this->model->getcategory();//fetch all category
		$data['subcategory']=$this->model->getsubcategory();//fetch all sub category
		$data['product']=$this->model->getproduct();//fetched all product from tables
	    $headdata['menu']='product';
		$headdata['submenu']='product';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/product/product',$data);
		$this->load->view('admin/footer');
	}
	//New Product open product PAGE  -product.php
	public function newproduct()
	{
		//product list & adding page
			$data['hsn']=$this->model->getallhsn();
			$data['protypes']=$this->model->getprotypes();
		$data['manufacture']=$this->model->getmanufacturer();
		$data['category']=$this->model->getcategory();//fetch all category List
		$data['subcat']=$this->model->editsubcategory();
		$data['product']=$this->model->getproduct();//fetched all product from tables
		$data['tax']=$this->model->gettax();//fetched all tax details from tables
		$data['measurement']=$this->model->getmeasurement();//fetched all product measurements from tables
		$headdata['menu']='product';
		$headdata['submenu']='newproduct';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/product/product_add',$data);
		$this->load->view('admin/footer');
	}
	//New Product - get sub categorie 
	public function newgetsubcategoriey()
	{
		$data['subcategory']=$this->model->getsubcategorybycategoryid();//newgetsubcategoriey();
	}
	//Get Tax Property Name
	public function newgettaxproperty(){
		$this->model->newgettaxproperty();	
	}
	//New Product - adding new product 
	public function addproduct(){
		$this->model->addproduct();	
	}
	
	 public function updaproduct()
	{
		
			$this->model->updaproduct();
		
	}
	
	
	//New category - adding new category directly
	public function newcategory(){
		$this->model->addingcategorydirect();	
	}
	
		//New category - adding new subcategory directly
	public function newsubcategory(){
		$this->model->addingsubcategorydirect();	
	}
	
	//New category - adding new mesurement directly
	public function newmesureunit(){
		$this->model->addnewmesure();
		
		}
	public function newprotype()
{
	$this->model->newprotype();	
}
	public function hsn(){
		$this->model->addnewhsn();
		
		}
		public function addnewmanufacturer(){
		$this->model->addnewmanufacturer();
		
		}
	
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getcategorybycategoryid();
	}

//product edit page open & get details	- New
	 public function proedit($id=false){
		 $data['menu']='product';
		$data['submenu']='product';
		 $data['protypes']=$this->model->getprotypes();
		 $data['hsn']=$this->model->getallhsn();
		 $data['manufacture']=$this->model->getmanufacturer();
		 $data['product']=$this->model->getproduct();
		$data['category']=$this->model->getcategory();
		$data['subcat']=$this->model->editsubcategory();
		$data['measurement']=$this->model->getmeasurement();
		$data['tax']=$this->model->gettax();
		$data['ptaxproperty']=$this->model->gettaxproperty($id);
		
		$data['edit']=$this->model->editproduct($id);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/product/product_edit',$data);
		$this->load->view('admin/footer');
	}	
	public function proupdate(){
			$this->model->updateproduct();		
	}
/*----------------------------------------------------------------------------------------------------------------------------------------------------*/	
	
	
	
public function deleteproduct()
{
	$this->model->deleteproduct();	
}
public function getnewmesureunit()
{
	$this->model->getnewmesureunit();	
}

public function getnewsubcats()
{
	$this->model->getnewsubcats();	
}
public function getnewcats()
{
	$this->model->getnewcats();	
}
public function getnewprotypes()
{
	$this->model->getnewprotypes();	
}

public function getnewhsn(){
	$this->model->getnewhsn();
	
	}
	public function getnewmanufacturer(){
	$this->model->getnewmanufacturer();
	
	}
	
	public function newselgetsubcategoriey(){
	$this->model->newselgetsubcategoriey();
	
	}

}

