<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	 function __construct(){
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Credentials: true");
        header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
        header('Access-Control-Max-Age: 1000');
        header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');

		$this->load->model('api/Login_model','model');
	 }	
	 public function index()
	{
		$this->model->login();
		
	}
	 public function checkattendance()
	{
		$this->model->checkattendance();
		
	}
	 public function checkphoto()
	{
		$this->model->checkphoto();
		
	}
	 public function addattendance()
	{
		$this->model->addattendance();
		
	}
	
	 public function addattendancephoto()
	{
		$this->model->addattendance();
		
	}
	
}

