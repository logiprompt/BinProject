<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesmanprofile extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->output->set_header('Access-Control-Allow-Origin: *');
		$this->load->model('api/Salesmanprofile_model','model');
	 }	
	 public function index()
	{
		$this->model->Salesmanprofile();
		
	}
	 public function alllocation()
	{
		$this->model->alllocation();
		
	}
	 public function routehistory()
	{
		$this->model->routehistory();
		
	}
}

