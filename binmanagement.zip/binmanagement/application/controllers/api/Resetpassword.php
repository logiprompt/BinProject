<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Resetpassword extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->output->set_header('Access-Control-Allow-Origin: *');
		$this->load->model('api/Resetpassword_model','model');
	 }	
	 public function index()
	{
		$this->model->checkoldpwd();
		
		
	}
	 public function getarea()
	{
		
		$this->model->getarea();
		
	}
	 public function resetpwd()
	{
		
		$this->model->resetpwd();
		
	}
	
}

