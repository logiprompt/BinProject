<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->output->set_header('Access-Control-Allow-Origin: *');
		$this->load->model('api/Report_model','model');
	 }	
	 public function index()
	{
		$this->model->getreport();
		
		
	}
	 public function collectionreport()
	{
		$this->model->collectionreport();
		
		
	}
	
}

