<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cashcollect extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->output->set_header('Access-Control-Allow-Origin: *');
		$this->load->model('api/Cashcollect_model','model');
	 }	
	 public function index()
	{
		$this->model->getmerchant();
		
		
	}
	 public function getareabyid()
	{
		
		$this->model->getareabyid();
		
	}
	 public function addcashcollection()
	{
		
		$this->model->addcashcollection();
		
	}
	 public function getopeningbalbyid()
	{
		
		$this->model->getopeningbalbyid();
		
	}
	 public function getlocationbyid()
	{
		
		$this->model->getlocationbyid();
		
	}
	 public function getterminalsbyid()
	{
		
		$this->model->getterminalsbyid();
		
	}
}

