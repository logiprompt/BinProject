<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salesproduct extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->output->set_header('Access-Control-Allow-Origin: *');
		$this->load->model('api/Salesproduct_model','model');
	 }	
	 public function index()
	{
		$this->model->getmerchant();
		
		
	}
	 public function getproductbyid()
	{
		
		$this->model->getproductbyid();
		
	}
 public function getamountbyproid()
	{
		
		$this->model->getamountbyproid();
		
	}
		 public function addsalesproduct()
	{
		
		$this->model->addsalesproduct();
		
	}
	 public function getopeningbalbyid()
	{
		
		$this->model->getopeningbalbyid();
		
	}
	 public function getlocationbyid()
	{
		
		$this->model->getlocationbyid();
		
	}
}

