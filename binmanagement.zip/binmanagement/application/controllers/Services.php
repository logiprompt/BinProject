<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Controller 
{
	 function __construct()
	 {
		parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Services_model','model');
	 }	
		 public function index()
		{
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			$data['amenity']=$this->model->getamenity();
			$data['jobs']=$this->model->getservicejobs();
			$data['amtitle']=$this->model->getamtitle();
			$data['itemtitle']=$this->model->getitemtitle();
			$data['services']=$this->model->getservices();
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/addservices',$data);
			$this->load->view('admin/footer');
		}
		
		
		 public function printpdf($id=false)
		 {
			$mid=decode($id);
			
			$this->model->generatepdf($mid);
			
			
			
		}
	public function insert()
	{
		$this->model->insert();	
	}
	public function insertdetails()
	{
		$this->model->insertdetails();	
	}
	public function updatedetails($id)
	{
		$id=decode($id);
		$this->model->updatedetails($id);	
	}
	public function insertdriver()
	{
		
		$this->model->insertdriver();	
	}
	/*public function deleteService()
	{
		$this->model->deleteService();	
	}*/

     public function editservices($id=false)
	 {
		$mid=decode($id);
		$data['edit']=$this->model->editservice($mid);
		$data['services']=$this->model->getservices($mid);
		$data['bike']=$this->model->getbikedetails($mid);
		$data['bikeaccess']=$this->model->getbikeaccess($mid);
		$data['hist']=$this->model->gethistory($mid);
		$data['schedule']=$this->model->getschedule($mid);
		$data['serjobs']=$this->model->getserjobs($mid);
		$data['menu']='service';
		$data['submenu']='sservice';
		$data['amenity']=$this->model->getamenity();
		$data['amtitle']=$this->model->getamtitle();
		$data['jobs']=$this->model->getservicejobs();
		$data['itemtitle']=$this->model->getitemtitle();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/services/editservices',$data);
		$this->load->view('admin/footer'); 
	 }
   	public function update()
	{
		$this->model->update();
	}
	public function updatedriver($id)
	{
		$id=decode($id);
		$this->model->updatedriver($id);
	}
	public function delete()
	{
		$this->model->delete();
	}
	public function deletereg()
	{
		$this->model->deletereg();
	}
	public function deletedri()
	{
		$this->model->deletedri();
	}
	public function deletesms()
	{
		$this->model->deletesms();
	}
	 public function serviceregister()
		{
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			$data['brand']=$this->model->getbrand();
			$data['amenity']=$this->model->getamenity();
			$data['jobs']=$this->model->getservicejobs();
			$data['amtitle']=$this->model->getamtitle();
			$data['itemtitle']=$this->model->getitemtitle();
			$data['services']=$this->model->getservicereg();
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/servicereg',$data);
			$this->load->view('admin/footer');
		}
		public function getmodel(){
		$this->model->getmodel();
	}
		public function edit($id)
		{
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			$data['brand']=$this->model->getbrand();
			$data['model']=$this->model->getmodelz();
			/*$data['amenity']=$this->model->getamenity();
			$data['jobs']=$this->model->getservicejobs();
			$data['amtitle']=$this->model->getamtitle();
			$data['itemtitle']=$this->model->getitemtitle();*/
			$data['services']=$this->model->getservicedetails($id);
			$data['vehicle']=$this->model->getvehicledetails($id);
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/servicereg_update',$data);
			$this->load->view('admin/footer');
		}
		public function getvehiclereg()
		{
			$this->model->getvehiclereg();	
		}
		 public function driverassign()
		{
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			
			$data['dri']=$this->model->getdriver();
			$data['services']=$this->model->getservicereg();
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/driverassign',$data);
			$this->load->view('admin/footer');
		}
		 public function driverassignedit($id)
		{
			$id=decode($id);
			$data['menu']='services';
			$data['submenu']='sservices';
			$data['service']=0;
			$data['vehicle']=$this->model->vehicle($id);
			$data['dri']=$this->model->getdriver();
			$data['services']=$this->model->getservicereg();
			$data['res']=$this->model->getdriverdetails($id);
			$this->load->view('admin/header',$data);
			$this->load->view('admin/services/editdriverassign',$data);
			$this->load->view('admin/footer');
		}
		
}

