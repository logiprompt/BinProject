<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absents extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Absents_model','model');
	 }	
	 public function index()
	{
 		$data['menu']='absents';
		$data['submenu']='absents';
		$data['absents']=$this->model->getabsents(); 
		//var_dump($this->session->userdata('org_id'));
		$this->load->view('admin/header',$data);
		$this->load->view('admin/absents/absentsadd',$data);
		$this->load->view('admin/footer');
	}
	 public function notification()
	{
 		$data['menu']='absents';
		$data['submenu']='absents';
		$data['absents']=$this->model->getabsents(); 
		//var_dump($this->session->userdata('org_id'));
		$this->load->view('admin/header',$data);
		$this->load->view('admin/absents/notification',$data);
		$this->load->view('admin/footer');
	}
	public function addabsents()
	{
		$this->model->addabsents();	
	}
	public function deleteAbsents(){
		//echo "dfgf";
		$this->model->deleteAbsents();
		}
	public function absedit($id=false){
		$aid=decode($id);
		$data['menu']='absents';
		$data['submenu']='absents';
		$data['edit']=$this->model->editDetails($aid);
		//var_dump($data['edit']);
		$data['absents']=$this->model->getabsents();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/absents/absentsedit',$data);
		$this->load->view('admin/footer'); 
		}
	public function updateabsents(){
		$this->model->updateabsents();	
	}
	public function newstatus(){
		$this->model->insertnew();	
	}
	
	
	public function getnewstatus(){
	$this->model->getnewstatus();
	
	}
	public function changevwstatus(){
	$this->model->changevwstatus();
	
	}
	
	
	
	/*public function addmenu(){
	$this->model->addmenu();	
	}
	public function editCategories($id=false){
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header');
		$this->load->view('admin/category/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatemenu(){
		$this->model->updatemenu();	
	}/*

	public function deleteMenu(){
		
		$this->model->deleteMenu();
		}
	
	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page*/
	
}

