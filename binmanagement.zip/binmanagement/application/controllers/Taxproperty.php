<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Taxproperty extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Tax_propertymodel','model');
	 }	
	 //$data['tax']=$this->model->gettax();//fetch all tax Names	default
	//ADD  sub tax property page
	public function index()
	{
		$data['tax']=$this->model->gettax();	
		$this->load->view('admin/header');
		$this->load->view('admin/taxproperty/tax_property',$data);
		$this->load->view('admin/footer');
	}
	//add sub tax property model
	public function addsubtax()
	{
	$this->model->addsubtax();	
	}
	//fetch exist field
	public function seltaxproperty()
	{
	$this->model->seltaxproperty();	
	}

}

