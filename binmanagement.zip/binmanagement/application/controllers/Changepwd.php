<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Changepwd extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Changepwd_model','model');
	 }	
	 public function index()
	{
		
		$headdata['status']='active';
		$headdata['menu']='index';
		$headdata['submenu']='changepassword';
		//$data['edu']=$this->model->geteducation();
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/resetpwd',$headdata);
		$this->load->view('admin/footer');
	}
	 public function reset()
	{
		
		$this->model->changepwd();
	 }

}

