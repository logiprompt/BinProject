<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewreturnstock extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Viewreturnstock_model','model');
	 }	
	 public function index()
	{
		//$data['area']=$this->model->getarea();
		$data['stock']=$this->model->getallreturnstock();
		$headdata['menu']='viewshifts';
		$headdata['submenu']='viewshifts';
		$this->load->view('admin/header',$headdata);
		$this->load->view('admin/registerreturns/returnliststock',$data);
		$this->load->view('admin/footer');
	}
	
	 

}
