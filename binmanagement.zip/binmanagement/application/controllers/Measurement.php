<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Measurement extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Measurement_model','model');
	 }	
	 public function index()
	{
	
		$data['tax']=$this->model->getmeasurement();
		$data['menu']='organizer';
		$data['submenu']='uom';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/measurement/measurementadd',$data);
		$this->load->view('admin/footer');
	}
	public function addmeasurement()
	{
		$this->model->addmeasurement();	
	}
	
	public function getdetails()
	{
		$this->model->getdetails();	
	}
		public function updatemeasurement()
	{
		$this->model->updatemeasurement();	
	}
		public function deletemeasurement()
	{
		$this->model->deletemeasurement();	
	}
}

