<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cash extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Cash_model','model');
	 }
	 
	 	public function index()
	    {
			//$data['title']='Merchant Registration';	

		//var_dump($data['product']);
       //  $data['merchant']=$this->model->getmerchant();
	    $data['menu']='collection';
		$data['submenu']='collection';
	    $data['bank']=$this->model->getbank();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/cashcollection/merchantsearch',$data);
		$this->load->view('admin/footer');
	}
	public function merchantsearch()
	{   
	$this->model->merchantsearch();
	}
	public function insertcash()
	{
	$this->model->insertcash();	
	}
}
