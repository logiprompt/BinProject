<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BinReport extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('BinReport_model','model');
	 }	
	 public function index()
	{
		//$data['category']=$this->model->getcategory();
		//$data['subcategory']=$this->model->getsubcategory();
		//var_dump($data['subcategory']);
		
		//$data['products']=$this->model->getproducts();
		$data['menu']='sales';
		$data['submenu']='salesreport';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/datesalereport/datesale');
		$this->load->view('admin/footer');
	}
	public function getReport()
	{
		//echo "fghg";
		$this->model->getReport();
		//var_dump($data['details']);
	}
		
		
		
	
}
