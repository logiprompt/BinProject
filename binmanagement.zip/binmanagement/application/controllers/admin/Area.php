<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Area extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Area_model','model');
	 }	
	 public function index()
	{
		
		//$data['area']=$this->model->getarea();
		$this->load->view('admin/header');
		$this->load->view('admin/area/areaadd');
		$this->load->view('admin/footer');
	}
	
	public function addarea(){
	$this->model->addarea();	
	}
	public function editArea($id=false){
		$data['area1']=$this->model->getarea();
		$data['edit']=$this->model->editArea($id);
		
		$this->load->view('admin/header');
		$this->load->view('admin/area/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatearea(){
		$this->model->updatearea();	
	}

	public function deleteArea(){
		//echo $id;
		$this->model->deleteArea();
		}
	
/*	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page
}

