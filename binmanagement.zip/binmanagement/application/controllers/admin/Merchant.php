<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchant extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Merchant_model','model');
	 }	public function index()
	{
			$data['title']='Merchant Registration';	
			$data['merchant']=$this->model->getmerchant();
			$data['area']=$this->model->getarea();
			$data['product']=$this->model->getproduct();
			//var_dump($data['product']);
		$this->load->view('admin/header');
		$this->load->view('admin/merchant/merchanthome',$data);
		$this->load->view('admin/footer');
	}
	
	public function addmerchant(){
		//$this->model->addmerchant();
			$data['area']=$this->model->getarea();
		$this->load->view('admin/header');
		$this->load->view('admin/merchant/merchantregistration1',$data);
		$this->load->view('admin/footer');
	}
	public function merchantproductadd()
	{/*
		$data['merchantid']=$this->model->getmerchantid();
		$data['productcat']=$this->model->getcategory();
		$data['merchant']=$this->model->getmerchant();
		$data['area']=$this->model->getarea();
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/merchantregistration1',$data);
		$this->load->view('admin/footer');*/
	}
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
		
	}
	public function getproductsbysubcategoryid()
	{ //fetching products by sucbcategory 
		$this->model->getproductsbysubcategoryid();
		
	}
	public function addmerchantproduct()
	{ //add salesman product
		$this->model->addmerchantproduct();
		
	}
	public function editmerchantreg($id=false,$mid=false)
	{ //add salesman product
		$data['title']='Edit Merchant Registration';	
		$data['merchantid']=$this->model->getmerchantid();
		$data['productcat']=$this->model->getcategory();
		$data['area']=$this->model->getarea();
		$data['edit']=$this->model->editmerchantreg($id);
		$data['terminal']=$this->model->getterminal($mid);
		//var_dump($data['edit']);
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/editmerchantregistration',$data);
		$this->load->view('admin/footer');
	}
	
	public function editmerchantproduct($id=false)
	{ //add salesman product
		$data['title']='Edit Merchant Product';	
		$data['productcat']=$this->model->getcategory();
		$data['editcategory']=$this->model->editcategory($id);
		$data['editsubcategory']=$this->model->editsubcategory($id);
		   $data['merchant']=$id;
$data['productsubcat']=$this->model->getsubcategory();
		$data['products']=$this->model->getproducts($data['editsubcategory'][0]);
		$data['edit']=$this->model->editmerchantproduct($id);
	//	var_dump($data['edit']);
		$this->load->view('admin/header');
			$this->load->view('admin/merchant/editmerchantproductadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function updatemerchant($id=false,$mid=false)
	{
		$this->model->updatemerchant($id,$mid);
	}
	
	public function updatemerchantproduct()
	{
		$this->model->updatemerchantproduct();
	}
	public function deletemerchant()
	{
		$this->model->deletemerchant();
	}
}
