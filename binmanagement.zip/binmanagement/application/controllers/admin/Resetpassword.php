<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Resetpassword extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Resetpassword_model','model');
	 }	
	   public function index(){    
      $this->load->view('admin/header');
		$this->load->view('admin/resetpassword');
		$this->load->view('admin/footer');  
    }
	 public function checkoldpwd(){    
 $this->model->checkoldpwd();	

    }
	 public function checkoldpwds(){    
 $this->model->checkoldpwds();	

    }
	
}
