<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Model_model','model');
	 }	public function index()
	{
		$data['menu']='Vehicle';
		$data['submenu']='model';
		$data['category']=$this->model->getbrand();
		$data['subcategory']=$this->model->getallmodel();
		//var_dump($data['subcategory']);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/model/add',$data);
		$this->load->view('admin/footer');
	}
	
	public function insert()
	{
	$this->model->insert();	
	}
	public function delete()
	{
	$this->model->delete();
	}
		
		
		public function edit($id=false){
			$data['menu']='Vehicle';
			$data['submenu']='model';
			$data['details']=$this->model->getdet($id);
			$data['category']=$this->model->getbrand();
		$data['subcategory']=$this->model->getallmodel();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/model/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function update(){
		$this->model->update();	
	}

	
	
}
