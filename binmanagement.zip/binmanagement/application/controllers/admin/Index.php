<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Index_model','model');
	 }	
	 public function index()
	{
		$this->load->view('admin/login ');
	}
	 public function forgot()
	{
		$this->load->view('admin/forgot');
	}
	public function home()
	{
		if($this->session->userdata('username')==false){
			$data['title']='Login';
			$data['page_title']='Login';
			$this->load->view('admin/login',$data);
			}
		else{
		
		$data['counts']=$this->model->counts();
		$this->load->view('admin/header');
		$this->load->view('admin/index',$data);
		$this->load->view('admin/footer');
	  }
	}
	public function login()
	{
		$this->model->login();
	}
	
	public function forpasssend()
	{
		$this->model->forpasssend();
	}
	
	
}
