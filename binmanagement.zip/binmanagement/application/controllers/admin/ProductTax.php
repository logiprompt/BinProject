<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductTax extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Product_tax_model','model');
	 }	
	 
	 public function index()
	{
		/*
		//product list & adding page
		$data['category']=$this->model->getcategory();//fetch all category
		$data['subcategory']=$this->model->getsubcategory();//fetch all sub category
		$data['product']=$this->model->getproduct();//fetched all product from tables*/
		$this->load->view('admin/header');
	/*	$this->load->view('admin/product/product',$data);*/
		$this->load->view('admin/footer');
	}
/*	public function addproduct()
	{
	$this->model->addproduct();	
	}
	public function getsubcategorybycategoryid()
	{ //fetching sucbcategory by category 
		$this->model->getsubcategorybycategoryid();
	}

//product edit page
	 public function proedit($id=false){
		$data['category']=$this->model->getcategory();               //fetch all category
		$data['subcategory']=$this->model->getsubcategoryedit();              //fetch all sub category
	
		$data['product']=$this->model->getproduct();            //fetched all product from tables
		$data['subcat']=$this->model->editsubcategory();
		$data['edit']=$this->model->editproduct($id);
		
		
		
		//$data['catbysubcat']=$this->model->editsubcategorybycategoryid();
		$this->load->view('admin/header');
		//$this->load->view('admin/category/categoryadd',$data);
		$this->load->view('admin/product/product_edit',$data);
		$this->load->view('admin/footer');
	}	
public function proupdate(){
		$this->model->updateproduct();		
}
public function deleteproduct()
{
	$this->model->deleteproduct();	
}*/
}

