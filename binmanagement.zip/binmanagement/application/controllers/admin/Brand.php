<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Brand_model','model');
	 }	
	 public function index()
	{
		$data['brand']=$this->model->getbrand();
		$data['menu']='Vehicle';
		$data['submenu']='brand';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/brand/add',$data);
		$this->load->view('admin/footer');
	}
	
	public function addbrand(){
	$this->model->addbrand();	
	}
	public function editbrand($id=false){
		$data['menu']='Vehicle';
		$data['submenu']='brand';
		$data['edit']=$this->model->editbrand($id);
		$data['brand']=$this->model->getbrand();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/brand/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatebrand(){
		$this->model->updatebrand();	
	}

	public function deletebrand(){
		//echo $id;
		$this->model->deletebrand();
		}
	
/*	public function deleteCategories($id=false){
		//echo $id;
		$this->model->deleteCategories($id);
		}*/
//product edit page
}

