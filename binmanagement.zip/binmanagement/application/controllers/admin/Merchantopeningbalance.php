<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchantopeningbalance extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Merchantopeningbalance_model','model');
	 }
	 
	 	public function index()
	{
		
			$data['merchant']=$this->model->getcategory();
			$data['openigbalance']=$this->model->getopenigbalance();
		$this->load->view('admin/header');
		$this->load->view('admin/merchantopeningbalanceadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addopeningbalance()
	{
		$this->model->addopeningbalance();
	}
	
	
		public function edit($id=false)
	{
		
		
			$data['merchant']=$this->model->getcategory();
			$data['opnbalbyid']=$this->model->getopenigbalancebyid($id);
			//var_dump($data['openigbalance']);
			//$data['edit']=$this->model->editopenigbalance();
		$this->load->view('admin/header');
		$this->load->view('admin/merchant/editmerchantopeningbalance',$data);
		$this->load->view('admin/footer');
	}
	
	
	public function update()
	{
		$this->model->update();	
	}
	
	
	public function delete()
	{
	$this->model->delete();	
	}
	
}
