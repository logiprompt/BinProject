<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subcategory extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Subcategory_model','model');
	 }	public function index()
	{
		$data['category']=$this->model->getcategory();
		$data['subcategory']=$this->model->getsubcategory();
		//var_dump($data['subcategory']);
		$this->load->view('admin/header');
		$this->load->view('admin/subcategory/subcategoryadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addsubcategory()
	{
	$this->model->addsubcategory();	
	}
		public function editsubcategories($id=false){
			$data['category']=$this->model->getcategory();
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header');
		$this->load->view('admin/subcategory/edit',$data);
		$this->load->view('admin/footer');
		}
		
	public function updatesubcategory(){
		$this->model->updatesubcategory();	
	}

	public function deletesubategories(){
		//echo $id;
		$this->model->deletesubategories();
		}
	
}
