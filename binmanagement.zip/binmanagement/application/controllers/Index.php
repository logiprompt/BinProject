<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {
	 function __construct(){
        parent::__construct();
		$this->load->model('Index_model','model');
	 }	
	 public function index()
	{
		if($this->session->userdata('loggedIn')==true)
		{
			header('location:'.SITE_PATH.'index/home');
		}
		$this->load->view('admin/login ');
	}
	 public function forgot()
	{
		$this->load->view('admin/forgot');
	}
	public function home()
	{
			if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		
		else{
		if($this->session->userdata('username')==false){
			$data['title']='Login';
			$data['page_title']='Login';
			$this->load->view('admin/login',$data);
			}
		else{
		
		$data['radarchart']=$this->model->getradarchart();
		$data['barchart']=$this->model->getbarchart();
		$data['merchant']=$this->model->getmerchant();
		$data['salesman']=$this->model->getsalesman();
		$data['categories']=$this->model->getcategories();
		$data['subcategories']=$this->model->getsubcategories();
		$data['totalbin']=$this->model->gettotalbin();
		$data['catbin']=$this->model->getcatbin();
		//var_dump($data['catbin']);
		$data['advtop']=$this->model->getadvtop();
		$data['advbtm']=$this->model->getadvbtm();
		$headdata['menu']='index';
		$headdata['submenu']='changepassword';
		if($this->session->userdata('usergroup')=='dri' || $this->session->userdata('usergroup')=='own')
		{
			$this->load->view('admin/do_header',$headdata);
		}
		else
		{
			$this->load->view('admin/header',$headdata);
		}
		$this->load->view('admin/index',$data);
		$this->load->view('admin/footerhome');
	  }
	}
	}
	public function login()
	{
		$this->model->login();
	}
	
	public function forpasssend()
	{
		$this->model->forpasssend();
	}
	
}
