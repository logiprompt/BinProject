<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
	$this->load->model('Service_model','model');
	 }	
	 public function index()
	{
		$data['menu']='Bin Management';
		$data['submenu']='Add to Bin';
		$data['bin']=$this->model->getbin();
		//var_dump($data['bin']);
		$data['mainservice']=$this->model->getmainservice();
		$data['category']=$this->model->getcategory();//fetch all category
		$data['subcategory']=$this->model->getsubcategory();//fetch all sub category
		$data['product']=$this->model->getproduct();//fetched all product from tables
		$data['measurement']=$this->model->getmeasurement();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/service/addservice',$data);
		$this->load->view('admin/footer');
	}
	public function addservice()
	{
		$this->model->addservice();	
	}
	
	public function deleteService()
	{
		$this->model->deleteService();	
	}

     public function seredit($id=false){
		$mid=decode($id);
		$data['edit']=$this->model->editservice($mid);
		$data['service']=$this->model->getservice();
		$data['menu']='service';
		$data['submenu']='sservice';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/service/serviceedit',$data);
		$this->load->view('admin/footer'); 
		}
   	public function updateservice(){
		$this->model->updateservice();
	}
	public function newgetproduct(){
		$this->model->newgetproduct();	
	}
	public function addbin(){
		//echo "fgf";
		$this->model->addbin();	
	}
	
}

