<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subcategory extends CI_Controller {
	 function __construct(){
        parent::__construct();
		if($this->session->userdata('loggedIn')==false)
		{
			header('location:'.SITE_PATH);
		}
		$this->load->model('Subcategory_model','model');
	 }	public function index()
	{
		$data['category']=$this->model->getcategory();
		$data['menu']='organizer';
		$data['submenu']='subcategory';
		$data['subcategory']=$this->model->getsubcategory();
		//var_dump($data['subcategory']);
		$this->load->view('admin/header',$data);
		$this->load->view('admin/subcategory/subcategoryadd',$data);
		$this->load->view('admin/footer');
	}
	
	public function addsubcategory()
	{
	$this->model->addsubcategory();	
	}
		public function editsubcategories($id=false){
			$data['subcategory']=$this->model->getsubcategory();
			$data['category']=$this->model->getcategory();
			$data['menu']='organizer';
			$data['submenu']='subcategory';
			$id=decode($id);
		$data['edit']=$this->model->editcategory($id);
		$this->load->view('admin/header',$data);
		if(empty($data['edit']))
		{
			$data['heading']='Message';
			$data['message']='An uncaught Exception was encountered.Please try again';
			$this->load->view('errors/html/error_general',$data);
		}
		else{
		$this->load->view('admin/subcategory/edit',$data);
		}
		$this->load->view('admin/footer');
		}
	//GET EXIST SUB CATEGORY
	public function getexistsubcategoriey(){
		$this->model->getexistsubcategoriey();	
	}
	public function getallsubcategoriey(){
		$this->model->getallsubcategoriey();	
	}
/*---------------------------------------------------------------------*/	
	public function updatesubcategory(){
		$this->model->updatesubcategory();	
	}

	public function deletesubategories(){
		//echo $id;
		$this->model->deletesubategories();
		}
	
}
